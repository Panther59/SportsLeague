# Road map

- [x] A feature that has been completed
- [ ] A feature that has NOT yet been completed

Features that have a checkmark are complete and available for
download in the
[CI build](http://vsixgallery.com/extension/VSOpenFolderPackage.293598f9-ae68-4cf5-a8ad-fa4f273fdc05/).

# Change log

These are the changes to each version that has been released
on the official Visual Studio extension gallery.

## 1.1

- [x] Feature 3
- [x] Feature 4

## 1.0

- [x] Initial release
- [x] Feature 1
- [x] Feature 2
  - [x] Sub feature