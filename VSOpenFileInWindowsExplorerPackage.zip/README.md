# Open File in Windows Explorer

<!-- Update the VS Gallery link after you upload the VSIX-->
Download this extension from the [VS Gallery](https://visualstudiogallery.msdn.microsoft.com/3aa3b07c-1ac5-44f3-a701-8aadb384c60e).

---------------------------------------

Open file in the windows explorer.Open 

## Features

- Open File in Windows Explorer.

### Open File in Windows Explorer
New context menu will be added on to file node.
Right click on the any file under solution explorer as shown below, then new command will be available which will open same file in the windows explorer.
![Preview](VSOpenFolderPackage/Resources/Preview1.png)
## Contribute
Check out the [contribution guidelines](CONTRIBUTING.md)
if you want to contribute to this project.

For cloning and building this project yourself, make sure
to install the
[Extensibility Tools 2015](https://visualstudiogallery.msdn.microsoft.com/ab39a092-1343-46e2-b0f1-6a3f91155aa6)
extension for Visual Studio which enables some features
used by this project.

## License
[Apache 2.0](LICENSE)