﻿//------------------------------------------------------------------------------
// <copyright file="OpenIDVReferenceInExplorerCommand.cs" company="Ayvan">
//     Copyright (c) Company.  All rights reserved.
// </copyright>
//------------------------------------------------------------------------------

namespace VSOpenFolderPackage.Commands
{
    using System;
    using System.ComponentModel.Design;
    using EnvDTE;
    using EnvDTE80;
    using Microsoft.VisualStudio;
    using Microsoft.VisualStudio.Shell;
    using Microsoft.VisualStudio.Shell.Interop;

    /// <summary>
    /// Command handler
    /// </summary>
    internal sealed class OpenIDVReferenceInExplorerCommand
    {
        #region Fields

        /// <summary>
        /// Command menu group (command set GUID).
        /// </summary>
        public static readonly Guid CommandSet = new Guid("5c11199d-c86f-46d4-a8ae-52851ea1d400");

        /// <summary>
        /// Defines the 
        /// </summary>
        private readonly DTE2 dte;

        /// <summary>
        /// VS Package that provides this command, not null.
        /// </summary>
        private readonly Package package;

        /// <summary>
        /// Command ID.
        /// </summary>
        public const int CommandId = 0x0102;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="OpenIDVReferenceInExplorerCommand"/> class.
        /// Adds our command handlers for menu (commands must exist in the command table file)
        /// </summary>
        /// <param name="package">Owner package, not null.</param>
        private OpenIDVReferenceInExplorerCommand(Package package)
        {
            if (package == null)
            {
                throw new ArgumentNullException("package");
            }

            this.package = package;
            this.dte = Package.GetGlobalService(typeof(DTE)) as DTE2;

            OleMenuCommandService commandService = this.ServiceProvider.GetService(typeof(IMenuCommandService)) as OleMenuCommandService;
            if (commandService != null)
            {
                var menuCommandID = new CommandID(CommandSet, CommandId);
                var menuItem = new OleMenuCommand(this.MenuItemCallback, menuCommandID);
                menuItem.BeforeQueryStatus += MenuItem_BeforeQueryStatus;
                commandService.AddCommand(menuItem);
            }
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the instance of the command.
        /// </summary>
        public static OpenIDVReferenceInExplorerCommand Instance
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets the service provider from the owner package.
        /// </summary>
        private IServiceProvider ServiceProvider
        {
            get
            {
                return this.package;
            }
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// Initializes the singleton instance of the command.
        /// </summary>
        /// <param name="package">Owner package, not null.</param>
        public static void Initialize(Package package)
        {
            Instance = new OpenIDVReferenceInExplorerCommand(package);
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// The MenuItem_BeforeQueryStatus
        /// </summary>
        /// <param name="sender">The <see cref="object"/></param>
        /// <param name="e">The <see cref="EventArgs"/></param>
        private void MenuItem_BeforeQueryStatus(object sender, EventArgs e)
        {
			bool isVisible = false;

			try
			{
				UIHierarchy uih = this.dte.ToolWindows.SolutionExplorer;
				Array selectedItems = (Array)uih.SelectedItems;
				if (selectedItems != null && selectedItems.Length > 0)
				{
					UIHierarchyItem selItem = selectedItems.GetValue(0) as UIHierarchyItem;
					dynamic obj = selItem.Object;
					var path = obj.Path;

					System.IO.FileInfo info = new System.IO.FileInfo(path);
					if (info.Exists && info.Directory.Exists)
					{
						isVisible = true;
					}
					//string filePath = prjItem.Properties.Item("FullPath").Value.ToString();
					//System.Windows.Forms.MessageBox.Show(selItem.Name + filePath);
				}
			}
			catch (Exception ex)
			{
				this.WriteToOutputWindow(ex.Message);
			}

			(sender as OleMenuCommand).Visible = isVisible;
		}

        /// <summary>
        /// This function is the callback used to execute the command when the menu item is clicked.
        /// See the constructor to see how the menu item is associated with this function using
        /// OleMenuCommandService service and MenuCommand class.
        /// </summary>
        /// <param name="sender">Event sender.</param>
        /// <param name="e">Event args.</param>
        private void MenuItemCallback(object sender, EventArgs e)
        {
            try
            {
                UIHierarchy uih = this.dte.ToolWindows.SolutionExplorer;
                Array selectedItems = (Array)uih.SelectedItems;
                if (selectedItems != null && selectedItems.Length > 0)
                {
                    UIHierarchyItem selItem = selectedItems.GetValue(0) as UIHierarchyItem;
                    dynamic obj = selItem.Object;
                    var path = obj.Path;

                    System.IO.FileInfo info = new System.IO.FileInfo(path);
                    if (info.Exists && info.Directory.Exists)
                    {
                        System.Diagnostics.Process.Start("explorer.exe", string.Format("/select,\"{0}\"", path));
                    }
                    //string filePath = prjItem.Properties.Item("FullPath").Value.ToString();
                    //System.Windows.Forms.MessageBox.Show(selItem.Name + filePath);
                }
            }
            catch (Exception ex)
            {
                this.WriteToOutputWindow(ex.Message);
            }
        }

        /// <summary>
        /// The WriteToOutputWindow
        /// </summary>
        /// <param name = "content">The <see cref = "string "/></param>
        private void WriteToOutputWindow(string content)
        {
            IVsOutputWindow outWindow = Microsoft.VisualStudio.Shell.Package.GetGlobalService(typeof(SVsOutputWindow)) as IVsOutputWindow;
            Guid generalPaneGuid = VSConstants.GUID_OutWindowDebugPane; // P.S. There's also the GUID_OutWindowDebugPane available.
            IVsOutputWindowPane generalPane;
            outWindow.GetPane(ref generalPaneGuid, out generalPane);
            generalPane.OutputTaskItemString(content, VSTASKPRIORITY.TP_NORMAL, VSTASKCATEGORY.CAT_COMMENTS, "Open File In Windows Explorer", 0, null, 0, null);
            generalPane.Activate(); // Brings this pane into view
        }

        #endregion

        #endregion
    }
}
