import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewMultipleQuestionPollComponent } from './view-multiple-question-poll.component';

describe('ViewMultipleQuestionPollComponent', () => {
  let component: ViewMultipleQuestionPollComponent;
  let fixture: ComponentFixture<ViewMultipleQuestionPollComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewMultipleQuestionPollComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewMultipleQuestionPollComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
