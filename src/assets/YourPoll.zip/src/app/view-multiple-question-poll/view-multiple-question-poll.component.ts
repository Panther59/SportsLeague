import { Component, OnInit, Output, Input, EventEmitter } from '@angular/core';
import { Poll } from '../_models/poll';
import { Question } from '../_models/question';
import { ResponsesService } from '../_services/responses.service';
import { ResponseRecord } from '../_models/responseRecord';

@Component({
  selector: 'app-view-multiple-question-poll',
  templateUrl: './view-multiple-question-poll.component.html',
  styleUrls: ['./view-multiple-question-poll.component.scss']
})
export class ViewMultipleQuestionPollComponent implements OnInit {

  totalVotes: number;

  pollData: Poll;
  get poll(): Poll {
    return this.pollData;
  }
  @Output() pollRefresh = new EventEmitter();
  answers: Array<ResponseRecord> = [];

  @Input('poll')
  set poll(value: Poll) {
    this.pollData = value;
    this.pollData.pollPages[0].questionGroups[0].questions.forEach((q) => this.updatePercentages(q));
  }

  @Input() isPollTaken: boolean = false;
  constructor(private responsesService: ResponsesService) { }

  ngOnInit() {
  }

  async saveAnswer(question: Question, optionId: number) {
    if (question && this.poll) {
      let record = new ResponseRecord();
      record.optionId = optionId;
      record.questionId = question.id;
      question.answerId = optionId;
      this.answers = this.answers.filter((a) => (a.questionId == question.id) == false);
      this.answers.push(record);
    }
  }

  async submitPoll() {
    if (this.poll.pollPages[0].questionGroups[0].questions.length == this.answers.length) {
      await this.responsesService.saveResponse(this.answers, this.poll.id).toPromise();
      this.pollRefresh.emit();
    }
  }

  updatePercentages(question: Question) {
    if (question) {
      this.totalVotes = question.optionSet.options.reduce((x, current) => {
        if (current.voteCount) {
          return x + current.voteCount;
        }
        else {
          return x;
        }
      }, 0);
      if (this.totalVotes && this.totalVotes > 0) {
        question.optionSet.options.forEach(x => {
          if (x.voteCount) {
            x.votePercentage = x.voteCount * 100 / this.totalVotes;
          } else {
            x.votePercentage = 0;
          }
        });
      }
    }
  }

  getDecimalPercentage(data: number, decimalPlaces : number = 0) : string{
    return data.toFixed(decimalPlaces);
  }

}
