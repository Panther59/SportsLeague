import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgBlockUI, BlockUI } from 'ng-block-ui';
import { PollsService } from '../_services/polls.service';
import { Poll } from '../_models/poll';

@Component({
  selector: 'app-polls',
  templateUrl: './polls.component.html',
  styleUrls: ['./polls.component.scss']
})
export class PollsComponent implements OnInit {
  polls: Array<Poll>;
  @BlockUI() blockUI: NgBlockUI;

  constructor(
    private router: Router,
    private pollsService: PollsService) {
    this.Initialize();
  }

  async Initialize() {
    try {
      this.blockUI.start("Loading polls...please wait...");
      this.polls = await this.pollsService.getAll().toPromise();
    }
    catch (ex) {
      console.error(ex);
    }
    finally {
      this.blockUI.stop();
    }
  }

  viewPoll(poll: Poll) {
    if (poll) {
      this.router.navigate(['/polls/' + poll.id]);
    }
  }

  ngOnInit() {
  }

}
