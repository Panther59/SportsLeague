var User = /** @class */ (function () {
    function User() {
    }
    return User;
}());
export { User };
//# sourceMappingURL=user.js.map