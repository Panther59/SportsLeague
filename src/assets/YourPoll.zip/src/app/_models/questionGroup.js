var QuestionGroup = /** @class */ (function () {
    function QuestionGroup() {
    }
    return QuestionGroup;
}());
export { QuestionGroup };
//# sourceMappingURL=questionGroup.js.map