import { Option } from "./option";
import { Question } from "./question";
import { Response } from "./response";

export class ResponseRecord {
  public id: number;
  public option: Option;
  public optionId: number;
  public question: Question;
  public questionId: number;
  public response: Response;
  public responseId: number;
}
