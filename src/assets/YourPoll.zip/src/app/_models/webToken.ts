export class WebToken {
    accessToken: string;
}