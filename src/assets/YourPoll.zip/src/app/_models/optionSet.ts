import { Option } from "./option";
import { Question } from "./question";

export class OptionSet {
  public id: number;
  public isGeneric: boolean;
  public name: string;
  public options: Option[];
  public questions: Question[];
}
