import { QuestionGroup } from "./questionGroup";
import { OptionSet } from "./optionSet";
import { QuestionType } from "./questionType";

export class Question {
  public group: QuestionGroup;
  public groupId: number;
  public id: number;
  public optionSet: OptionSet;
  public optionSetId: number;
  public answerId: number;
  public required: boolean;
  public title: string;
  public type: QuestionType;
  public typeId: number;
}
