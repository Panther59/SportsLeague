var Response = /** @class */ (function () {
    function Response() {
    }
    return Response;
}());
export { Response };
//# sourceMappingURL=response.js.map