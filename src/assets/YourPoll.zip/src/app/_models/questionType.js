var QuestionType = /** @class */ (function () {
    function QuestionType() {
    }
    return QuestionType;
}());
export { QuestionType };
//# sourceMappingURL=questionType.js.map