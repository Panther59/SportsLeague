import { OptionSet } from "./optionSet";

export class Option {
  public id: number;
  public optionSet: OptionSet;
  public optionSetId: number;
  public title: string;
  public voteCount: number;
  public votePercentage: number;
}
