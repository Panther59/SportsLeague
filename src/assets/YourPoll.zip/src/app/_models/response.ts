import { Poll } from "./poll";
import { User } from "./user";

export class Response {
  public createdOn: Date;
  public date: Date;
  public id: number;
  public poll: Poll;
  public pollId: number;
  public status: string;
  public updatedOn: Date;
  public user: User;
  public userId: number;
}
