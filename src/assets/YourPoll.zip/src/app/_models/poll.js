var Poll = /** @class */ (function () {
    function Poll() {
    }
    return Poll;
}());
export { Poll };
//# sourceMappingURL=poll.js.map