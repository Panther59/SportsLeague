import { User } from "./user";
import { OptionSet } from "./optionSet";
import { PollPage } from "./pollPage";
import { PollType } from "./pollType";

export class Poll {
  public createdBy: number;
  public createdOn: Date;
  public createdUser: User;
  public end: Date;
  public id: number;
  public name: string;
  public pollPages: PollPage[];
  public responses: Response[];
  public start: Date;
  public status: string;
  public type: PollType;
  public typeId: number;
  public updatedBy: number;
  public updatedOn: Date;
  public updatedUser: User;
}