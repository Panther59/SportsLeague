var WebToken = /** @class */ (function () {
    function WebToken() {
    }
    return WebToken;
}());
export { WebToken };
//# sourceMappingURL=webToken.js.map