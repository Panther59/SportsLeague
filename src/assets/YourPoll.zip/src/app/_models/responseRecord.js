var ResponseRecord = /** @class */ (function () {
    function ResponseRecord() {
    }
    return ResponseRecord;
}());
export { ResponseRecord };
//# sourceMappingURL=responseRecord.js.map