export class theme{
    isDark: boolean;
    styleName: string;
    displayName: string;
    primary: string;
    accent: string;
    warn: string;
}