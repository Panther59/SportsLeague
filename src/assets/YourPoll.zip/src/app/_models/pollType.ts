export class PollType {
  public id: number;
  public name: string;
}
