var Question = /** @class */ (function () {
    function Question() {
    }
    return Question;
}());
export { Question };
//# sourceMappingURL=question.js.map