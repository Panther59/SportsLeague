import { Poll } from "./poll";
import { QuestionGroup } from "./questionGroup";

export class PollPage {
  public id: number;
  public poll: Poll;
  public pollId: number;
  public questionGroups: QuestionGroup[];
  public title: string;
}