var theme = /** @class */ (function () {
    function theme() {
    }
    return theme;
}());
export { theme };
//# sourceMappingURL=theme.js.map