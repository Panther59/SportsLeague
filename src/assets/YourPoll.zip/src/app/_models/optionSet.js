var OptionSet = /** @class */ (function () {
    function OptionSet() {
    }
    return OptionSet;
}());
export { OptionSet };
//# sourceMappingURL=optionSet.js.map