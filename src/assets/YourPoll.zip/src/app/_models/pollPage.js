var PollPage = /** @class */ (function () {
    function PollPage() {
    }
    return PollPage;
}());
export { PollPage };
//# sourceMappingURL=pollPage.js.map