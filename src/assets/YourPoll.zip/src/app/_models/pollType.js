var PollType = /** @class */ (function () {
    function PollType() {
    }
    return PollType;
}());
export { PollType };
//# sourceMappingURL=pollType.js.map