var Option = /** @class */ (function () {
    function Option() {
    }
    return Option;
}());
export { Option };
//# sourceMappingURL=option.js.map