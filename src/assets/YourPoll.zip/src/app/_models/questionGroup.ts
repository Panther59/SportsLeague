import { Question } from "./question";
import { PollPage } from "./pollPage";

export class QuestionGroup {
  public id: number;
  public pollPage: PollPage;
  public pollPageId: number;
  public questions: Question[];
  public title: string;
}
