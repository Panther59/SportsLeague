import { RouterModule } from '@angular/router';
import { UsersComponent } from './users/users.component';
import { PollsComponent } from './polls/polls.component';
import { ViewPollComponent } from './view-poll/view-poll.component';
import { AuthGuard } from './_guards/auth.guard';
import { LoginComponent } from './login/login.component';
import { CreatePollComponent } from './create-poll/create-poll.component';
var appRoutes = [
    { path: '', component: PollsComponent, },
    { path: 'login', component: LoginComponent, },
    { path: 'home', component: PollsComponent, },
    { path: 'users', component: UsersComponent, canActivate: [AuthGuard] },
    { path: 'polls/create', component: CreatePollComponent },
    { path: 'polls', component: PollsComponent, },
    { path: 'polls/:id', component: ViewPollComponent, },
    // otherwise redirect to home
    { path: '**', redirectTo: '' }
];
export var routing = RouterModule.forRoot(appRoutes, { useHash: true, enableTracing: false, onSameUrlNavigation: 'reload' });
//# sourceMappingURL=app.routing.js.map