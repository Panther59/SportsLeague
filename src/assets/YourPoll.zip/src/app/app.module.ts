import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {
  MatButtonModule,
  MatCheckboxModule,
  MatMenuModule,
  MatSidenavModule,
  MatToolbarModule,
  MatCardModule,
  MatIconModule,
  MatDividerModule,
  MatListModule,
  MatFormFieldModule,
  MatInputModule,
  MatExpansionModule,
  MatDialogModule,
  MatSelectModule,
  MatDatepickerModule,
  MatNativeDateModule,
  MatTooltipModule
} from '@angular/material';
import { NgProgressModule } from '@ngx-progressbar/core';
import { BlockUIModule } from 'ng-block-ui';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { NgProgressHttpModule } from '@ngx-progressbar/http';
import { NgProgressRouterModule } from '@ngx-progressbar/router';
import { FormsModule } from '@angular/forms';
import {
  SocialLoginModule,
  AuthServiceConfig,
  GoogleLoginProvider,
  FacebookLoginProvider,
  LinkedinLoginProvider,
} from "angular-6-social-login";

import { AppComponent } from './app.component';
import { UsersComponent } from './users/users.component';
import { HomeComponent } from './home/home.component';
import { routing } from './app.routing';
import { StorageService } from './_services/storage.service';
import { PollsComponent } from './polls/polls.component';
import { UserService } from './_services/user.service';
import { PollsService } from './_services/polls.service';
import { ViewPollComponent } from './view-poll/view-poll.component';
import { ViewSingleQuestionPollComponent } from './view-single-question-poll/view-single-question-poll.component';
import { ResponsesService } from './_services/responses.service';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './_guards/auth.guard';
import { AuthService } from './_services/auth.service';
import { ThemeDialogComponent } from './theme-dialog/theme-dialog.component';
import { CreatePollComponent } from './create-poll/create-poll.component';
import { CreateSingleQuestionPollComponent } from './create-single-question-poll/create-single-question-poll.component';
import { MessageDialogComponent } from './message-dialog/message-dialog.component';
import { ConfirmDialogComponent } from './confirm-dialog/confirm-dialog.component';
import { AlertService } from './_services/alert.service';
import { MessageService } from './_services/message.service';
import { CreateMultipleQuestionPollComponent } from './create-multiple-question-poll/create-multiple-question-poll.component';
import { CreateQuestionComponent } from './create-question/create-question.component';
import { ViewMultipleQuestionPollComponent } from './view-multiple-question-poll/view-multiple-question-poll.component';
import { MyPollsComponent } from './my-polls/my-polls.component';

export function getAuthServiceConfigs() {
  let config = new AuthServiceConfig(
    [
      {
        id: FacebookLoginProvider.PROVIDER_ID,
        provider: new FacebookLoginProvider("303396613571673")
      },
      {
        id: GoogleLoginProvider.PROVIDER_ID,
        provider: new GoogleLoginProvider("848129182659-ula5dg97e827i5atdptuampr5jr7mqkj.apps.googleusercontent.com")
      },
      {
        id: LinkedinLoginProvider.PROVIDER_ID,
        provider: new LinkedinLoginProvider("1098828800522-m2ig6bieilc3tpqvmlcpdvrpvn86q4ks.apps.googleusercontent.com")
      },
    ]);
  return config;
}

@NgModule({
  declarations: [
    AppComponent,
    UsersComponent,
    HomeComponent,
    PollsComponent,
    ViewPollComponent,
    CreatePollComponent,
    LoginComponent,
    ViewSingleQuestionPollComponent,
    ThemeDialogComponent,
    CreateSingleQuestionPollComponent,
    MessageDialogComponent,
    ConfirmDialogComponent,
    CreateMultipleQuestionPollComponent,
    CreateQuestionComponent,
    ViewMultipleQuestionPollComponent,
    MyPollsComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    routing,
    SocialLoginModule,
    HttpClientModule,
    MatButtonModule,
    MatCheckboxModule,
    MatSidenavModule,
    MatToolbarModule,
    MatMenuModule,
    MatInputModule,
    MatFormFieldModule,
    MatIconModule,
    MatCardModule,
    MatDividerModule,
    MatListModule,
    MatExpansionModule,
    MatDialogModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatTooltipModule,
    NgProgressModule.forRoot(),
    NgProgressRouterModule,
    NgProgressHttpModule,
    BlockUIModule.forRoot()
  ],
  entryComponents: [
    ThemeDialogComponent,
    ConfirmDialogComponent,
    MessageDialogComponent
  ],
  providers: [
    AuthGuard,
    AuthService,
    StorageService,
    UserService,
    PollsService,
    ResponsesService,
    AlertService,
    MessageService,
    {
      provide: AuthServiceConfig,
      useFactory: getAuthServiceConfigs
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
