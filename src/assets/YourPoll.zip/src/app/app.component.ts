import { Component, HostBinding } from '@angular/core';
import { OverlayContainer } from '@angular/cdk/overlay';
import { StorageService } from './_services/storage.service';
import { NgBlockUI, BlockUI } from 'ng-block-ui';
import { routerTransition } from './_animations/router.transition.animation';
import { AuthService } from './_services/auth.service';
import { ActivatedRoute, Router, RoutesRecognized, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import {
  AuthService as SocialAuthService,
  FacebookLoginProvider,
  GoogleLoginProvider,
  LinkedinLoginProvider,
  SocialUser
} from 'angular-6-social-login';
import { MatDialog } from '@angular/material';
import { ThemeDialogComponent } from './theme-dialog/theme-dialog.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  animations: [routerTransition]
})
export class AppComponent {
  @BlockUI() blockUI: NgBlockUI;
  @HostBinding('class') componentCssClass;
  themes: string[] = ['my-light-theme', 'my-dark-theme', 'my-theme'];
  lastUrl: any;

  constructor(
    private socialAuthService: SocialAuthService,
    public overlayContainer: OverlayContainer,
    private authService: AuthService,
    private route: ActivatedRoute,
    private router: Router,
    private storageService: StorageService,
    public dialog: MatDialog) {
    
    this.applyTheme(this.storageService.theme);
  }

  selectTheme(theme: string = null) {
    let selectedTheme = 'dark-deep-purple-theme';
    if (theme != null) {
      selectedTheme = theme;
    }

    this.applyTheme(selectedTheme);
    this.storageService.theme = selectedTheme;
  }

  applyTheme(theme: string) {
    this.componentCssClass = theme;
    const classList = this.overlayContainer.getContainerElement().classList;
    const toRemove = Array.from(classList).filter((item: string) =>
      item.includes('-theme')
    );
    if (toRemove && toRemove.length > 0) {
      classList.remove(...toRemove);
    }

    classList.add(theme);
  }

  isUserLoggedIn() {
    if (this.storageService.currentUser && this.storageService.token) {
      return true;
    } else {
      return false;
    }
  }

  isSocial() {
    if (this.storageService.currentUser && this.storageService.isSocial) {
      return true;
    } else {
      return false;
    }
  }

  getCurrentUserName() {
    if (this.storageService.currentUser) {
      return this.storageService.currentUser.firstName + ' ' + this.storageService.currentUser.lastName;
    }
  }

  getCurrentUserImage() {
    if (this.storageService.currentUser) {
      return this.storageService.currentUser.imageUrl;
    }
  }

  logout() {
    if (this.storageService.isSocial) {
      this.socialAuthService.signOut();
    }
    this.authService.logout();
    if (this.isAuthGuardPresent(this.lastUrl)) {
      this.router.navigateByUrl('');
    }
  }

  isAuthGuardPresent(url: string): boolean {
    url = url.toLocaleLowerCase();
    if (url.startsWith('/users') || 
    url.startsWith('/polls/create') ||
    url.startsWith('/mypolls')) {
      return true;
    } else {
      return false;
    }
  }

  async viewTheme() {
    const dialogRef = this.dialog.open(ThemeDialogComponent);

    var result = await dialogRef.afterClosed().toPromise();
    if(result){
      this.applyTheme(result);
    }
  }

  ngOnInit() {
  }
}
