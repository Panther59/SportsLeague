import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { theme } from 'src/app/_models/theme';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-theme-dialog',
  templateUrl: './theme-dialog.component.html',
  styleUrls: ['./theme-dialog.component.scss']
})
export class ThemeDialogComponent implements OnInit {

  themes: Array<theme> = []
  selectedTheme: string;

  constructor(
    private http: HttpClient,
    public dialogRef: MatDialogRef<ThemeDialogComponent>) {
    this.loadData();
  }

  async loadData() {
    this.themes = await this.getThemes().toPromise();
  }

  getThemes(): Observable<Array<theme>> {
    return this.http.get<Array<theme>>("assets/themes.json")
  }

  getThemeClassForCard(theme: theme) {
    let themes = 'themeCard ';
    if (theme && theme.isDark) {
      themes = themes + 'dark';
    } else {
      themes = themes + 'light';
    }
    return themes;
  }

  getThemeClassForButton(theme: string) {
    let themes = 'themeColorButton ';
    themes = themes + theme;
    return themes;
  }

  ngOnInit() {
  }

  apply(theme: theme) {
    this.selectedTheme = theme.styleName;
    this.closePopup();
  }

  closePopup() {
    this.dialogRef.close(this.selectedTheme);
  }

}
