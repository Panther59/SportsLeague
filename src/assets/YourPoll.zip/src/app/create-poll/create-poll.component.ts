import { Component, OnInit, NgZone, ViewChild } from '@angular/core';
import { Option } from '../_models/option';
import { take } from 'rxjs/operators';
import { Poll } from '../_models/poll';
import { PollPage } from '../_models/pollPage';
import { QuestionGroup } from '../_models/questionGroup';
import { Question } from '../_models/question';
import { PollsService } from '../_services/polls.service';
import { OptionSet } from '../_models/optionSet';
import { CdkTextareaAutosize } from '@angular/cdk/text-field';

@Component({
  selector: 'app-create-poll',
  templateUrl: './create-poll.component.html',
  styleUrls: ['./create-poll.component.scss']
})
export class CreatePollComponent implements OnInit {

  selectedPoll: string;
  pollType: string
  question: string;
  startDate: Date;
  endDate: Date;
  options: Array<Option> = [];
  @ViewChild('autosize') autosize: CdkTextareaAutosize;
  constructor(private ngZone: NgZone,
  private pollsService: PollsService) {
    let today = new Date(Date.now());
    this.startDate = new Date(today);
    let newDate = new Date(today);
    newDate.setDate(today.getDate() + 1);
    this.endDate = newDate;
  }

  ngOnInit() {
  }

  triggerResize() {
    // Wait for changes to be applied, then trigger textarea resize.
    this.ngZone.onStable.pipe(take(1))
      .subscribe(() => this.autosize.resizeToFitContent(true));
  }

  initiateCreation() {
    if (this.selectedPoll) {
      this.pollType = this.selectedPoll;
    }
  }

  addOption() {
    let newOption = new Option();
    this.options.push(newOption);
  }

  async savePoll() {
    if(this.validatePoll()){

      let qus = new Question();
      qus.title = this.question;
      qus.typeId = 1;
      qus.required = true;
      qus.optionSet =new OptionSet();
      qus.optionSet.options = this.options;
      
      let qg = new QuestionGroup();
      qg.title = '';
      qg.questions = [qus];

      let pollPage = new PollPage();
      pollPage.title = '';
      pollPage.questionGroups = [qg];

      let poll = new Poll();
      poll.typeId = 1;
      poll.start =this.startDate;
      poll.end = this.endDate;
      poll.status = 'Active';
      poll.name = this.question;
      poll.pollPages = [pollPage];

      poll = await this.pollsService.createPoll(poll).toPromise();
      this.resetPoll();
    }
  }

  validatePoll(): boolean{
    let result = true;

    return result;
  }

  resetPoll() {
    this.question = '';
    this.options = [];
  }
}
