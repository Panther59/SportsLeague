﻿import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Poll } from '../_models/poll';
import { StorageService } from './storage.service';
import { User } from '../_models/user';

@Injectable()
export class PollsService {
    constructor(
        private storageService: StorageService,
        private httpClient: HttpClient) { }

    getAll(): Observable<Array<Poll>> {
        return this.httpClient.get<Array<Poll>>('api/polls');
    }

    getAllCreatedPolls(user: User): Observable<Array<Poll>> {
        let headers = new HttpHeaders();
        headers = headers.set('Authorization', 'Bearer ' + this.storageService.token);
        return this.httpClient.post<Array<Poll>>('api/polls', user, { headers: headers });
    }

    getPollById(id: number): Observable<Poll> {
        return this.httpClient.get<Poll>('api/polls/' + id);
    }

    getPollResultById(id: number): Observable<Poll> {
        return this.httpClient.get<Poll>('api/polls/result/' + id);
    }

    createPoll(user: Poll): Observable<Poll> {
        let headers = new HttpHeaders();
        headers = headers.set('Authorization', 'Bearer ' + this.storageService.token);
        return this.httpClient.put<Poll>('api/polls/0', user, { headers: headers });
    }

    updatePoll(id: number, user: Poll): Observable<Poll> {
        return this.httpClient.put<Poll>('api/polls/' + id, user);
    }

    deletePoll(id: number): Observable<Poll> {
        return this.httpClient.delete<Poll>('api/polls/' + id);
    }
}