import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Response } from '../_models/response';
import { ResponseRecord } from '../_models/responseRecord';
import { StorageService } from './storage.service';
@Injectable()
export class ResponsesService {
  constructor(
    private storageService: StorageService,
    private httpClient: HttpClient) { }

    getResponseById(id: number): Observable<Response> {
        let headers = new HttpHeaders();
      headers = headers.set('guid', this.storageService.client);
      return this.httpClient.get<Response>('api/responses/poll/' + id, { headers });
    }

    saveResponse(record: Array<ResponseRecord>, pollId: number) : Observable<void> {
      let headers = new HttpHeaders();
      headers = headers.set('guid', this.storageService.client);
      return this.httpClient.put<void>('api/responses/newpoll/' + pollId, record, { headers });
    }
}
