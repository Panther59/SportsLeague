var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { Injectable } from '@angular/core';
import { Guid } from "guid-typescript";
var StorageService = /** @class */ (function () {
    function StorageService() {
        this.currentUserKey = 'currentUser';
        this.tokenKey = 'token';
        this.themeKey = 'theme';
        this.clientKey = 'uuid';
        this.isSocialKey = 'isSocial';
    }
    Object.defineProperty(StorageService.prototype, "currentUser", {
        get: function () {
            return this.getStorageData(this.currentUserKey);
        },
        set: function (user) {
            this.setStorageData(this.currentUserKey, user);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(StorageService.prototype, "isSocial", {
        get: function () {
            return this.getStorageData(this.isSocialKey);
        },
        set: function (isboo) {
            var data = isboo;
            this.setStorageString(this.isSocialKey, data.toString());
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(StorageService.prototype, "client", {
        get: function () {
            var data = this.getStorageString(this.clientKey);
            if (data == null) {
                data = Guid.create().toString();
                this.setStorageString(this.clientKey, data);
            }
            return data;
        },
        set: function (client) {
            this.setStorageString(this.clientKey, client);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(StorageService.prototype, "theme", {
        get: function () {
            return this.getStorageString(this.themeKey);
        },
        set: function (theme) {
            this.setStorageString(this.themeKey, theme);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(StorageService.prototype, "token", {
        get: function () {
            return this.getStorageString(this.tokenKey);
        },
        set: function (token) {
            this.setStorageString(this.tokenKey, token);
        },
        enumerable: true,
        configurable: true
    });
    ;
    StorageService.prototype.getStorageData = function (key) {
        return JSON.parse(localStorage.getItem(key));
    };
    StorageService.prototype.getStorageString = function (key) {
        return localStorage.getItem(key);
    };
    StorageService.prototype.setStorageData = function (key, data) {
        var strData = null;
        if (data != null) {
            strData = JSON.stringify(data);
        }
        this.setStorageString(key, strData);
    };
    StorageService.prototype.setStorageString = function (key, data) {
        if (data == null) {
            localStorage.removeItem(key);
        }
        else {
            localStorage.setItem(key, data);
        }
    };
    StorageService = __decorate([
        Injectable()
    ], StorageService);
    return StorageService;
}());
export { StorageService };
//# sourceMappingURL=storage.service.js.map