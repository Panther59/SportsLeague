﻿import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from '../_models/user';
import { StorageService } from './storage.service';

@Injectable()
export class UserService {
    constructor(
        private storageService: StorageService,
        private httpClient: HttpClient) { }

    getAll(): Observable<Array<User>> {
        return this.httpClient.get<Array<User>>('api/users');
    }

    getCurrentUser(): Observable<User> {
        let headers = new HttpHeaders();
        headers = headers.set('Authorization', 'Bearer ' + this.storageService.token);
        return this.httpClient.get<User>('api/user', { headers });
    }

    getUserById(id: number): Observable<User> {
        return this.httpClient.get<User>('api/users/' + id);
    }

    createUser(user: User): Observable<User> {
        return this.httpClient.put<User>('api/user', user);
    }

    updateUser(id: number, user: User): Observable<User> {
        return this.httpClient.put<User>('api/users/' + id, user);
    }

    deleteUser(id: number): Observable<User> {
        return this.httpClient.delete<User>('api/users/' + id);
    }
}