import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Poll } from '../_models/poll';
import { Question } from '../_models/question';
import { PollsService } from '../_services/polls.service';
import { ResponsesService } from '../_services/responses.service';
import { ResponseRecord } from '../_models/responseRecord';


@Component({
  selector: 'app-view-single-question-poll',
  templateUrl: './view-single-question-poll.component.html',
  styleUrls: ['./view-single-question-poll.component.scss']
})
export class ViewSingleQuestionPollComponent implements OnInit {


  totalVotes: number;

  pollData: Poll;
  get poll(): Poll {
    return this.pollData;
  }
  @Output() pollRefresh = new EventEmitter();


  get question(): Question {
    return this.poll.pollPages[0].questionGroups[0].questions[0];
  }
  @Input('poll')
  set poll(value: Poll) {
    this.pollData = value;
    this.updatePercentages();
  }

  @Input() isPollTaken = false;
  constructor(private responsesService: ResponsesService) { }

  ngOnInit() {
  }

  async saveAnswer(optionId: number) {
    if (this.question && this.poll) {
      const record = new ResponseRecord();
      record.optionId = optionId;
      record.questionId = this.question.id;
      await this.responsesService.saveResponse([record], this.poll.id).toPromise();
      this.pollRefresh.emit();
    }
  }

  updatePercentages() {
    if (this.question) {
      this.totalVotes = this.question.optionSet.options.reduce((x, current) => {
        if (current.voteCount) {
          return x + current.voteCount;
        } else {
          return x;
        }
      }, 0);
      if (this.totalVotes && this.totalVotes > 0) {
        this.question.optionSet.options.forEach(x => {
          if (x.voteCount) {
            x.votePercentage = x.voteCount * 100 / this.totalVotes;
          } else {
            x.votePercentage = 0;
          }
        });
      }
    }
  }

  getDecimalPercentage(data: number, decimalPlaces: number = 0): string {
    return data.toFixed(decimalPlaces);
  }

}
