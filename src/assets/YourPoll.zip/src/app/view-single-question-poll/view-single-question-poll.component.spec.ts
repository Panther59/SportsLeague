import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewSingleQuestionPollComponent } from './view-single-question-poll.component';

describe('ViewSingleQuestionPollComponent', () => {
  let component: ViewSingleQuestionPollComponent;
  let fixture: ComponentFixture<ViewSingleQuestionPollComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewSingleQuestionPollComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewSingleQuestionPollComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
