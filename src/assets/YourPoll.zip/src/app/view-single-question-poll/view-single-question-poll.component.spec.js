import { async, TestBed } from '@angular/core/testing';
import { ViewSingleQuestionPollComponent } from './view-single-question-poll.component';
describe('ViewSingleQuestionPollComponent', function () {
    var component;
    var fixture;
    beforeEach(async(function () {
        TestBed.configureTestingModule({
            declarations: [ViewSingleQuestionPollComponent]
        })
            .compileComponents();
    }));
    beforeEach(function () {
        fixture = TestBed.createComponent(ViewSingleQuestionPollComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should create', function () {
        expect(component).toBeTruthy();
    });
});
//# sourceMappingURL=view-single-question-poll.component.spec.js.map