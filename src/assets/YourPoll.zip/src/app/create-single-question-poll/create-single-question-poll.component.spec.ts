import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateSingleQuestionPollComponent } from './create-single-question-poll.component';

describe('CreateSingleQuestionPollComponent', () => {
  let component: CreateSingleQuestionPollComponent;
  let fixture: ComponentFixture<CreateSingleQuestionPollComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateSingleQuestionPollComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateSingleQuestionPollComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
