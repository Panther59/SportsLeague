import { Component, OnInit, ViewChild, NgZone } from '@angular/core';
import { Router } from '@angular/router';
import { NgBlockUI, BlockUI } from 'ng-block-ui';

import { Option } from '../_models/option';
import { PollsService } from '../_services/polls.service';
import { Poll } from '../_models/poll';
import { PollPage } from '../_models/pollPage';
import { QuestionGroup } from '../_models/questionGroup';
import { OptionSet } from '../_models/optionSet';
import { Question } from '../_models/question';
import { MessageService } from '../_services/message.service';

@Component({
  selector: 'app-create-single-question-poll',
  templateUrl: './create-single-question-poll.component.html',
  styleUrls: ['./create-single-question-poll.component.scss']
})
export class CreateSingleQuestionPollComponent implements OnInit {

  startDate: Date;
  endDate: Date;
  question: Question;
  @BlockUI() blockUI: NgBlockUI;

  constructor(
    private ngZone: NgZone,
    private router: Router,
    private messageService: MessageService,
    private pollsService: PollsService) {

    this.question = new Question();
    let today = new Date(Date.now());
    this.startDate = new Date(today);
    let newDate = new Date(today);
    newDate.setDate(today.getDate() + 1);
    this.endDate = newDate;
  }

  async savePoll() {
    try {
      if (this.validatePoll()) {
        this.blockUI.start("Creating poll...please wait...");
        let qg = new QuestionGroup();
        qg.title = '';
        qg.questions = [this.question];

        let pollPage = new PollPage();
        pollPage.title = '';
        pollPage.questionGroups = [qg];

        let poll = new Poll();
        poll.typeId = 1;
        poll.start = this.startDate;
        poll.end = this.endDate;
        poll.status = 'Active';
        poll.name = this.question.title;
        poll.pollPages = [pollPage];

        poll = await this.pollsService.createPoll(poll).toPromise();
        this.router.navigate['/mypolls'];
      }
    } catch (error) {
      console.error(error);
    }
    finally {
      this.blockUI.stop();
    }
  }

  validatePoll(): boolean {
    let newoptions = this.question.optionSet.options.filter((opt) => opt.title != undefined && opt.title.trim() != '');
    if (this.question == undefined || this.question.title == undefined || this.question.title.trim() == '') {
      this.messageService.showMessage("Poll Create", "Question is required");
      return false;
    } else if (this.endDate < this.startDate) {
      this.messageService.showMessage("Poll Create", "End date can not be less than start date");
      return false;
    } else if (newoptions == undefined || newoptions.length <= 0) {
      this.messageService.showMessage("Poll Create", "Options are required");
      return false;
    } else if (this.hasDuplicates(newoptions)) {
      this.messageService.showMessage("Poll Create", "Duplicate options not allowed");
      return false;
    } else if (newoptions.length < 2) {
      this.messageService.showMessage("Poll Create", "At least 2 options are required");
      return false;
    } else {
      return true;
    }
  }

  hasDuplicates(array: Array<Option>) {
    return (new Set(array)).size !== array.length;
  }

  resetPoll() {
    this.question = new Question()
    this.question.optionSet = new OptionSet();
    this.question.optionSet.options = [];
  }

  ngOnInit() {
  }

}
