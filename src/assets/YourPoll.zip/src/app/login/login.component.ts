import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from '../_services/auth.service';
import { StorageService } from '../_services/storage.service';
import { UserService } from '../_services/user.service';
import { BlockUI, NgBlockUI } from '../../../node_modules/ng-block-ui';
import { AuthService as SocialAuthService, FacebookLoginProvider, GoogleLoginProvider, LinkedinLoginProvider, SocialUser } from 'angular-6-social-login';
import { User } from '../_models/user';
import { WebToken } from '../_models/webToken';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  @BlockUI() blockui: NgBlockUI;
  username: string;
  password: string;
  returnUrl: string;
  constructor(
    private socialAuthService: SocialAuthService,
    private route: ActivatedRoute,
    private router: Router,
    private userService: UserService,
    private storageService: StorageService,
    private authService: AuthService) { }

  async login() {
    try {
      this.blockui.start("Validating...please wait..");
      let token = await this.authService.authenticate(this.username, this.password).toPromise();
      await this.loadUser(token);
    } catch (error) {
      console.error(error);
    }
    finally {
      this.blockui.stop();
    }
  }

  async loadUser(token: WebToken) {
    if (token) {
      this.storageService.token = token.accessToken;
      this.storageService.currentUser = await this.userService.getCurrentUser().toPromise();
      this.router.navigate([this.returnUrl]);
    }
  }

  public async socialSignIn(socialPlatform: string) {
    let socialPlatformProvider;
    if (socialPlatform == "facebook") {
      socialPlatformProvider = FacebookLoginProvider.PROVIDER_ID;
    } else if (socialPlatform == "google") {
      socialPlatformProvider = GoogleLoginProvider.PROVIDER_ID;
    } else if (socialPlatform == "linkedin") {
      socialPlatformProvider = LinkedinLoginProvider.PROVIDER_ID;
    }

    this.socialAuthService.signIn(socialPlatformProvider).then(
      (userData: SocialUser) => {
        console.log(socialPlatform + " sign in data : ", userData);

        let user = new User();
        user.email = userData.email;
        let index = userData.name.indexOf(' ');
        if (index > -1) {
          user.firstName = userData.name.substring(0, index);
          user.lastName = userData.name.substring(index + 1);
        }
        user.token = userData.token;
        this.authService.authenticeSocial(user).subscribe(async (token) => {
          this.storageService.isSocial = true;
          await this.loadUser(token);
          user = this.storageService.currentUser;
          user.imageUrl = userData.image;
          this.storageService.currentUser = user;
        });
      }, (err) => { alert("error"); console.log(err); }
    );
  }

  ngOnInit() {

    // reset login status
    this.authService.logout();

    // get return url from route parameters or default to '/'
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  }
}
