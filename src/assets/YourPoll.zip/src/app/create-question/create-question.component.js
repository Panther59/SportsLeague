var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, ViewChild, NgZone, Input, Output, EventEmitter } from '@angular/core';
import { Option } from '../_models/option';
import { CdkTextareaAutosize } from '@angular/cdk/text-field';
import { Router } from '@angular/router';
import { take } from 'rxjs/operators';
import { Question } from '../_models/question';
import { OptionSet } from '../_models/optionSet';
var CreateQuestionComponent = /** @class */ (function () {
    function CreateQuestionComponent(ngZone, router) {
        this.ngZone = ngZone;
        this.router = router;
        this.remove = new EventEmitter();
        this.initialize();
    }
    CreateQuestionComponent.prototype.initialize = function () {
        if (this.data == undefined) {
            this.data = new Question();
            this.data.optionSet = new OptionSet();
            this.data.optionSet.options = [];
        }
        if (this.data.optionSet.options == undefined) {
            this.data.optionSet.options = [];
        }
    };
    CreateQuestionComponent.prototype.removeQuestion = function () {
        this.remove.emit();
    };
    CreateQuestionComponent.prototype.triggerResize = function () {
        var _this = this;
        // Wait for changes to be applied, then trigger textarea resize.
        this.ngZone.onStable.pipe(take(1))
            .subscribe(function () { return _this.autosize.resizeToFitContent(true); });
    };
    CreateQuestionComponent.prototype.addOption = function () {
        var newOption = new Option();
        if (this.data.optionSet == undefined) {
            this.data.optionSet = new OptionSet();
        }
        if (this.data.optionSet.options == undefined) {
            this.data.optionSet.options = [];
        }
        this.data.optionSet.options.push(newOption);
    };
    CreateQuestionComponent.prototype.ngOnInit = function () {
    };
    __decorate([
        Input(),
        __metadata("design:type", Question)
    ], CreateQuestionComponent.prototype, "data", void 0);
    __decorate([
        ViewChild('autosize'),
        __metadata("design:type", CdkTextareaAutosize)
    ], CreateQuestionComponent.prototype, "autosize", void 0);
    __decorate([
        Output(),
        __metadata("design:type", Object)
    ], CreateQuestionComponent.prototype, "remove", void 0);
    CreateQuestionComponent = __decorate([
        Component({
            selector: 'app-create-question',
            templateUrl: './create-question.component.html',
            styleUrls: ['./create-question.component.scss']
        }),
        __metadata("design:paramtypes", [NgZone,
            Router])
    ], CreateQuestionComponent);
    return CreateQuestionComponent;
}());
export { CreateQuestionComponent };
//# sourceMappingURL=create-question.component.js.map