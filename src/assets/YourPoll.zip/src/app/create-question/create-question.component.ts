import { Component, OnInit, ViewChild, NgZone, Input, Output, EventEmitter } from '@angular/core';
import { Option } from '../_models/option';
import { CdkTextareaAutosize } from '@angular/cdk/text-field';
import { Router } from '@angular/router';
import { take } from 'rxjs/operators';
import { Question } from '../_models/question';
import { OptionSet } from '../_models/optionSet';

@Component({
  selector: 'app-create-question',
  templateUrl: './create-question.component.html',
  styleUrls: ['./create-question.component.scss']
})
export class CreateQuestionComponent implements OnInit {

  @Input() data: Question;
  @ViewChild('autosize') autosize: CdkTextareaAutosize;
  @Output() remove = new EventEmitter();
  constructor(
    private ngZone: NgZone,
    private router: Router) {
    this.initialize();
  }

  initialize() {
    if(this.data == undefined){
      this.data = new Question();
      this.data.optionSet =new OptionSet();
      this.data.optionSet.options = [];
    }

    if(this.data.optionSet.options == undefined){
      this.data.optionSet.options = [];
    }
  }

  removeQuestion(){
    this.remove.emit();
  }

  triggerResize() {
    // Wait for changes to be applied, then trigger textarea resize.
    this.ngZone.onStable.pipe(take(1))
      .subscribe(() => this.autosize.resizeToFitContent(true));
  }

  addOption() {
    let newOption = new Option();
    if(this.data.optionSet == undefined){
      this.data.optionSet = new OptionSet();
    }

    if(this.data.optionSet.options == undefined){
      this.data.optionSet.options = [];
    }
    this.data.optionSet.options.push(newOption);
  }

  ngOnInit() {
  }

}
