import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateMultipleQuestionPollComponent } from './create-multiple-question-poll.component';

describe('CreateMultipleQuestionPollComponent', () => {
  let component: CreateMultipleQuestionPollComponent;
  let fixture: ComponentFixture<CreateMultipleQuestionPollComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateMultipleQuestionPollComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateMultipleQuestionPollComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
