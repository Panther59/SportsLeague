import { Component, OnInit, ViewChild, NgZone } from '@angular/core';
import { Question } from '../_models/question';
import { OptionSet } from '../_models/optionSet';
import { CdkTextareaAutosize } from '@angular/cdk/text-field';
import { NgBlockUI, BlockUI } from 'ng-block-ui';
import { take } from 'rxjs/operators';
import { MessageService } from '../_services/message.service';
import { Option } from '../_models/option';
import { QuestionGroup } from '../_models/questionGroup';
import { PollPage } from '../_models/pollPage';
import { Poll } from '../_models/poll';
import { PollsService } from '../_services/polls.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-multiple-question-poll',
  templateUrl: './create-multiple-question-poll.component.html',
  styleUrls: ['./create-multiple-question-poll.component.scss']
})
export class CreateMultipleQuestionPollComponent implements OnInit {

  pollName: string;
  startDate: Date;
  endDate: Date;
  questions: Array<Question> = [];
  @ViewChild('autosize') autosize: CdkTextareaAutosize;
  @BlockUI() blockUI: NgBlockUI;
  constructor(
    private pollsService: PollsService,
    private router: Router,
    private messageService: MessageService,
    private ngZone: NgZone) {
    this.initialize();
  }

  initialize() {
    this.questions = [];
    let today = new Date(Date.now());
    this.startDate = new Date(today);
    let newDate = new Date(today);
    newDate.setDate(today.getDate() + 1);
    this.endDate = newDate;
  }

  triggerResize() {
    // Wait for changes to be applied, then trigger textarea resize.
    this.ngZone.onStable.pipe(take(1))
      .subscribe(() => this.autosize.resizeToFitContent(true));
  }

  ngOnInit() {
  }

  addQuestion() {
    var newQuestion = new Question();
    newQuestion.title = 'Question Title';
    newQuestion.typeId = 1;
    newQuestion.optionSet = new OptionSet();
    newQuestion.optionSet.questions = [];

    this.questions.push(newQuestion);
  }

  removeQuesion(quesion: Question) {
    var index = this.questions.indexOf(quesion);
    if (index > -1) {
      this.questions = this.questions.filter((q, i) => i != index);
    }
  }

  async savePoll() {
    try {
      if (this.validatePoll()) {
        this.blockUI.start("Creating poll...please wait...");
        let qg = new QuestionGroup();
        qg.title = '';
        qg.questions = this.questions;

        let pollPage = new PollPage();
        pollPage.title = '';
        pollPage.questionGroups = [qg];

        let poll = new Poll();
        poll.typeId = 2;
        poll.start = this.startDate;
        poll.end = this.endDate;
        poll.status = 'Active';
        poll.name = this.pollName;
        poll.pollPages = [pollPage];

        poll = await this.pollsService.createPoll(poll).toPromise();
        this.router.navigate['/mypolls'];
      }
    } catch (error) {
      console.error(error);
    }
    finally {
      this.blockUI.stop();
    }
  }

  showMessage(message: string) {
    this.messageService.showMessage("Create Poll", message);
  }

  validatePoll(): boolean {
    if (this.pollName == undefined || this.pollName.trim() == '') {
      this.showMessage("Poll Name is required");
      return false;
    } else if (this.pollName == undefined || this.pollName.trim() == '') {
      this.showMessage("Poll Name is required");
      return false;
    } else if (this.questions.every(q => this.validateQuestion(q)) == false) {
      return false;
    } else {
      return true;
    }
  }

  validateQuestion(question: Question): boolean {
    let newoptions = question.optionSet.options.filter((opt) => opt.title != undefined && opt.title.trim() != '');
    if (question == undefined || question.title == undefined || question.title.trim() == '') {
      this.messageService.showMessage("Poll Create", "Question is required");
      return false;
    } else if (newoptions == undefined || newoptions.length <= 0) {
      this.messageService.showMessage("Poll Create", "Options are required");
      return false;
    } else if (this.hasDuplicates(newoptions)) {
      this.messageService.showMessage("Poll Create", "Duplicate options not allowed");
      return false;
    } else if (newoptions.length < 2) {
      this.messageService.showMessage("Poll Create", "At least 2 options are required");
      return false;
    } else {
      return true;
    }
  }

  hasDuplicates(array: Array<Option>) {
    return (new Set(array)).size !== array.length;
  }

  resetPoll() {
    this.initialize();
  }

}
