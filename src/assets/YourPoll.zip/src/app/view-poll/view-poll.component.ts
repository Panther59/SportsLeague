import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NgBlockUI, BlockUI } from 'ng-block-ui';
import { PollsService } from '../_services/polls.service';
import { Poll } from '../_models/poll';
import { ResponsesService } from '../_services/responses.service';

@Component({
  selector: 'app-view-poll',
  templateUrl: './view-poll.component.html',
  styleUrls: ['./view-poll.component.scss']
})
export class ViewPollComponent implements OnInit {
  poll: Poll;
  isPollTaken: boolean = false;
  @BlockUI() blockUI: NgBlockUI;
  constructor(
    private route: ActivatedRoute,
    private responsesService: ResponsesService,
    private pollService: PollsService) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      let pollId = +params['id'];
      this.loadPollDetail(pollId);
    });
  }

  async loadPollDetail(id: number) {
    try {
      this.blockUI.start("Loading poll detail...please wait...");
      var response = await this.responsesService.getResponseById(id).toPromise();
      if (response && response.id) {
        this.isPollTaken = true;
        this.poll = await this.pollService.getPollResultById(id).toPromise();
      }
      else {
        this.poll = await this.pollService.getPollById(id).toPromise();
      }
    }
    catch (ex) {
      console.error(ex);
    }
    finally {
      this.blockUI.stop();
    }
  }

  async pollRefresh(){
    await this.loadPollDetail(this.poll.id);
  }

}
