﻿// <copyright file="Constants.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>30-07-2017</date>

namespace CodeFormatter.Common
{
    /// <summary>
    /// Defines the <see cref = "Constants"/>
    /// </summary>
    public class Constants
    {
        #region Constants

        /// <summary>
        /// Defines the AccessModifier
        /// </summary>
        public const string AccessModifier = "Access Modifier";

        /// <summary>
        /// Defines the And
        /// </summary>
        public const string And = "And";

        /// <summary>
        /// Defines the FieldCommentRegex
        /// </summary>
        public const string FieldCommentRegex = @"\/\/\/.\<summary\>.*\n.*\/\/\/.Defines the ((\w|\S)*)\s*\n.*\/\/\/.*\<\/summary\>";

        /// <summary>
        /// Defines the IsStatic
        /// </summary>
        public const string IsStatic = "Is Static";

        /// <summary>
        /// Defines the Kind
        /// </summary>
        public const string Kind = "Kind";

        /// <summary>
        /// Defines the Member
        /// </summary>
        public const string Member = "Member";

        /// <summary>
        /// Defines the Model
        /// </summary>
        public const string Model = "Model";

        /// <summary>
        /// Defines the Name
        /// </summary>
        public const string Name = "Name";

        /// <summary>
        /// Defines the Or
        /// </summary>
        public const string Or = "Or";

        /// <summary>
        /// Defines the PropertyCommentRegex
        /// </summary>
        public const string PropertyCommentRegex = @"\/\/\/.\<summary\>.*\n.*\/\/\/.{0}.((.|\n)*)\s*\n.*\/\/\/.*\<\/summary\>";

        /// <summary>
        /// Defines the PropertyDefaultCommentRegex
        /// </summary>
        public const string PropertyDefaultCommentRegex = @"\/\/\/.\<summary\>.*\n.*\/\/\/.{0}.((\w|\S)*)\s*\n.*\/\/\/.*\<\/summary\>";

        /// <summary>
        /// Defines the ReadOnly
        /// </summary>
        public const string ReadOnly = "Read Only";

        /// <summary>
        /// Defines the Static
        /// </summary>
        public const string Static = "Static";

        /// <summary>
        /// Defines the SummaryCommentRegex
        /// </summary>
        public const string SummaryCommentRegex = @"\/\/\/.\<summary\>.*\n.*\/\/\/((.|\n)*)\n.*\/\/\/.*\<\/summary\>";

        /// <summary>
        /// Defines the Type
        /// </summary>
        public const string Type = "Type";

        /// <summary>
        /// Defines the VM
        /// </summary>
        public const string VM = "ViewModel";

        #endregion
    }
}
