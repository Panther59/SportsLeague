﻿// <copyright file="BaseViewModel.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>30-07-2017</date>

namespace CodeFormatter.Common.Entities
{
    using Ayvan.ErrorLogger;
    using System;
    using System.ComponentModel;

    /// <summary>
    /// Defines the <see cref = "BaseViewModel"/>
    /// </summary>
    public abstract class BaseViewModel : INotifyPropertyChanged
    {
        #region Events

        /// <summary>
        /// Defines the PropertyChanged
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// The LogException
        /// </summary>
        /// <param name="ex">The <see cref="Exception"/></param>
        public void LogException(Exception ex)
        {
            ErrorLog.LogException(ex);
        }

        /// <summary>
        /// The OnPropertyChanged
        /// </summary>
        /// <param name = "propertyName">The <see cref = "string "/></param>
        public void OnPropertyChanged(string propertyName)
        {
            this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion

        #endregion
    }
}