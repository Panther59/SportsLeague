﻿// <copyright file="RelayCommand.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>30-07-2017</date>

namespace CodeFormatter.Common.Entities
{
    using System;
    using System.Diagnostics;
    using System.Windows.Input;

    /// <summary>
    /// Defines the <see cref = "RelayCommand"/>
    /// </summary>
    public class RelayCommand : ICommand
    {
        /// <summary>
        /// Defines the _canExecute
        /// </summary>
        internal readonly Predicate<object> _canExecute;
        /// <summary>
        /// Defines the _execute
        /// </summary>
        internal readonly Action<object> _execute;
        /// <summary>
        /// Initializes a new instance of the <see cref = "RelayCommand"/> class.
        /// </summary>
        /// <param name = "execute">The <see cref = "Action{object}"/></param>
        public RelayCommand(Action<object> execute) : this(execute, null)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref = "RelayCommand"/> class.
        /// </summary>
        /// <param name = "execute">The <see cref = "Action{object}"/></param>
        /// <param name = "canExecute">The <see cref = "Predicate{object}"/></param>
        public RelayCommand(Action<object> execute, Predicate<object> canExecute)
        {
            if (execute == null)
                throw new ArgumentNullException("execute");
            _execute = execute;
            _canExecute = canExecute;
        }

        /// <summary>
        /// The CanExecute
        /// </summary>
        /// <param name = "parameter">The <see cref = "object "/></param>
        /// <returns>The <see cref = "bool "/></returns>
        [DebuggerStepThrough]
        public bool CanExecute(object parameter)
        {
            return _canExecute == null ? true : _canExecute(parameter);
        }

        /// <summary>
        /// The Execute
        /// </summary>
        /// <param name = "parameter">The <see cref = "object "/></param>
        public void Execute(object parameter)
        {
            _execute(parameter);
        }

        public event EventHandler CanExecuteChanged
        {
            add
            {
                CommandManager.RequerySuggested += value;
            }

            remove
            {
                CommandManager.RequerySuggested -= value;
            }
        }
    }

    /// <summary>
    /// Defines the <see cref = "RelayCommand{T}"/>
    /// </summary>
    /// <typeparam name = "T"></typeparam>
    public class RelayCommand<T> : ICommand
    {
        /// <summary>
        /// Defines the canExecute
        /// </summary>
        private readonly Predicate<T> canExecute;
        /// <summary>
        /// Defines the execute
        /// </summary>
        private readonly Action<T> execute;
        /// <summary>
        /// Initializes a new instance of the <see cref = "RelayCommand{T}"/> class.
        /// </summary>
        /// <param name = "execute">The <see cref = "Action{T}"/></param>
        public RelayCommand(Action<T> execute) : this(execute, null)
        {
        }

        /// <exception cref = "ArgumentNullException"><paramref name = "execute"/> is <c>null</c>.</exception> 
        public RelayCommand(Action<T> execute, Predicate<T> canExecute)
        {
            if (execute == null)
            {
                throw new ArgumentNullException("execute");
            }

            this.execute = execute;
            this.canExecute = canExecute;
        }

        /// <summary>
        /// The CanExecute
        /// </summary>
        /// <param name = "parameter">The <see cref = "object "/></param>
        /// <returns>The <see cref = "bool "/></returns>
        [DebuggerStepThrough]
        public bool CanExecute(object parameter)
        {
            return canExecute == null ? true : canExecute((T)parameter);
        }

        /// <summary>
        /// The Execute
        /// </summary>
        /// <param name = "parameter">The <see cref = "object "/></param>
        public void Execute(object parameter)
        {
            execute((T)parameter);
        }

        public event EventHandler CanExecuteChanged
        {
            add
            {
                CommandManager.RequerySuggested += value;
            }

            remove
            {
                CommandManager.RequerySuggested -= value;
            }
        }
    }
}