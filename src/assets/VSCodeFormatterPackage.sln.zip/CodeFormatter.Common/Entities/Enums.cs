﻿// <copyright file="Enums.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>30-07-2017</date>

namespace CodeFormatter.Common.Entities
{
    /// <summary>
    /// Defines the MemberKinds
    /// </summary>
    public enum MemberKinds
    {
        /// <summary>
        /// Defines the Constants
        /// </summary>
        Constants = 1,

        /// <summary>
        /// Defines the Fields
        /// </summary>
        Fields = 2,

        /// <summary>
        /// Defines the Constructors
        /// </summary>
        Constructors = 4,

        /// <summary>
        /// Defines the Destructors
        /// </summary>
        Destructors = 8,

        /// <summary>
        /// Defines the Delegates
        /// </summary>
        Delegates = 16,

        /// <summary>
        /// Defines the Events
        /// </summary>
        Events = 32,

        /// <summary>
        /// Defines the Enums
        /// </summary>
        Enums = 64,

        /// <summary>
        /// Defines the Interfaces
        /// </summary>
        Interfaces = 128,

        /// <summary>
        /// Defines the Properties
        /// </summary>
        Properties = 256,

        /// <summary>
        /// Defines the Indexers
        /// </summary>
        Indexers = 512,

        /// <summary>
        /// Defines the Methods
        /// </summary>
        Methods = 1024,

        /// <summary>
        /// Defines the Structs
        /// </summary>
        Structs = 2048,

        /// <summary>
        /// Defines the Classes
        /// </summary>
        Classes = 4096,

        /// <summary>
        /// Defines the Namespaces
        /// </summary>
        Namespaces = 8192,
    }
}