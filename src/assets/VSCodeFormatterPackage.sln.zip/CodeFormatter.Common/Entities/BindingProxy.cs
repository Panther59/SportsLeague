﻿// <copyright file="BindingProxy.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>30-07-2017</date>

namespace CodeFormatter.Common.Entities
{
    using System.Windows;

    /// <summary>
    /// Defines the <see cref="BindingProxy" />
    /// </summary>
    public class BindingProxy : Freezable
    {
        #region Fields

        /// <summary>
        /// Defines the DataProperty
        /// </summary>
        public static readonly DependencyProperty DataProperty = DependencyProperty.Register("Data", typeof(object), typeof(BindingProxy), new UIPropertyMetadata(CallBack));

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the Data
        /// </summary>
        public object Data
        {
            get
            {
                return (object)GetValue(DataProperty);
            }

            set
            {
                SetValue(DataProperty, value);
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// The CreateInstanceCore
        /// </summary>
        /// <returns>The <see cref="Freezable"/></returns>
        protected override Freezable CreateInstanceCore()
        {
            return new BindingProxy();
        }

        #region Private Methods

        /// <summary>
        /// The CallBack
        /// </summary>
        /// <param name="d">The <see cref="DependencyObject"/></param>
        /// <param name="e">The <see cref="DependencyPropertyChangedEventArgs"/></param>
        private static void CallBack(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
        }

        #endregion

        #endregion
    }
}