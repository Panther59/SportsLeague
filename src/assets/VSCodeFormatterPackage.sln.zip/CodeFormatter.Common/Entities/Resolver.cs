// <copyright file="Resolver.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>30-07-2017</date>

namespace CodeFormatter.Common.Entities
{
    using System.Collections.Generic;
    using Contracts;
    using Unity;

    /// <summary>
    /// Defines the <see cref = "Resolver"/>
    /// </summary>
    public class Resolver : IResolver
    {
        #region Fields

        /// <summary>
        /// Defines the container
        /// </summary>
        private readonly UnityContainer container;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "Resolver"/> class.
        /// </summary>
        /// <param name = "package">The extension package</param>
        public Resolver(UnityContainer container)
        {
            this.container = container;
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <inheritdoc/>
        public T Resolve<T>()
        {
            return this.container.Resolve<T>();
        }

        /// <inheritdoc/>
        public T Resolve<T>(string key)
        {
            return this.container.Resolve<T>(key);
        }

        /// <inheritdoc/>
        public IEnumerable<T> ResolveAll<T>()
        {
            return this.container.ResolveAll<T>();
        }

        #endregion

        #endregion
    }
}
