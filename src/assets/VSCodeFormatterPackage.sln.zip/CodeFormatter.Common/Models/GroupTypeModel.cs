namespace CodeFormatter.Common.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;

    /// <summary>
    /// Defines the <see cref = "GroupTypeModel"/>
    /// </summary>
    public class GroupTypeModel : INotifyPropertyChanged
    {
        #region Fields

        /// <summary>
        /// The name field
        /// </summary>
        private string name;

        /// <summary>
        /// The types field
        /// </summary>
        private string types;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="GroupTypeModel"/> class.
        /// </summary>
        public GroupTypeModel()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref = "GroupTypeModel"/> class.
        /// </summary>
        /// <param name = "name">The <see cref = "string "/></param>
        /// <param name = "types">The <see cref = "string "/></param>
        public GroupTypeModel(string name, string types) : this()
        {
            this.Name = name;
            this.Types = types;
        }

        #endregion

        #region Events

        /// <summary>
        /// Defines the PropertyChanged
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the Name
        /// </summary>
        public string Name
        {
            get
            {
                return this.name;
            }

            set
            {
                this.name = value;
                this.OnPropertyChanged("Name");
            }
        }

        /// <summary>
        /// Gets or sets the Types
        /// </summary>
        public string Types
        {
            get
            {
                return this.types;
            }

            set
            {
                this.types = value;
                this.OnPropertyChanged("Types");
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// The GetTypes
        /// </summary>
        /// <returns>The <see cref = "List{string}"/></returns>
        public List<string> GetTypes()
        {
            if (this.Types == null)
            {
                return null;
            }

            return this.Types.Split(',').Where(x => x != null && string.IsNullOrEmpty(x.Trim()) == false).Select(y => y.Trim()).ToList();
        }

        /// <summary>
        /// Raises property changed event with the property name
        /// </summary>
        /// <param name = "propertyName">The property name</param>
        private void OnPropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public static string ToFullString(List<GroupTypeModel> input)
        {
            string output = null;
            if (input != null)
            {
                output = string.Empty;
                foreach (var item in input)
                {
                    if (string.IsNullOrEmpty(item.name) == false && string.IsNullOrEmpty(item.Types) == false)
                    {
                        output += string.Format("{0}({1}){2}", item.Name, item.Types, Environment.NewLine);
                    }
                }

                output = output.Trim();
            }

            return output;
        }

        public static List<GroupTypeModel> ParseCollection(string input)
        {
            List<GroupTypeModel> output = null;
            if (string.IsNullOrEmpty(input) == false)
            {
                var parts = input.Replace("\r\n", "\n").Split('\n');
                output = parts.Select(y => GroupTypeModel.Parse(y)).Where(z => z != null).ToList();
            }

            return output;
        }

        private static GroupTypeModel Parse(string input)
        {
            GroupTypeModel output = null;
            if (string.IsNullOrEmpty(input) == false)
            {
                var parts = input.Replace(")", string.Empty).Split('(');
                if (parts.Length == 2 &&
                    string.IsNullOrEmpty(parts[0]) == false &&
                    string.IsNullOrEmpty(parts[1]) == false)
                {
                    output = new GroupTypeModel(parts[0], parts[1]);
                }
            }

            return output;
        }

        #endregion
    }
}
