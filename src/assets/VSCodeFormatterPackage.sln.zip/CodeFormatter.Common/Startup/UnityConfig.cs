// <copyright file="UnityConfig.cs" company="Avanade">
// Copyright (c) 17 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>29-07-2017</date>

namespace CodeFormatter.Common.Startup
{
    using Contracts;
    using Entities;
    using Unity;

    /// <summary>
    /// Defines the <see cref = "UnityConfig"/>
    /// </summary>
    public static class UnityConfig
    {
        #region Methods

        #region Public Methods

        /// <summary>
        /// The RegisterTypes
        /// </summary>
        /// <param name = "container">The <see cref = "IUnityContainer"/></param>
        public static void RegisterTypes(IUnityContainer container)
        {
            container.RegisterType<IResolver, Resolver>();
        }

        #endregion

        #endregion
    }
}
