// <copyright file="IResolver.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>30-07-2017</date>

namespace CodeFormatter.Common.Contracts
{
    using System.Collections.Generic;

    #region Interfaces

    /// <summary>
    /// Defines the <see cref = "IResolver"/>
    /// </summary>
    public interface IResolver
    {
        #region Methods

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        T Resolve<T>();

        /// <summary>
        /// The Resolve
        /// </summary>
        /// <param name="key">The <see cref="string"/></param>
        /// <returns>The <see cref="T"/></returns>
        T Resolve<T>(string key);

        /// <summary>
        /// The ResolveAll
        /// </summary>
        /// <returns>The <see cref="IEnumerable{T}"/></returns>
        IEnumerable<T> ResolveAll<T>();

        #endregion
    }

    #endregion
}
