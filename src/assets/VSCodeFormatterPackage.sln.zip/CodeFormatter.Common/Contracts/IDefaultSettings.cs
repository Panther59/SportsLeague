// <copyright file="IDefaultSettings.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>30-07-2017</date>

namespace CodeFormatter.Common.Contracts
{
    #region Interfaces

    /// <summary>
    /// Defines the <see cref = "IDefaultSettings"/>
    /// </summary>
    public interface IDefaultSettings
    {
        #region Properties

        /// <summary>
        /// Gets a value indicating whether AddClassHeader
        /// </summary>
        bool AddClassHeader
        {
            get;
        }

        /// <summary>
        /// Gets a value indicating whether AddConstructorHeader
        /// </summary>
        bool AddConstructorHeader
        {
            get;
        }

        /// <summary>
        /// Gets a value indicating whether AddDelegateHeader
        /// </summary>
        bool AddDelegateHeader
        {
            get;
        }

        /// <summary>
        /// Gets a value indicating whether AddEnumHeader
        /// </summary>
        bool AddEnumHeader
        {
            get;
        }

        /// <summary>
        /// Gets a value indicating whether AddEventHeader
        /// </summary>
        bool AddEventHeader
        {
            get;
        }

        /// <summary>
        /// Gets a value indicating whether AddFieldHeader
        /// </summary>
        bool AddFieldHeader
        {
            get;
        }

        /// <summary>
        /// Gets a value indicating whether AddMethodHeader
        /// </summary>
        bool AddMethodHeader
        {
            get;
        }

        /// <summary>
        /// Gets a value indicating whether AddMissingAccessModifier
        /// </summary>
        bool AddMissingAccessModifier
        {
            get;
        }

        /// <summary>
        /// Gets a value indicating whether AddPropertyHeader
        /// </summary>
        bool AddPropertyHeader
        {
            get;
        }

        /// <summary>
        /// Gets the DefaultAccessModifier
        /// </summary>
        string DefaultAccessModifier
        {
            get;
        }

        /// <summary>
        /// Gets or sets a value indicating whether IsFirstLaunch
        /// </summary>
        bool IsFirstLaunch
        {
            get;
            set;
        }

        /// <summary>
        /// Gets a value indicating whether MoveUsingInsideNamespace
        /// </summary>
        bool MoveUsingInsideNamespace
        {
            get;
        }

        /// <summary>
        /// Gets a value indicating whether RemoveUnwantedUsings
        /// </summary>
        bool RemoveUnwantedUsings
        {
            get;
        }

        /// <summary>
        /// Gets a value indicating whether StatementFixes
        /// </summary>
        bool StatementFixes
        {
            get;
        }

        #endregion

        #region Methods

        /// <summary>
        /// The Save
        /// </summary>
        void Save();

        #endregion
    }

    #endregion
}
