﻿// <copyright file="IFileHeaderSettings.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>30-07-2017</date>

namespace CodeFormatter.Common.Contracts
{
    /// <summary>
    /// Defines the <see cref = "IFileHeaderSettings"/>
    /// </summary>
    public interface IFileHeaderSettings
    {
        #region Properties

        /// <summary>
        /// Gets or sets a value indicating whether AddFileHeader
        /// </summary>
        bool AddFileHeader
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets Header
        /// </summary>
        string Header
        {
            get;
            set;
        }

        #endregion
    }
}