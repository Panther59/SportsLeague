# Code Formatter

<!-- Replace this badge with your own-->
[![Build status](https://ci.appveyor.com/api/projects/status/hv6uyc059rqbc6fj?svg=true)](https://ci.appveyor.com/project/madskristensen/extensibilitytools)

<!-- Update the VS Gallery link after you upload the VSIX-->
Download this extension from the [VS Gallery](https://visualstudiogallery.msdn.microsoft.com/[GuidFromGallery])
or get the [CI build](http://vsixgallery.com/extension/17127020-d0c0-4d46-89ac-2b4eab61be4e/).

---------------------------------------

Format the class file and arrange fields, properties and methods as per StyleCop.

## Features

- Format the class file (.cs) to arrange members of class in the proper order.
- Using statements are brought inside namespace block.
- Unwanted namespaces are removed.
- Unwanted space are removed.
- Proper space introduced where ever required.

### Feature Format class
Members of the class are arranged in following order
 - Constants
 - Fields
 - Constructors
 - Properties
 - Methods

Furthermre the members are also sorted by access modifers as follows
 - public
 - internal
 - protected
 - private

You can access these command from two different places.

1. Right click on any class file(s) as follows.
![File Formatter Solution Explorer Command](CodeFormatter/Resources/FileFormatterSolutionExplorerCommand.png)

2. Right click on code window as follows.
![File Formatter Code Window Command](CodeFormatter/Resources/FileFormatterCodeWindowCommand.png)

## Contribute
Check out the [contribution guidelines](CONTRIBUTING.md)
if you want to contribute to this project.

For cloning and building this project yourself, make sure
to install the
[Extensibility Tools 2015](https://visualstudiogallery.msdn.microsoft.com/ab39a092-1343-46e2-b0f1-6a3f91155aa6)
extension for Visual Studio which enables some features
used by this project.

## License
[Apache 2.0](LICENSE)