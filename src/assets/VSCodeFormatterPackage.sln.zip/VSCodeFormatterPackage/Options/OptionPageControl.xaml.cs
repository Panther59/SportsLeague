﻿// <copyright file="OptionPageControl.xaml.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>30-07-2017</date>

namespace VSCodeFormatterPackage.Options
{
    using CodeFormatter.Core.Views.Settings;
    using System;
    using System.Windows;
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for OptionPageControl.xaml
    /// </summary>
    public partial class OptionPageControl : UserControl
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "OptionPageControl"/> class.
        /// </summary>
        public OptionPageControl()
        {
            InitializeComponent();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the OptionPage
        /// </summary>
        public FileFormatterOptionPage OptionPage
        {
            get;
            set;
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// The Initialize
        /// </summary>
        public void Initialize()
        {
            this.DataContext = OptionPage;
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// The TypeLayoutSettingButton_Click
        /// </summary>
        /// <param name = "sender">The <see cref = "object "/></param>
        /// <param name = "e">The <see cref = "RoutedEventArgs"/></param>
        private void SettingButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ResourceDictionary myResourceDictionary = new ResourceDictionary();
                myResourceDictionary.Source = new Uri(@"/VSCodeFormatterPackage;component/MainResourceDictionary.xaml", UriKind.RelativeOrAbsolute);
                SettingsWindow window = new SettingsWindow();
                window.Owner = Application.Current.MainWindow;
                window.Resources.MergedDictionaries.Add(myResourceDictionary);
                window.ShowDialog();
            }
            catch (Exception)
            {
            }
        }

        #endregion

        #endregion
    }
}