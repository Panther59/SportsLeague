namespace VSCodeFormatterPackage.Options
{
    using CodeFormatter.Common.Contracts;

    /// <summary>
    /// Defines the <see cref = "Settings"/>
    /// </summary>
    public class Settings : ISettings
    {
        #region Fields

        /// <summary>
        /// Defines the package
        /// </summary>
        private readonly VSPackage package;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "Settings"/> class.
        /// </summary>
        /// <param name = "package">The extension package</param>
        public Settings(VSPackage package)
        {
            this.package = package;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets a value indicating whether AddClassHeader
        /// </summary>
        public bool AddClassHeader
        {
            get
            {
                FileFormatterOptionPage page = (FileFormatterOptionPage)this.package.GetDialogPage(typeof(FileFormatterOptionPage));
                return page.AddClassHeader;
            }
        }

        /// <summary>
        /// Gets a value indicating whether AddConstructorHeader
        /// </summary>
        public bool AddConstructorHeader
        {
            get
            {
                FileFormatterOptionPage page = (FileFormatterOptionPage)this.package.GetDialogPage(typeof(FileFormatterOptionPage));
                return page.AddConstructorHeader;
            }
        }

        /// <summary>
        /// Gets a value indicating whether AddDelegateHeader
        /// </summary>
        public bool AddDelegateHeader
        {
            get
            {
                FileFormatterOptionPage page = (FileFormatterOptionPage)this.package.GetDialogPage(typeof(FileFormatterOptionPage));
                return page.AddDelegateHeader;
            }
        }

        /// <summary>
        /// Gets a value indicating whether AddFieldHeader
        /// </summary>
        public bool AddFieldHeader
        {
            get
            {
                FileFormatterOptionPage page = (FileFormatterOptionPage)this.package.GetDialogPage(typeof(FileFormatterOptionPage));
                return page.AddFieldHeader;
            }
        }

        /// <summary>
        /// Gets a value indicating whether AddMethodHeader
        /// </summary>
        public bool AddMethodHeader
        {
            get
            {
                FileFormatterOptionPage page = (FileFormatterOptionPage)this.package.GetDialogPage(typeof(FileFormatterOptionPage));
                return page.AddMethodHeader;
            }
        }

        /// <summary>
        /// Gets a value indicating whether AddMissingAccessModifier
        /// </summary>
        public bool AddMissingAccessModifier
        {
            get
            {
                FileFormatterOptionPage page = (FileFormatterOptionPage)this.package.GetDialogPage(typeof(FileFormatterOptionPage));
                return page.AddMissingAccessModifier;
            }
        }

        /// <summary>
        /// Gets a value indicating whether AddPropertyHeader
        /// </summary>
        public bool AddPropertyHeader
        {
            get
            {
                FileFormatterOptionPage page = (FileFormatterOptionPage)this.package.GetDialogPage(typeof(FileFormatterOptionPage));
                return page.AddPropertyHeader;
            }
        }

        /// <summary>
        /// Gets the DefaultAccessModifer
        /// </summary>
        public string DefaultAccessModifier
        {
            get
            {
                FileFormatterOptionPage page = (FileFormatterOptionPage)this.package.GetDialogPage(typeof(FileFormatterOptionPage));
                return page.DefaultAccessModifier;
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether IsFirstLaunch
        /// </summary>
        public bool IsFirstLaunch
        {
            get
            {
                FileFormatterOptionPage page = (FileFormatterOptionPage)this.package.GetDialogPage(typeof(FileFormatterOptionPage));
                return page.IsFirstLaunch;
            }

            set
            {
                FileFormatterOptionPage page = (FileFormatterOptionPage)this.package.GetDialogPage(typeof(FileFormatterOptionPage));
                page.IsFirstLaunch = value;
                page.SaveSettingsToStorage();
            }
        }

        /// <summary>
        /// Gets a value indicating whether MoveUsingInsideNamespace
        /// </summary>
        public bool MoveUsingInsideNamespace
        {
            get
            {
                FileFormatterOptionPage page = (FileFormatterOptionPage)this.package.GetDialogPage(typeof(FileFormatterOptionPage));
                return page.MoveUsingInsideNamespace;
            }
        }

        /// <summary>
        /// Gets a value indicating whether RemoveUnwantedUsings
        /// </summary>
        public bool RemoveUnwantedUsings
        {
            get
            {
                FileFormatterOptionPage page = (FileFormatterOptionPage)this.package.GetDialogPage(typeof(FileFormatterOptionPage));
                return page.RemoveUnwantedUsings;
            }
        }

        #endregion
    }
}
