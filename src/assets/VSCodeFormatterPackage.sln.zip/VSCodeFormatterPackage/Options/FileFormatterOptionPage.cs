// <copyright file="FileFormatterOptionPage.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>30-07-2017</date>

namespace VSCodeFormatterPackage.Options
{
    using Microsoft.VisualStudio.Shell;
    using System;
    using System.Runtime.InteropServices;
    using System.Windows.Forms;
    using System.Windows.Forms.Integration;

    /// <summary>
    /// Defines the <see cref = "FileFormatterOptionPage"/>
    /// </summary>
    [Guid("131625E7-F433-433E-9387-BB7CBE5BE083")]
    public class FileFormatterOptionPage : DialogPage
    {
        #region Properties

        /// <summary>
        /// Gets  the Window
        /// </summary>
        protected override IWin32Window Window
        {
            get
            {
                OptionPageControl page = new OptionPageControl();
                page.OptionPage = this;
                page.Initialize();
                System.Windows.Forms.UserControl user = new UserControl();
                // Create the ElementHost control for hosting the
                // WPF UserControl.
                ElementHost host = new ElementHost();
                host.Dock = DockStyle.Fill;
                // Assign the WPF UserControl to the ElementHost control's
                // Child property.
                host.Child = page;
                // Add the ElementHost control to the form's
                // collection of child controls.
                user.Controls.Add(host);
                return user;
            }
        }

        #endregion
    }
}