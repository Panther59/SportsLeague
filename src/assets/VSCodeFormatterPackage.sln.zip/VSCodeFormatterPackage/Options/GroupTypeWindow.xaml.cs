﻿namespace VSCodeFormatterPackage.Options
{
    using CodeFormatter.Common.Entities;
    using CodeFormatter.Common.Models;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Windows;

    /// <summary>
    /// Interaction logic for GroupTypeWindow.xaml
    /// </summary>
    public partial class GroupTypeWindow : Window, INotifyPropertyChanged
    {
        #region Fields

        /// <summary>
        /// The customGroupTypes field
        /// </summary>
        private List<GroupTypeModel> customGroupTypes;

        /// <summary>
        /// The removeGroupTypeCommand field
        /// </summary>
        private RelayCommand<GroupTypeModel> removeGroupTypeCommand;

        #region Commands

        /// <summary>
        /// The addGroupTypeCommand field
        /// </summary>
        private RelayCommand addGroupTypeCommand;

        #endregion

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "GroupTypeWindow"/> class.
        /// </summary>
        public GroupTypeWindow()
        {
            InitializeComponent();
            this.Loaded += this.GroupTypeWindow_Loaded;
        }

        #endregion

        #region Events

        /// <inheritdoc/>
        public event PropertyChangedEventHandler PropertyChanged;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the CustomGroupTypes
        /// </summary>
        public List<GroupTypeModel> CustomGroupTypes
        {
            get
            {
                return this.customGroupTypes;
            }

            set
            {
                this.customGroupTypes = value;
                this.OnPropertyChanged("CustomGroupTypes");
            }
        }

        /// <summary>
        /// Gets the RemoveGroupTypeCommand
        /// </summary>
        public RelayCommand<GroupTypeModel> RemoveGroupTypeCommand
        {
            get
            {
                if (this.removeGroupTypeCommand == null)
                {
                    this.removeGroupTypeCommand = new RelayCommand<GroupTypeModel>(command => this.ExecuteRemoveGroupType(command));
                }

                return this.removeGroupTypeCommand;
            }
        }

        #region Commands

        /// <summary>
        /// Gets the AddGroupTypeCommand
        /// </summary>
        public RelayCommand AddGroupTypeCommand
        {
            get
            {
                if (this.addGroupTypeCommand == null)
                {
                    this.addGroupTypeCommand = new RelayCommand(command => this.ExecuteAddGroupType(), can => this.CanAddGroupTypeExecute());
                }

                return this.addGroupTypeCommand;
            }
        }

        #endregion

        #endregion

        #region Methods

        /// <summary>
        /// Determines whether AddGroupType can be executed or not
        /// </summary>
        private bool CanAddGroupTypeExecute()
        {
            return true;
        }

        /// <summary>
        /// The CloseButton_Click
        /// </summary>
        /// <param name = "sender">The <see cref = "object "/></param>
        /// <param name = "e">The <see cref = "RoutedEventArgs"/></param>
        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.CustomGroupTypes = null;
            this.Close();
        }

        /// <summary>
        /// Executes AddGroupType
        /// </summary>
        private void ExecuteAddGroupType()
        {
            var list = this.CustomGroupTypes;
            if (list == null)
            {
                list = new List<GroupTypeModel>();
            }

            list.Add(new GroupTypeModel());
            this.CustomGroupTypes = new List<GroupTypeModel>(list);
        }

        /// <summary>
        /// Executes RemoveGroupType
        /// </summary>
        private void ExecuteRemoveGroupType(GroupTypeModel input)
        {
            var list = this.CustomGroupTypes;
            list.Remove(input);
            this.CustomGroupTypes = new List<GroupTypeModel>(list);
        }

        /// <summary>
        /// The GroupTypeWindow_Loaded
        /// </summary>
        /// <param name = "sender">The <see cref = "object "/></param>
        /// <param name = "e">The <see cref = "RoutedEventArgs"/></param>
        private void GroupTypeWindow_Loaded(object sender, RoutedEventArgs e)
        {
            this.DataContext = this;
        }

        /// <summary>
        /// Raises property changed event with the property name
        /// </summary>
        /// <param name = "propertyName">The property name</param>
        private void OnPropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        /// <summary>
        /// The SaveButton_Click
        /// </summary>
        /// <param name = "sender">The <see cref = "object "/></param>
        /// <param name = "e">The <see cref = "RoutedEventArgs"/></param>
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        #endregion
    }
}
