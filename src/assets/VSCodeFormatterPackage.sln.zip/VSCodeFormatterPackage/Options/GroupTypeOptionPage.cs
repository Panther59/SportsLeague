namespace VSCodeFormatterPackage.Options
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Runtime.InteropServices;
    using Microsoft.VisualStudio.Shell;

    /// <summary>
    /// Defines the <see cref = "GroupTypeOptionPage"/>
    /// </summary>
    [Guid("EC3305F0-DFF8-4DA3-AF02-F9321D30F305")]
    public class GroupTypeOptionPage : DialogPage, INotifyPropertyChanged
    {
        #region Fields

        /// <summary>
        /// The name field
        /// </summary>
        private string name;

        /// <summary>
        /// The types field
        /// </summary>
        private string types;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="GroupTypeOptionPage"/> class.
        /// </summary>
        public GroupTypeOptionPage()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref = "GroupTypeOptionPage"/> class.
        /// </summary>
        /// <param name = "name">The <see cref = "string "/></param>
        /// <param name = "types">The <see cref = "string "/></param>
        public GroupTypeOptionPage(string name, string types) : this()
        {
            this.Name = name;
            this.Types = types;
        }

        #endregion

        #region Events

        /// <summary>
        /// Defines the PropertyChanged
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the Name
        /// </summary>
        public string Name
        {
            get
            {
                return this.name;
            }

            set
            {
                this.name = value;
                this.OnPropertyChanged("Name");
            }
        }

        /// <summary>
        /// Gets or sets the Types
        /// </summary>
        public string Types
        {
            get
            {
                return this.types;
            }

            set
            {
                this.types = value;
                this.OnPropertyChanged("Types");
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// The GetTypes
        /// </summary>
        /// <returns>The <see cref = "List{string}"/></returns>
        public List<string> GetTypes()
        {
            if (this.Types == null)
            {
                return null;
            }

            return this.Types.Split(',').Where(x => x != null && string.IsNullOrEmpty(x.Trim()) == false).Select(y => y.Trim()).ToList();
        }

        /// <summary>
        /// Raises property changed event with the property name
        /// </summary>
        /// <param name = "propertyName">The property name</param>
        private void OnPropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        #endregion
    }
}
