﻿namespace VSCodeFormatterPackage.Options
{
    using System;
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for FileHeaderOptionPageControl.xaml
    /// </summary>
    public partial class FileHeaderOptionPageControl : UserControl
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="FileHeaderOptionPageControl"/> class.
        /// </summary>
        public FileHeaderOptionPageControl()
        {
            InitializeComponent();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the OptionPage
        /// </summary>
        public FileHeaderOptionPage OptionPage
        {
            get;
            set;
        }

        public void Initialize()
        {
            this.DataContext = OptionPage;
        }

        #endregion
    }
}