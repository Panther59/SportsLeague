﻿namespace VSCodeFormatterPackage.Options
{
    using System.Windows;
    using System.ComponentModel;
    using System.Windows.Forms.Integration;
    using Microsoft.VisualStudio.Shell;
    using System.Windows.Forms;
    using System.Runtime.InteropServices;

    /// <summary>
    /// Defines the <see cref="FileHeaderOptionPage" />
    /// </summary>
    [Guid("AEDA73AD-7046-45C8-9D8B-23019862CB11")]
    public class FileHeaderOptionPage : DialogPage, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// The header field
        /// </summary>
        private string header;

        /// <summary>
        /// Gets or sets the Header
        /// </summary>
        public string Header
        {
            get
            {
                return this.header;
            }

            set
            {
                this.header = value;
                this.OnPropertyChanged("Header");
            }
        }

        private void OnPropertyChanged(string prop)
        {
            this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
        }


        /// <summary>
        /// Gets  the Window
        /// </summary>
        protected override IWin32Window Window
        {
            get
            {
                FileHeaderOptionPageControl page = new FileHeaderOptionPageControl();
                page.OptionPage = this;
                page.Initialize();
                UserControl user = new UserControl();
                // Create the ElementHost control for hosting the
                // WPF UserControl.
                ElementHost host = new ElementHost();
                host.Dock = DockStyle.Fill;
                // Assign the WPF UserControl to the ElementHost control's
                // Child property.
                host.Child = page;
                // Add the ElementHost control to the form's
                // collection of child controls.
                user.Controls.Add(host);
                return user;
            }
        }
    }
}
