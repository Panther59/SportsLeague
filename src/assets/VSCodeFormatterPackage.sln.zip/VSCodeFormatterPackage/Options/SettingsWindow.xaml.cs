namespace VSCodeFormatterPackage.Options
{
    using System;
    using System.Windows;
    using CodeFormatter.Common.Entities;
    using CodeFormatter.Core.Syntaxs.MemberGroups;
    using CodeFormatter.Core.ViewModels;
    using CodeFormatter.Core.ViewModels.Settings;

    /// <summary>
    /// Interaction logic for TypeLayoutWindow.xaml
    /// </summary>
    public partial class TypeLayoutWindow : Window
    {
        #region Fields

        #region Commands

        /// <summary>
        /// The closeCommand field
        /// </summary>
        private RelayCommand closeCommand;

        /// <summary>
        /// The saveCommand field
        /// </summary>
        private RelayCommand saveCommand;

        #endregion

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="TypeLayoutWindow"/> class.
        /// </summary>
        public TypeLayoutWindow()
        {
            InitializeComponent();
            this.Loaded += this.TypeLayoutWindow_Loaded;
        }

        private void TypeLayoutWindow_Loaded(object sender, RoutedEventArgs e)
        {
            this.DataContext = this;
        }

        #endregion

        #region Properties

        #region Commands

        /// <summary>
        /// Gets the CloseCommand
        /// </summary>
        public RelayCommand CloseCommand
        {
            get
            {
                if (this.closeCommand == null)
                {
                    this.closeCommand = new RelayCommand(command => this.ExecuteClose());
                }

                return this.closeCommand;
            }
        }

        /// <summary>
        /// Gets the SaveCommand
        /// </summary>
        public RelayCommand SaveCommand
        {
            get
            {
                if (this.saveCommand == null)
                {
                    this.saveCommand = new RelayCommand(command => this.ExecuteSave());
                }

                return this.saveCommand;
            }
        }

        #endregion

        #endregion

        #region Methods

        /// <summary>
        /// Executes Close
        /// </summary>
        private void ExecuteClose()
        {
            this.Close();
        }

        /// <summary>
        /// Executes Save
        /// </summary>
        private void ExecuteSave()
        {
            var vm = this.SettingsView.DataContext as SettingsViewModel;
            if (vm != null)
            {
                try
                {
                    vm.SaveSettings();
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        #endregion
    }
}
