﻿using System;
using System.Windows;

namespace VSCodeFormatterPackage.Options
{
    /// <summary>
    /// Interaction logic for FirstTimeSettingsWindow.xaml
    /// </summary>
    public partial class FirstTimeSettingsWindow : Window
    {
        public FirstTimeSettingsWindow()
        {
            InitializeComponent();
        }

        internal void Initialize(VSPackage package)
        {
            this.OptionPageControl.OptionPage = (FileFormatterOptionPage)package.GetDialogPage(typeof(FileFormatterOptionPage));
            this.OptionPageControl.Initialize();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            this.OptionPageControl.OptionPage.SaveSettingsToStorage();
            this.Close();
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
