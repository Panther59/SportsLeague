﻿//------------------------------------------------------------------------------
// <copyright file="AddHeaderSettingFileViaProjectNodeCommand.cs" company="Accenture">
//     Copyright (c) Company.  All rights reserved.
// </copyright>
//------------------------------------------------------------------------------

namespace VSCodeFormatterPackage.Commands
{
    using EnvDTE;
    using Microsoft.VisualStudio.Shell;
    using System;
    using System.ComponentModel.Design;
    using System.IO;
    using Ayvan.ErrorLogger;

    /// <summary>
    /// Command handler
    /// </summary>
    internal sealed class AddHeaderSettingFileViaProjectNodeCommand : BaseAddHeaderSettingFileCommand
    {
        #region Fields

        /// <summary>
        /// Command menu group (command set GUID).
        /// </summary>
        public static readonly Guid CommandSet = new Guid("bd51ba80-94da-4fe7-9b20-ab86e159f065");

        /// <summary>
        /// Command ID.
        /// </summary>
        public const int CommandId = 4133;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "AddHeaderSettingFileViaProjectNodeCommand"/> class.
        /// Adds our command handlers for menu (commands must exist in the command table file)
        /// </summary>
        /// <param name = "package">Owner package, not null.</param>
        private AddHeaderSettingFileViaProjectNodeCommand(VSPackage package) : base(package)
        {
            if (package == null)
            {
                throw new ArgumentNullException("package");
            }

            OleMenuCommandService commandService = this.ServiceProvider.GetService(typeof(IMenuCommandService)) as OleMenuCommandService;
            if (commandService != null)
            {
                var menuCommandID = new CommandID(CommandSet, CommandId);
                var menuItem = new OleMenuCommand(this.MenuItemCallback, menuCommandID);
                menuItem.BeforeQueryStatus += this.MenuItem_BeforeQueryStatus;
                commandService.AddCommand(menuItem);
            }
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the instance of the command.
        /// </summary>
        public static AddHeaderSettingFileViaProjectNodeCommand Instance
        {
            get;
            private set;
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// Initializes the singleton instance of the command.
        /// </summary>
        /// <param name = "package">Owner package, not null.</param>
        public static void Initialize(VSPackage package)
        {
            Instance = new AddHeaderSettingFileViaProjectNodeCommand(package);
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// The MenuItem_BeforeQueryStatus
        /// </summary>
        /// <param name = "sender">The <see cref = "object "/></param>
        /// <param name = "e">The <see cref = "EventArgs"/></param>
        private void MenuItem_BeforeQueryStatus(object sender, EventArgs e)
        {
            OleMenuCommand command = sender as OleMenuCommand;
            bool canBeVisible = false;
            if (command != null)
            {
                if (this.Dte.SelectedItems != null)
                {
                    foreach (SelectedItem proj in this.Dte.SelectedItems)
                    {
                        if (proj.Project != null && proj.Project is Project)
                        {
                            Project project = proj.Project as Project;
                            if (File.Exists(project.FullName))
                            {
                                canBeVisible = true;
                                break;
                            }
                            //if (File.Exists(proj.Name))
                            //{
                            //    canBeVisible = true;
                            //    break;
                            //}
                        }
                    }
                }
            }

            command.Visible = canBeVisible;
        }

        /// <summary>
        /// This function is the callback used to execute the command when the menu item is clicked.
        /// See the constructor to see how the menu item is associated with this function using
        /// OleMenuCommandService service and MenuCommand class.
        /// </summary>
        /// <param name = "sender">Event sender.</param>
        /// <param name = "e">Event args.</param>
        private async void MenuItemCallback(object sender, EventArgs e)
        {
            try
            {
                if (this.Dte.SelectedItems != null)
                {
                    foreach (SelectedItem project in this.Dte.SelectedItems)
                    {
                        if (project.Project != null && project.Project is Project)
                        {
                            Project proj = project.Project as Project;
                            if (proj != null)
                            {
                                var projFolder = Path.GetDirectoryName(proj.FileName);
                                var newFileName = projFolder + "\\" + proj.Name + ".header";
                                this.AddHeaderFileIntoProject(proj, newFileName);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogException(ex);
                this.WriteToOutputWindow("Error Occured: " + ex.Message);
            }
        }

        #endregion

        #endregion
    }
}