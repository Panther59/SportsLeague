﻿//------------------------------------------------------------------------------
// <copyright file="CodeFormatterViaCodeWindowCommand.cs" company="Company">
//     Copyright (c) Company.  All rights reserved.
// </copyright>
//------------------------------------------------------------------------------

namespace VSCodeFormatterPackage.Commands
{
    using Microsoft.VisualStudio.Shell;
    using System;
    using System.ComponentModel.Design;
    using System.IO;
    using Microsoft.VisualStudio.Shell.Interop;
    using Ayvan.ErrorLogger;

    /// <summary>
    /// Command handler
    /// </summary>
    internal sealed class CodeFormatterViaCodeWindowCommand : BaseFormatCodeCommand
    {
        #region Fields

        /// <summary>
        /// Command menu group (command set GUID).
        /// </summary>
        public static readonly Guid CommandSet = new Guid("bd51ba80-94da-4fe7-9b20-ab86e159f065");

        /// <summary>
        /// Command ID.
        /// </summary>
        public const int CommandId = 3000;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "CodeFormatterViaCodeWindowCommand"/> class.
        /// Adds our command handlers for menu (commands must exist in the command table file)
        /// </summary>
        /// <param name = "package">Owner package, not null.</param>
        private CodeFormatterViaCodeWindowCommand(VSPackage package) : base(package)
        {
            OleMenuCommandService commandService = this.ServiceProvider.GetService(typeof(IMenuCommandService)) as OleMenuCommandService;
            if (commandService != null)
            {
                var menuCommandID = new CommandID(CommandSet, CommandId);
                var menuItem = new OleMenuCommand(this.MenuItemCallback, menuCommandID);
                menuItem.BeforeQueryStatus += this.MenuItem_BeforeQueryStatus;
                commandService.AddCommand(menuItem);
            }
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the instance of the command.
        /// </summary>
        public static CodeFormatterViaCodeWindowCommand Instance
        {
            get;
            private set;
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// Initializes the singleton instance of the command.
        /// </summary>
        /// <param name = "package">Owner package, not null.</param>
        public static void Initialize(VSPackage package)
        {
            Instance = new CodeFormatterViaCodeWindowCommand(package);
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// The MenuItem_BeforeQueryStatus
        /// </summary>
        /// <param name = "sender">The <see cref = "object "/></param>
        /// <param name = "e">The <see cref = "EventArgs"/></param>
        private void MenuItem_BeforeQueryStatus(object sender, EventArgs e)
        {
            OleMenuCommand command = sender as OleMenuCommand;
            if (command != null)
            {
                bool canBeVisible = false;
                if (this.Dte.ActiveDocument != null)
                {
                    var fullPath = this.Dte.ActiveDocument.FullName.ToString();
                    if (Path.GetExtension(fullPath).ToLowerInvariant() == ".cs")
                    {
                        canBeVisible = true;
                    }
                }

                command.Visible = canBeVisible;
            }
        }

        /// <summary>
        /// This function is the callback used to execute the command when the menu item is clicked.
        /// See the constructor to see how the menu item is associated with this function using
        /// OleMenuCommandService service and MenuCommand class.
        /// </summary>
        /// <param name = "sender">Event sender.</param>
        /// <param name = "e">Event args.</param>
        private async void MenuItemCallback(object sender, EventArgs e)
        {
            try
            {
                if (this.Dte.ActiveDocument != null)
                {
                    var fullPath = this.Dte.ActiveDocument.FullName.ToString();
                    if (Path.GetExtension(fullPath).ToLowerInvariant() == ".cs")
                    {
                        await this.UpdateFileContent(this.Dte.ActiveDocument);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogException(ex);
                this.WriteToOutputWindow("Error Occured: " + ex.Message);
            }
        }

        #endregion

        #endregion
    }
}