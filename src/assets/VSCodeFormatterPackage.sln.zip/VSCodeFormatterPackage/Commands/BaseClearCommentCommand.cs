// <copyright file="BaseClearCommentCommand.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>30-07-2017</date>

namespace VSCodeFormatterPackage.Commands
{
    using System;
    using System.IO;
    using System.Linq;
    using System.Threading.Tasks;
    using Ayvan.ErrorLogger;
    using CodeFormatter.Common.Contracts;
    using CodeFormatter.Core;
    using EnvDTE;
    using EnvDTE80;
    using Microsoft.VisualStudio;
    using Microsoft.VisualStudio.Shell.Interop;
    using Unity;

    /// <summary>
    /// Defines the <see cref = "BaseClearCommentCommand"/>
    /// </summary>
    public class BaseClearCommentCommand
    {
        #region Fields

        /// <summary>
        /// The visual studio instance
        /// </summary>
        private readonly DTE2 dte;

        /// <summary>
        /// VS Package that provides this command, not null.
        /// </summary>
        private readonly VSPackage package;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "BaseClearCommentCommand"/> class.
        /// </summary>
        /// <param name = "package">The <see cref = "VSPackage"/></param>
        public BaseClearCommentCommand(VSPackage package)
        {
            if (package == null)
            {
                throw new ArgumentNullException("package");
            }

            this.dte = Microsoft.VisualStudio.Shell.Package.GetGlobalService(typeof(DTE)) as DTE2;
            this.package = package;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the Dte
        /// </summary>
        public DTE2 Dte
        {
            get
            {
                return dte;
            }
        }

        /// <summary>
        /// Gets the Package
        /// </summary>
        public VSPackage Package
        {
            get
            {
                return package;
            }
        }

        /// <summary>
        /// Gets the service provider from the owner package.
        /// </summary>
        public IServiceProvider ServiceProvider
        {
            get
            {
                return this.Package;
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// The GetDocumentText
        /// </summary>
        /// <param name = "document">The <see cref = "Document"/></param>
        /// <returns>The <see cref = "Task{string}"/></returns>
        protected Task<string> GetDocumentText(Document document)
        {
            return System.Threading.Tasks.Task.Run(() =>
            {
                var textDocument = (EnvDTE.TextDocument)document.Object("TextDocument");
                EditPoint editPoint = textDocument?.StartPoint?.CreateEditPoint();
                return editPoint?.GetText(textDocument.EndPoint);
            });
        }

        /// <summary>
        /// The SetDocumentText
        /// </summary>
        /// <param name = "document">The <see cref = "EnvDTE.Document"/></param>
        /// <param name = "content">The <see cref = "string "/></param>
        /// <returns>The <see cref = "System.Threading.Tasks.Task"/></returns>
        protected System.Threading.Tasks.Task SetDocumentText(EnvDTE.Document document, string content)
        {
            return System.Threading.Tasks.Task.Run(() =>
            {
                var textDocument = (EnvDTE.TextDocument)document.Object("TextDocument");
                EditPoint editPoint = textDocument.StartPoint.CreateEditPoint();
                EditPoint endPoint = textDocument.EndPoint.CreateEditPoint();
                editPoint.ReplaceText(endPoint, content, 0);
                document.Activate();
                var setting = VSPackage.Container.Resolve<IDefaultSettings>();
                if (setting.RemoveUnwantedUsings)
                {
                    var version = this.Dte.Version;
                    if (version.StartsWith("15."))
                    {
                        this.Dte.ExecuteCommand("EditorContextMenus.CodeWindow.RemoveAndSort", string.Empty);
                    }
                    else
                    {
                        this.Dte.ExecuteCommand("EditorContextMenus.CodeWindow.OrganizeUsings.RemoveAndSort", string.Empty);
                    }
                }

                this.Dte.ExecuteCommand("Edit.FormatDocument", string.Empty);
            });
        }

        /// <summary>
        /// The UpdateFileContent
        /// </summary>
        /// <param name = "document">The <see cref = "Document"/></param>
        /// <returns>The <see cref = "System.Threading.Tasks.Task"/></returns>
        protected async System.Threading.Tasks.Task UpdateFileContent(Document document)
        {
            var path = document.FullName;
            string outputWindowContent = string.Empty;
            var fileName = document.Name;
            try
            {
                var header = GetFileHeaderSettings(document);
                var content = await this.GetDocumentText(document);
                CodeFileFormatter formatter = VSPackage.Container.Resolve<CodeFileFormatter>();
                var newContent = await formatter.RemoveCommentsFromContent(content, Path.GetFileName(path), header);
                await this.SetDocumentText(document, newContent);
                outputWindowContent = string.Format("{0} Formatted successfully. ({1}){2}", fileName, path, Environment.NewLine);
            }
            catch (Exception ex)
            {
                ErrorLog.LogException(ex);
                outputWindowContent = string.Format("{0} Formatted failed with error '{1}'. ({2}){3}", fileName, ex.Message, path, Environment.NewLine);
            }

            this.WriteToOutputWindow(outputWindowContent);
        }

        /// <summary>
        /// The UpdateFileContent
        /// </summary>
        /// <param name = "projectItem">The <see cref = "ProjectItem"/></param>
        /// <returns>The <see cref = "Task"/></returns>
        protected async Task UpdateFileContent(ProjectItem projectItem)
        {
            bool wasOpen = true;
            Window documentWindow = null;
            if (projectItem.IsOpen == false)
            {
                wasOpen = false;
                documentWindow = projectItem.Open();
            }

            TextSelection textSelection = projectItem.Document.Selection as TextSelection;
            int lineNum = 0;
            if (textSelection != null)
            {
                lineNum = textSelection.ActivePoint.Line;
            }

            await this.UpdateFileContent(projectItem.Document);
            textSelection.GotoLine(lineNum);
            if (wasOpen == false)
            {
                documentWindow.Close(vsSaveChanges.vsSaveChangesYes);
            }
        }

        /// <summary>
        /// The WriteToOutputWindow
        /// </summary>
        /// <param name = "content">The <see cref = "string "/></param>
        protected void WriteToOutputWindow(string content)
        {
            IVsOutputWindow outWindow = Microsoft.VisualStudio.Shell.Package.GetGlobalService(typeof(SVsOutputWindow)) as IVsOutputWindow;
            Guid generalPaneGuid = VSConstants.GUID_OutWindowDebugPane; // P.S. There's also the GUID_OutWindowDebugPane available.
            IVsOutputWindowPane generalPane;
            outWindow.GetPane(ref generalPaneGuid, out generalPane);
            generalPane.OutputTaskItemString(content, VSTASKPRIORITY.TP_NORMAL, VSTASKCATEGORY.CAT_COMMENTS, "Code Formatter", 0, null, 0, null);
            generalPane.Activate(); // Brings this pane into view
        }

        #region Private Methods

        /// <summary>
        /// The GetFileHeaderSettings
        /// </summary>
        /// <param name = "document">The <see cref = "Document"/></param>
        /// <returns>The <see cref = "string "/></returns>
        private string GetFileHeaderSettings(Document document)
        {
            if (AppGlobal.FileHeaderSettings.AddFileHeader == false)
            {
                return null;
            }

            var projectPath = document?.ProjectItem?.ContainingProject?.FileName;
            string settings = GetFileHeaderSettings(projectPath);
            if (settings != null)
            {
                return settings;
            }

            var solutionPath = Dte?.Solution?.FileName;
            settings = GetFileHeaderSettings(solutionPath);
            if (settings != null)
            {
                return settings;
            }

            settings = AppGlobal.FileHeaderSettings.Header;
            return settings;
        }

        /// <summary>
        /// The GetFileHeaderSettings
        /// </summary>
        /// <param name = "path">The <see cref = "string "/></param>
        /// <returns>The <see cref = "string "/></returns>
        private string GetFileHeaderSettings(string path)
        {
            if (path != null)
            {
                var directory = Path.GetDirectoryName(path);
                var files = Directory.GetFiles(directory, "*.header", SearchOption.TopDirectoryOnly);
                var fileHeader = files.Any() ? files.First() : null;
                if (fileHeader != null)
                {
                    var setting = File.ReadAllText(fileHeader);
                    return setting;
                }
            }

            return null;
        }

        #endregion

        #endregion
    }
}
