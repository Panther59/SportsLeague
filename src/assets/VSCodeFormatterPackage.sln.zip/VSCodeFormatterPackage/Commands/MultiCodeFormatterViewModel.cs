﻿// <copyright file="MultiCodeFormatterViewModel.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>30-07-2017</date>

namespace VSCodeFormatterPackage.Commands
{
    using CodeFormatter.Common.Entities;
    using EnvDTE;
    using EnvDTE80;
    using System.ComponentModel;
    using System.IO;
    using System.Threading;
    using System.Threading.Tasks;
    using VSCodeFormatterPackage.Views;
    using Ayvan.ErrorLogger;

    /// <summary>
    /// Defines the <see cref = "MultiCodeFormatterViewModel"/>
    /// </summary>
    public class MultiCodeFormatterViewModel : BaseFormatCodeCommand, INotifyPropertyChanged
    {
        #region Fields

        /// <summary>
        /// The visual studio instance
        /// </summary>
        private readonly DTE2 dte;

        /// <summary>
        /// Defines the cts
        /// </summary>
        private CancellationTokenSource cts;

        /// <summary>
        /// The fileName field
        /// </summary>
        private string fileName;

        /// <summary>
        /// The filePath field
        /// </summary>
        private string filePath;

        /// <summary>
        /// Defines the view
        /// </summary>
        private IWindowView view;

        #region Commands

        /// <summary>
        /// The cancelOperationCommand field
        /// </summary>
        private RelayCommand cancelOperationCommand;

        #endregion

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "MultiCodeFormatterViewModel"/> class.
        /// </summary>
        public MultiCodeFormatterViewModel(VSPackage package) : base(package)
        {
            this.dte = Microsoft.VisualStudio.Shell.Package.GetGlobalService(typeof(DTE)) as DTE2;
        }

        #endregion

        #region Events

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the FilePath
        /// </summary>
        public string FilePath
        {
            get
            {
                return this.filePath;
            }

            set
            {
                this.filePath = value;
                this.OnPropertyChanged("FilePath");
            }
        }

        /// <summary>
        /// Gets or sets the FileName
        /// </summary>
        public string FileName
        {
            get
            {
                return this.fileName;
            }

            set
            {
                this.fileName = value;
                this.OnPropertyChanged("FileName");
            }
        }

        #region Commands

        /// <summary>
        /// Gets the CancelOperationCommand
        /// </summary>
        public RelayCommand CancelOperationCommand
        {
            get
            {
                if (this.cancelOperationCommand == null)
                {
                    this.cancelOperationCommand = new RelayCommand(command => this.ExecuteCancelOperation());
                }

                return this.cancelOperationCommand;
            }
        }

        #endregion

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// The AttachView
        /// </summary>
        /// <param name = "view">The <see cref = "IWindow"/></param>
        public void AttachView(IWindowView view)
        {
            this.view = view;
        }

        /// <summary>
        /// The StartFormattingSolution
        /// </summary>
        /// <param name = "updateCodeAction">The <see cref = "Task"/></param>
        public async void StartFormattingProject()
        {
            cts = new CancellationTokenSource();
            await ExecuteProjectFormatting(cts.Token);
            this.view.CloseWindow();
        }

        /// <summary>
        /// The StartFormattingSolution
        /// </summary>
        /// <param name = "updateCodeAction">The <see cref = "Task"/></param>
        public async void StartFormattingSolution()
        {
            cts = new CancellationTokenSource();
            await ExecuteSolutionFormatting(cts.Token);
            this.view.CloseWindow();
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Executes CancelOperation
        /// </summary>
        private void ExecuteCancelOperation()
        {
            try
            {
                if (cts != null)
                {
                    cts.Cancel();
                }
            }
            catch (System.Exception ex)
            {
                ErrorLog.LogException(ex);
            }
        }

        /// <summary>
        /// The ExecuteProjectFormatting
        /// </summary>
        /// <param name = "updateCodeAction">The <see cref = "Task"/></param>
        /// <param name = "token">The <see cref = "CancellationToken"/></param>
        /// <returns>The <see cref = "Task"/></returns>
        private async Task ExecuteProjectFormatting(CancellationToken token)
        {
            try
            {
                if (this.Dte.SelectedItems != null)
                {
                    foreach (SelectedItem project in this.Dte.SelectedItems)
                    {
                        if (project.Project != null && project.Project is Project)
                        {
                            Project proj = project.Project as Project;
                            if (proj != null)
                            {
                                if (File.Exists(proj.FullName))
                                {
                                    foreach (ProjectItem item in proj.ProjectItems)
                                    {
                                        if (token.IsCancellationRequested == false)
                                        {
                                            await this.FormatCodeForProjectItem(item, token);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                ErrorLog.LogException(ex);
                this.WriteToOutputWindow("Error Occured: " + ex.Message);
            }
        }

        /// <summary>
        /// The ExecuteSolutionFormatting
        /// </summary>
        /// <param name = "updateCodeAction">The <see cref = "Task"/></param>
        /// <param name = "token">The <see cref = "CancellationToken"/></param>
        /// <returns>The <see cref = "Task"/></returns>
        private async Task ExecuteSolutionFormatting(CancellationToken token)
        {
            try
            {
                if (this.dte.Solution != null)
                {
                    if (this.dte.Solution.Projects != null)
                    {
                        foreach (Project proj in this.dte.Solution.Projects)
                        {
                            if (File.Exists(proj.FullName))
                            {
                                foreach (ProjectItem item in proj.ProjectItems)
                                {
                                    if (token.IsCancellationRequested == false)
                                    {
                                        await this.FormatCodeForProjectItem(item, token);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                ErrorLog.LogException(ex);
                this.WriteToOutputWindow("Error Occured: " + ex.Message);
            }
        }

        /// <summary>
        /// The FormatCodeForProjectItem
        /// </summary>
        /// <param name = "projItem">The <see cref = "ProjectItem"/></param>
        /// <param name = "updateCodeAction">The <see cref = "Task"/></param>
        /// <returns>The <see cref = "System.Threading.Tasks.Task"/></returns>
        private async System.Threading.Tasks.Task FormatCodeForProjectItem(ProjectItem projItem, CancellationToken token)
        {
            if (token.IsCancellationRequested)
            {
                return;
            }

            var fullPathProperty = projItem.Properties.Item("FullPath");
            if (fullPathProperty != null)
            {
                var fullPath = fullPathProperty.Value.ToString();
                if (Path.GetExtension(fullPath).ToLowerInvariant() == ".cs")
                {
                    this.FileName = projItem.Name;
                    this.FilePath = fullPath;
                    //await Task.Delay(1000);
                    await this.UpdateFileContent(projItem);
                }
            }

            if (projItem.ProjectItems != null)
            {
                foreach (ProjectItem item in projItem.ProjectItems)
                {
                    await this.FormatCodeForProjectItem(item, token);
                }
            }
        }

        /// <summary>
        /// The OnPropertyChanged
        /// </summary>
        /// <param name = "prop">The <see cref = "string "/></param>
        private void OnPropertyChanged(string prop)
        {
            this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
        }

        #endregion

        #endregion
    }
}