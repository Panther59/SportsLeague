﻿//------------------------------------------------------------------------------
// <copyright file="VSPackage.cs" company="Company">
//     Copyright (c) Company.  All rights reserved.
// </copyright>
//------------------------------------------------------------------------------

namespace VSCodeFormatterPackage
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using System.IO;
    using System.Reflection;
    using System.Runtime.InteropServices;
    using System.Windows;
    using Ayvan.ErrorLogger;
    using CodeFormatter.Common.Contracts;
    using CodeFormatter.Core.Views.Settings;
    using EnvDTE;
    using EnvDTE80;
    using Microsoft.VisualStudio.Shell;
    using Microsoft.VisualStudio.Shell.Interop;
    using Unity;
    using VSCodeFormatterPackage.Commands;
    using VSCodeFormatterPackage.Options;

    /// <summary>
    /// This is the class that implements the package exposed by this assembly.
    /// </summary>
    /// <remarks>
    /// <para>
    /// The minimum requirement for a class to be considered a valid package for Visual Studio
    /// is to implement the IVsPackage interface and register itself with the shell.
    /// This package uses the helper classes defined inside the Managed Package Framework (MPF)
    /// to do it: it derives from the Package class that provides the implementation of the
    /// IVsPackage interface and uses the registration attributes defined in the framework to
    /// register itself and its components with the shell. These attributes tell the pkgdef creation
    /// utility what data to put into .pkgdef file.
    /// </para>
    /// <para>
    /// To get loaded into VS, the package must be referred by &lt;Asset Type="Microsoft.VisualStudio.VsPackage" ...&gt; in .vsixmanifest file.
    /// </para>
    /// </remarks>
    [PackageRegistration(UseManagedResourcesOnly = true)]
    [InstalledProductRegistration("#110", "#112", "1.0", IconResourceID = 400)] // Info on this package for Help/About
    [Guid(VSPackage.PackageGuidString)]
    [SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1650:ElementDocumentationMustBeSpelledCorrectly", Justification = "pkgdef, VS and vsixmanifest are valid VS terms")]
    [ProvideMenuResource("Menus.ctmenu", 1)]
    [ProvideAutoLoad(Microsoft.VisualStudio.Shell.Interop.UIContextGuids80.SolutionExists)]
    [ProvideOptionPage(typeof(FileFormatterOptionPage), "Code Formatter", "Default", 0, 0, true)]
    //[ProvideOptionPage(typeof(FileHeaderOptionPage), "Code Formatter", "File Header", 0, 0, true)]
    public sealed class VSPackage : Package
    {
        #region Constants

        /// <summary>
        /// VSPackage GUID string.
        /// </summary>
        public const string PackageGuidString = "253be176-c374-4af6-975f-98e810905fb7";

        #endregion

        #region Fields

        /// <summary>
        /// Defines the dte
        /// </summary>
        private DTE2 dte;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "VSPackage"/> class.
        /// </summary>
        public VSPackage()
        {
            // Inside this method you can place any initialization code that does not require
            // any Visual Studio service because at this point the package object is created but
            // not sited yet inside Visual Studio environment. The place to do all the other
            // initialization is the Initialize method.
            //// AppDomain.CurrentDomain.AssemblyResolve += OnAssemblyResolve;
            AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
            this.dte = Microsoft.VisualStudio.Shell.Package.GetGlobalService(typeof(DTE)) as DTE2;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the Container
        /// </summary>
        public static UnityContainer Container { get; private set; }

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// The GetDialogPage
        /// </summary>
        /// <param name = "dialogPageType">The <see cref = "Type"/></param>
        /// <returns>The <see cref = "DialogPage"/></returns>
        public new DialogPage GetDialogPage(Type dialogPageType)
        {
            return base.GetDialogPage(dialogPageType);
        }

        /// <summary>
        /// The ShowMessage
        /// </summary>
        /// <param name="title">The <see cref="string"/></param>
        /// <param name="message">The <see cref="string"/></param>
        public void ShowMessage(string title, string message)
        {
            // Show a message box to prove we were here
            VsShellUtilities.ShowMessageBox(
                this,
                message,
                title,
                OLEMSGICON.OLEMSGICON_INFO,
                OLEMSGBUTTON.OLEMSGBUTTON_OK,
                OLEMSGDEFBUTTON.OLEMSGDEFBUTTON_FIRST);
        }

        #endregion

        /// <summary>
        /// The CurrentDomain_UnhandledException
        /// </summary>
        /// <param name = "sender">The <see cref = "object "/></param>
        /// <param name = "e">The <see cref = "UnhandledExceptionEventArgs"/></param>
        internal void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            if (e.IsTerminating)
            {
                System.Windows.MessageBox.Show("Something bad happened, closing application...");
            }
            else
            {
                System.Windows.MessageBox.Show("Something bad happened.");
            }
        }

        /// <summary>
        /// Initialization of the package; this method is called right after the package is sited, so this is the place
        /// where you can put all the initialization code that rely on services provided by VisualStudio.
        /// </summary>
        protected override void Initialize()
        {
            base.Initialize();
            try
            {
                Container = new UnityContainer();
                Container.RegisterInstance<UnityContainer>(Container);
                Container.RegisterInstance<VSPackage>(this);
                Startup.UnityConfig.RegisterTypes(Container);
                ErrorLog.ApplicationDetail = new ApplicationAttributes(Assembly.GetAssembly(typeof(VSPackage)));

                var settings = Container.Resolve<IDefaultSettings>();
                if (settings.IsFirstLaunch == false)
                {
                    SettingsWindow window = new SettingsWindow();
                    ResourceDictionary myResourceDictionary = new ResourceDictionary();
                    myResourceDictionary.Source = new Uri(@"/VSCodeFormatterPackage;component/MainResourceDictionary.xaml", UriKind.RelativeOrAbsolute);
                    window.Resources.MergedDictionaries.Add(myResourceDictionary);
                    //window.Initialize(this);
                    window.ShowDialog();
                    settings.IsFirstLaunch = true;
                    settings.Save();
                }

                ClearCommentViaCodeWindowCommand.Initialize(this);
                CodeFormatterViaCodeWindowCommand.Initialize(this);
                CodeFormatterViaItemNodeCommand.Initialize(this);
                CodeFormatterViaProjectNodeCommand.Initialize(this);
                CodeFormatterViaSolutionNodeCommand.Initialize(this);
                AddHeaderSettingFileViaProjectNodeCommand.Initialize(this);
                AddHeaderSettingFileViaSolutionNodeCommand.Initialize(this);
            }
            catch (Exception ex)
            {
                this.ShowMessage("Unable to load Code Formatter", ex.Message);
                ErrorLog.LogException(ex);
            }
        }

        #region Private Methods

        /// <summary>
        /// The OnAssemblyResolve
        /// </summary>
        /// <param name = "sender">The <see cref = "object "/></param>
        /// <param name = "args">The <see cref = "ResolveEventArgs"/></param>
        /// <returns>The <see cref = "System.Reflection.Assembly"/></returns>
        private System.Reflection.Assembly OnAssemblyResolve(object sender, ResolveEventArgs args)
        {
            string path = Assembly.GetExecutingAssembly().Location;
            path = Path.GetDirectoryName(path);
            if (args.Name.ToLower().Contains("Microsoft.CodeAnalysis"))
            {
                path = Path.Combine(path, "Microsoft.CodeAnalysis.dll");
                Assembly ret = Assembly.LoadFrom(path);
                return ret;
            }

            return null;
        }

        #endregion

        #endregion
    }
}
