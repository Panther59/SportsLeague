// <copyright file="UnityConfig.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>30-07-2017</date>

namespace VSCodeFormatterPackage.Startup
{
    using Unity;

    /// <summary>
    /// Defines the <see cref = "UnityConfig"/>
    /// </summary>
    public static class UnityConfig
    {
        #region Methods

        #region Public Methods

        /// <summary>
        /// The RegisterTypes
        /// </summary>
        /// <param name = "container">The <see cref = "IUnityContainer"/></param>
        public static void RegisterTypes(IUnityContainer container)
        {
            CodeFormatter.Common.Startup.UnityConfig.RegisterTypes(container);
            CodeFormatter.Core.Startup.UnityConfig.RegisterTypes(container);
        }

        #endregion

        #endregion
    }
}
