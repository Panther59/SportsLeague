﻿// <copyright file="IWindow.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>30-07-2017</date>

namespace VSCodeFormatterPackage.Views
{
    using System.Windows.Threading;

    /// <summary>
    /// Defines the <see cref = "IWindowView"/>
    /// </summary>
    public interface IWindowView
    {
        #region Properties

        /// <summary>
        /// Gets the Dispatcher
        /// </summary>
        Dispatcher Dispatcher
        {
            get;
        }

        #endregion

        #region Methods

        /// <summary>
        /// The CloseWindow
        /// </summary>
        void CloseWindow();

        #endregion
    }
}