﻿// <copyright file="MultiEditWindow.xaml.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>30-07-2017</date>

namespace VSCodeFormatterPackage.Views
{
    using System.Windows;

    /// <summary>
    /// Interaction logic for MultiEditWindow.xaml
    /// </summary>
    public partial class MultiEditWindow : Window, IWindowView
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "MultiEditWindow"/> class.
        /// </summary>
        public MultiEditWindow()
        {
            InitializeComponent();
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// The CloseWindow
        /// </summary>
        public void CloseWindow()
        {
            this.Close();
        }

        #endregion

        #endregion
    }
}