﻿using System.Reflection;
using CodeFormatter.Common.Contracts;
using Microsoft.Practices.Unity;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CodeFormatterTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            UnityContainer container = new UnityContainer();
            container.RegisterInstance<UnityContainer>(container);
            container.RegisterType<ISettings, Settings>();
            CodeFormatter.Common.Startup.UnityConfig.RegisterTypes(container);
            CodeFormatter.Core.Startup.UnityConfig.RegisterTypes(container);
            var testFilePath = System.AppDomain.CurrentDomain.BaseDirectory + @"\TestFile.txt";
            CodeFormatter.Core.CodeFileFormatter fomatter = container.Resolve<CodeFormatter.Core.CodeFileFormatter>();
            var result = fomatter.FormatFromFilePath(testFilePath).GetAwaiter().GetResult();
        }
    }
}
