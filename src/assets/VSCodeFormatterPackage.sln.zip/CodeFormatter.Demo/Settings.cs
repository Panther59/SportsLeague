namespace CodeFormatter.Demo
{
    using CodeFormatter.Common.Contracts;

    /// <summary>
    /// Defines the <see cref = "Settings"/>
    /// </summary>
    public class Settings : IDefaultSettings
    {
        #region Properties

        /// <summary>
        /// Gets a value indicating whether AddClassHeader
        /// </summary>
        public bool AddClassHeader
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// Gets a value indicating whether AddConstructorHeader
        /// </summary>
        public bool AddConstructorHeader
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// Gets a value indicating whether AddDelegateHeader
        /// </summary>
        public bool AddDelegateHeader
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// Gets a value indicating whether AddFieldHeader
        /// </summary>
        public bool AddFieldHeader
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// Gets a value indicating whether AddConstructorHeader
        /// </summary>
        public bool AddMethodHeader
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// Gets a value indicating whether AddMissingAccessModifier
        /// </summary>
        public bool AddMissingAccessModifier
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// Gets a value indicating whether AddPropertyHeader
        /// </summary>
        public bool AddPropertyHeader
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// Gets the DefaultAccessModifer
        /// </summary>
        public string DefaultAccessModifier
        {
            get
            {
                return "internal";
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether IsFirstLaunch
        /// </summary>
        public bool IsFirstLaunch
        {
            get;
            set;
        }

        /// <summary>
        /// Gets a value indicating whether MoveUsingInsideNamespace
        /// </summary>
        public bool MoveUsingInsideNamespace
        {
            get
            {
                return true;
            }
        }

        /// <summary>
        /// Gets a value indicating whether RemoveUnwantedUsings
        /// </summary>
        public bool RemoveUnwantedUsings
        {
            get
            {
                return true;
            }
        }

        #endregion
    }
}
