﻿// <copyright file="MainWindow.xaml.cs" company="Avanade">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>24-04-2018</date>

namespace CodeFormatter.Demo
{
    using System;
    using System.IO;
    using System.Windows;
    using System.Xml;
    using CodeFormatter.Common.Contracts;
    using CodeFormatter.Core;
    using CodeFormatter.Core.ViewModels.Settings;
    using CodeFormatter.Core.Views.Settings;
    using Microsoft.Win32;
    using Unity;

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        #region Fields

        /// <summary>
        /// Defines the formatter
        /// </summary>
        private CodeFileFormatter formatter;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="MainWindow"/> class.
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
            this.Loaded += MainWindow_Loaded;
        }

        #endregion

        #region Methods

        #region Private Methods

        /// <summary>
        /// The ApplySyntax
        /// </summary>
        private void ApplySyntax()
        {
            var dir = Environment.CurrentDirectory;
            Stream xshd_stream = File.OpenRead(dir + "\\Resources\\CSharp-Mode.xshd");
            XmlTextReader xshd_reader = new XmlTextReader(xshd_stream);
            var obj = ICSharpCode.AvalonEdit.Highlighting.Xshd.HighlightingLoader.Load(xshd_reader, ICSharpCode.AvalonEdit.Highlighting.HighlightingManager.Instance);
            txtInputData.SyntaxHighlighting = obj;
            txtOutputData.SyntaxHighlighting = obj;
            xshd_reader.Close();
            xshd_stream.Close();
        }

        /// <inheritdoc/>
        private void BtnBrowse_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();
            openFile.Multiselect = false;
            openFile.Filter = "Code File(.cs)|*.cs";
            var result = openFile.ShowDialog();
            if (result.HasValue && result.Value)
            {
                txtPath.Text = openFile.FileName;
                this.LoadFileContent(txtPath.Text);
            }
        }

        /// <summary>
        /// The btnClearComment_Click
        /// </summary>
        /// <param name="sender">The <see cref="object"/></param>
        /// <param name="e">The <see cref="RoutedEventArgs"/></param>
        private async void btnClearComment_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                this.SaveInputToSettings();
                var result = await this.formatter.RemoveCommentsFromContent(txtInputData.Text, "TestFile.cs", AppGlobal.FileHeaderSettings.AddFileHeader ? AppGlobal.FileHeaderSettings.Header : null);
                txtOutputData.Text = result;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Occured");
            }
        }

        /// <inheritdoc/>
        private async void BtnFormat_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                this.SaveInputToSettings();
                var result = await this.formatter.FormatFromContent(txtInputData.Text, "TestFile.cs", AppGlobal.FileHeaderSettings.AddFileHeader ? AppGlobal.FileHeaderSettings.Header : null);
                txtOutputData.Text = result;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Occured");
            }
        }

        /// <summary>
        /// The btnSetting_Click
        /// </summary>
        /// <param name="sender">The <see cref="object"/></param>
        /// <param name="e">The <see cref="RoutedEventArgs"/></param>
        private void btnSetting_Click(object sender, RoutedEventArgs e)
        {
            SettingsWindow window = new SettingsWindow();
            window.Owner = this;
            window.Resources = this.Resources;
            window.ShowDialog();
        }

        /// <summary>
        /// Loads file content to textbox
        /// </summary>
        /// <param name = "filePath">The file path</param>
        private void LoadFileContent(string filePath)
        {
            txtInputData.Text = File.ReadAllText(filePath);
            this.SaveInputToSettings();
        }

        /// <summary>
        /// The MainWindow_Loaded
        /// </summary>
        /// <param name="sender">The <see cref="object"/></param>
        /// <param name="e">The <see cref="RoutedEventArgs"/></param>
        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            this.ApplySyntax();
            UnityContainer container = new UnityContainer();
            container.RegisterInstance<UnityContainer>(container);

            var fileHeader = AppGlobal.GetFileHeaderSettings() ?? container.Resolve<FileHeaderViewModel>();
            container.RegisterInstance<IFileHeaderSettings>(fileHeader);


            CodeFormatter.Common.Startup.UnityConfig.RegisterTypes(container);
            CodeFormatter.Core.Startup.UnityConfig.RegisterTypes(container);
            formatter = container.Resolve<CodeFormatter.Core.CodeFileFormatter>();
            txtPath.Text = Properties.Settings.Default.FilePath;
            txtInputData.Text = Properties.Settings.Default.InputContent;
        }

        /// <summary>
        /// Save the input data to settings in order to load next time
        /// </summary>
        private void SaveInputToSettings()
        {
            Properties.Settings.Default.FilePath = txtPath.Text;
            Properties.Settings.Default.InputContent = txtInputData.Text;
            Properties.Settings.Default.Save();
        }

        #endregion

        #endregion
    }
}
