﻿// <copyright file="FileHeader.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>30-07-2017</date>

namespace Ayvan.VisualStudio.Common.Models
{
    /// <summary>
    /// Defines the <see cref="FileHeader" />
    /// </summary>
    public class FileHeader
    {
        #region Properties

        /// <summary>
        /// Gets or sets Header
        /// </summary>
        public string Header
        {
            get;
            set;
        }

        #endregion
    }
}