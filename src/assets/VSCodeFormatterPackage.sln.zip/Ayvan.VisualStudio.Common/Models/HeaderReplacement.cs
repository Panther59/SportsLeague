﻿// <copyright file="HeaderReplacement.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>30-07-2017</date>

namespace Ayvan.VisualStudio.Common.Models
{
    using System.Collections.Generic;

    /// <summary>
    /// Defines the <see cref="HeaderReplacement" />
    /// </summary>
    public class HeaderReplacement
    {
        #region Properties

        /// <summary>
        /// Gets or sets the Replacements
        /// </summary>
        public List<KeyValuePair<string, string>> Replacements
        {
            get;
            set;
        }

        #endregion
    }
}