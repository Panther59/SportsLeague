﻿// <copyright file="HeaderHelper.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>30-07-2017</date>

namespace Ayvan.VisualStudio.Common
{
    using Ayvan.VisualStudio.Common.Models;

    /// <summary>
    /// Defines the <see cref="HeaderHelper" />
    /// </summary>
    public class HeaderHelper
    {
        #region Properties

        /// <summary>
        /// Gets a value indicating whether IsHeaderFilePresent
        /// </summary>
        public bool IsHeaderFilePresent
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// Gets the GetHeaderFilePath
        /// </summary>
        public string GetHeaderFilePath
        {
            get
            {
                return null;
            }
        }

        /// <summary>
        /// Gets the GetHeaderRawContent
        /// </summary>
        public string GetHeaderRawContent
        {
            get
            {
                return null;
            }
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// The GetDefaultHeaderContent
        /// </summary>
        /// <returns>The <see cref="string"/></returns>
        public string GetDefaultHeaderContent()
        {
            return null;
        }

        /// <summary>
        /// The GetHeaderContent
        /// </summary>
        /// <param name="replacement">The <see cref="HeaderReplacement"/></param>
        /// <returns>The <see cref="string"/></returns>
        public string GetHeaderContent(HeaderReplacement replacement)
        {
            return null;
        }

        #endregion

        #endregion
    }
}