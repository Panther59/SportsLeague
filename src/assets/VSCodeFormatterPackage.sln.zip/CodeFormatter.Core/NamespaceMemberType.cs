namespace CodeFormatter.Core
{
    using System;
    using System.Linq;
    using CodeFormatter.Common.Contracts;
    using CodeFormatter.Core.Syntaxs;
    using Microsoft.CodeAnalysis;
    using Microsoft.CodeAnalysis.CSharp;
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    /// <summary>
    /// Defines the <see cref = "NamespaceMemberType"/>
    /// </summary>
    public class NamespaceMemberType : BaseMemberType
    {
        #region Fields

        /// <summary>
        /// Defines the resolver
        /// </summary>
        private readonly IResolver resolver;

        /// <summary>
        /// Defines the setting
        /// </summary>
        private readonly IDefaultSettings setting;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "NamespaceMemberType"/> class.
        /// </summary>
        /// <param name = "setting">The <see cref = "IDefaultSettings"/></param>
        /// <param name = "resolver">The <see cref = "IResolver"/></param>
        public NamespaceMemberType(IDefaultSettings setting, IResolver resolver) : base(setting, resolver)
        {
            this.setting = setting;
            this.resolver = resolver;
            //this.headerModifiersRootObject = resolver.ResolveAll<IBaseRootSyntax>();
        }

        #endregion


        #region Methods

        /// <summary>
        /// The Load
        /// </summary>
        /// <param name = "source">The <see cref = "MemberDeclarationSyntax"/></param>
        /// <param name = "isParentInterface">The <see cref = "bool "/></param>
        public void Load(MemberDeclarationSyntax source, bool isParentInterface = false)
        {
            try
            {
                IBaseMemberSyntax baseSyntax = this.resolver.Resolve<IBaseMemberSyntax>(source.Kind().ToString());
                source = baseSyntax.FixNode(source);
            }
            catch (Exception)
            {
            }

            this.SwitchKind(source, isParentInterface);
        }

        /// <summary>
        /// The FixField
        /// </summary>
        /// <param name = "field">The <see cref = "FieldDeclarationSyntax"/></param>
        /// <returns>The <see cref = "FieldDeclarationSyntax"/></returns>
        private FieldDeclarationSyntax FixField(FieldDeclarationSyntax field)
        {
            var leadingTrivia = field.GetLeadingTrivia().ToString().Trim();
            if (string.IsNullOrEmpty(leadingTrivia))
            {
                var comment = string.Format(@"
        /// <summary>
        /// Defines the {0}
        /// </summary>
        ", field.Declaration.Variables.First().ToString());
                field = field.WithLeadingTrivia(SyntaxFactory.Whitespace(comment));
            }

            return field;
        }

        #endregion
    }
}
