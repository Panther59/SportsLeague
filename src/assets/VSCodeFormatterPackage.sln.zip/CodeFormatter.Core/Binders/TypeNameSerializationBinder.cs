﻿namespace CodeFormatter.Core.Binders
{
    using System;
    using System.Runtime.Serialization;
    using Newtonsoft.Json.Serialization;

    /// <summary>
    /// Defines the <see cref="TypeNameSerializationBinder" />
    /// </summary>
    public class TypeNameSerializationBinder : ISerializationBinder
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="TypeNameSerializationBinder"/> class.
        /// </summary>
        /// <param name="typeFormat">The <see cref="string"/></param>
        public TypeNameSerializationBinder(string typeFormat)
        {
            TypeFormat = typeFormat;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the TypeFormat
        /// </summary>
        public string TypeFormat
        {
            get;
            private set;
        }

        #endregion

        #region Methods

        /// <summary>
        /// The BindToName
        /// </summary>
        /// <param name="serializedType">The <see cref="Type"/></param>
        /// <param name="assemblyName">The <see cref="string"/></param>
        /// <param name="typeName">The <see cref="string"/></param>
        public void BindToName(Type serializedType, out string assemblyName, out string typeName)
        {
            assemblyName = null;
            typeName = serializedType.Name;
        }

        /// <summary>
        /// The BindToType
        /// </summary>
        /// <param name="assemblyName">The <see cref="string"/></param>
        /// <param name="typeName">The <see cref="string"/></param>
        /// <returns>The <see cref="Type"/></returns>
        public Type BindToType(string assemblyName, string typeName)
        {
            var resolvedTypeName = string.Format(TypeFormat, typeName);
            return Type.GetType(resolvedTypeName, true);
        }

        #endregion
    }
}
