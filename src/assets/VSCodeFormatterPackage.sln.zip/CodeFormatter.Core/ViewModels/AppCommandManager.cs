﻿namespace CodeFormatter.Core.ViewModels
{
    using CodeFormatter.Core.Syntaxs.MemberGroups;

    /// <summary>
    /// Defines the <see cref = "CommandManager"/>
    /// </summary>
    public static class AppCommandManager
    {
        #region Properties

        /// <summary>
        /// Gets or sets the MemberGroup
        /// </summary>
        public static IMemberGroup MemberGroup
        {
            get;
            set;
        }

        #endregion
    }
}
