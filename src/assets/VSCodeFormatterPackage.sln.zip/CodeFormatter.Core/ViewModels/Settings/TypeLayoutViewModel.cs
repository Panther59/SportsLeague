// <copyright file="TypeLayoutViewModel.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>02-08-2017</date>

namespace CodeFormatter.Core.ViewModels.Settings
{
    using System;
    using System.IO;
    using System.Threading.Tasks;
    using CodeFormatter.Common;
    using CodeFormatter.Common.Entities;
    using CodeFormatter.Core.Binders;
    using CodeFormatter.Core.Startup;
    using CodeFormatter.Core.Syntaxs.MemberGroups;
    using Newtonsoft.Json;
    using Unity;

    /// <summary>
    /// Defines the <see cref = "TypeLayoutViewModel"/>
    /// </summary>
    public class TypeLayoutViewModel : BaseViewModel
    {
        #region Fields

        /// <summary>
        /// The isBusy field
        /// </summary>
        private bool isBusy;

        /// <summary>
        /// The rootGroup field
        /// </summary>
        private IMemberGroupCollection rootGroup;

        /// <summary>
        /// The title field
        /// </summary>
        private string title;

        #region Commands

        /// <summary>
        /// The defaultWithouRegionCommand field
        /// </summary>
        private RelayCommand defaultWithoutRegionCommand;

        /// <summary>
        /// The defaultWithRegionCommand field
        /// </summary>
        private RelayCommand defaultWithRegionCommand;

        /// <summary>
        /// The removeMemberGroupCommand field
        /// </summary>
        private RelayCommand<IMemberGroup> removeMemberGroupCommand;

        #endregion

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "TypeLayoutViewModel"/> class.
        /// </summary>
        public TypeLayoutViewModel()
        {
            this.RootGroup = UnityConfig.Container.Resolve<IMemberGroupCollection>(Constants.And + Constants.VM);
            this.RootGroup.Name = "Root";
            this.RootGroup.MemberGroups = new System.Collections.Generic.List<IMemberGroup>();
            var existingData = AppGlobal.GetTypeLayout();
            var typeLayout = existingData ?? UnityConfig.Container.Resolve<IMemberGroup>(Constants.And + Constants.VM);
            typeLayout.Name = "Type Layout";
            this.RootGroup.MemberGroups.Add(typeLayout);
            this.Title = "Type Layout";
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets a value indicating whether IsBusy
        /// </summary>
        public bool IsBusy
        {
            get
            {
                return this.isBusy;
            }

            set
            {
                this.isBusy = value;
                this.OnPropertyChanged("IsBusy");
            }
        }

        /// <summary>
        /// Gets or sets the RootGroup
        /// </summary>
        public IMemberGroupCollection RootGroup
        {
            get
            {
                return this.rootGroup;
            }

            set
            {
                this.rootGroup = value;
                this.OnPropertyChanged("RootGroup");
            }
        }

        /// <summary>
        /// Gets or sets the Title
        /// </summary>
        public string Title
        {
            get
            {
                return this.title;
            }

            set
            {
                this.title = value;
                this.OnPropertyChanged("Title");
            }
        }

        #region Commands

        /// <summary>
        /// Gets the DefaultWithoutRegionCommand
        /// </summary>
        public RelayCommand DefaultWithoutRegionCommand
        {
            get
            {
                if (this.defaultWithoutRegionCommand == null)
                {
                    this.defaultWithoutRegionCommand = new RelayCommand(command => this.ExecuteDefaultWithoutRegion());
                }

                return this.defaultWithoutRegionCommand;
            }
        }

        /// <summary>
        /// Gets the DefaultWithRegionCommand
        /// </summary>
        public RelayCommand DefaultWithRegionCommand
        {
            get
            {
                if (this.defaultWithRegionCommand == null)
                {
                    this.defaultWithRegionCommand = new RelayCommand(command => this.ExecuteDefaultWithRegion());
                }

                return this.defaultWithRegionCommand;
            }
        }

        /// <summary>
        /// Gets the RemoveMemberGroupCommand
        /// </summary>
        public RelayCommand<IMemberGroup> RemoveMemberGroupCommand
        {
            get
            {
                if (this.removeMemberGroupCommand == null)
                {
                    this.removeMemberGroupCommand = new RelayCommand<IMemberGroup>(command => this.ExecuteRemoveMemberGroup(command), can => this.CanRemoveMemberGroupExecute());
                }

                return this.removeMemberGroupCommand;
            }
        }

        #endregion

        #endregion

        #region Methods

        #region Private Methods

        /// <summary>
        /// Determines whether RemoveMemberGroup can be executed or not
        /// </summary>
        private bool CanRemoveMemberGroupExecute()
        {
            return true;
        }

        /// <summary>
        /// Executes ExecuteDefaultWithoutRegion
        /// </summary>
        private async void ExecuteDefaultWithoutRegion()
        {
            Task.Run(() =>
            {
                var defaultFilePath = AppGlobal.GetDefaultLayoutFolderPath() + "DefaultWithoutRegion.txt";
                this.LoadContentFromFile(defaultFilePath);
            });
        }

        /// <summary>
        /// Executes DefaultWithRegion
        /// </summary>
        private async void ExecuteDefaultWithRegion()
        {
            Task.Run(() =>
            {
                var defaultFilePath = AppGlobal.GetDefaultLayoutFolderPath() + "DefaultWithRegion.txt";
                this.LoadContentFromFile(defaultFilePath);
            });
        }

        /// <summary>
        /// Executes RemoveMemberGroup
        /// </summary>
        private void ExecuteRemoveMemberGroup(IMemberGroup input)
        {
        }

        /// <summary>
        /// The LoadContentFromFile
        /// </summary>
        /// <param name = "file">The <see cref = "string "/></param>
        private void LoadContentFromFile(string file)
        {
            try
            {
                this.IsBusy = true;
                FileInfo defInfo = new FileInfo(file);
                if (defInfo.Exists)
                {
                    string json = File.ReadAllText(file);
                    var obj = AppGlobal.GetTypeLayout(json);
                    var groups = new System.Collections.Generic.List<IMemberGroup>()
                    {obj};
                    this.RootGroup.MemberGroups = groups;
                }
            }
            catch (Exception ex)
            {
                this.LogException(ex);
            }
            finally
            {
                this.IsBusy = false;
            }
        }

        /// <summary>
        /// The LoadLayout
        /// </summary>
        /// <returns>The <see cref = "AndMemberGroupCollection"/></returns>
        private AndMemberGroupCollection LoadLayout()
        {
            try
            {
                var binder = new TypeNameSerializationBinder("CodeFormatter.Core.Syntaxs.MemberGroups.{0}, CodeFormatter.Core");
                var file = AppGlobal.TypeLayoutFile;
                FileInfo info = new FileInfo(file);
                if (info.Exists)
                {
                    string json = File.ReadAllText(file);
                    json = json.Replace("ViewModel\"", "\"");
                    var obj = JsonConvert.DeserializeObject<AndMemberGroupCollection>(json, new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.Auto, NullValueHandling = NullValueHandling.Ignore, SerializationBinder = binder });
                    return obj;
                }
                else
                {
                    var defaultFilePath = AppGlobal.GetDefaultLayoutFolderPath() + "\\DefaultWithRegion.txt";
                    FileInfo defInfo = new FileInfo(defaultFilePath);
                    if (defInfo.Exists)
                    {
                        string json = File.ReadAllText(file);
                        AppGlobal.SaveTypeLayout(json);
                        return LoadLayout();
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        #endregion

        #endregion
    }
}
