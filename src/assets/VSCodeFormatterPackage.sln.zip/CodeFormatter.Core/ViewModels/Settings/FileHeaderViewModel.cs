﻿namespace CodeFormatter.Core.ViewModels.Settings
{
    using CodeFormatter.Common.Contracts;
    using CodeFormatter.Common.Entities;
    using Newtonsoft.Json;
    using System.Collections.Generic;

    /// <summary>
    /// Defines the <see cref = "FileHeaderViewModel"/>
    /// </summary>
    public class FileHeaderViewModel : BaseViewModel, IFileHeaderSettings
    {
        #region Fields

        /// <summary>
        /// The addFileHeader field
        /// </summary>
        private bool addFileHeader;

        /// <summary>
        /// The header field
        /// </summary>
        private string header;

        /// <summary>
        /// The replacements field
        /// </summary>
        private List<string> replacements;

        /// <summary>
        /// The selection field
        /// </summary>
        private string selection;

        #region Commands

        /// <summary>
        /// The addReplacementCommand field
        /// </summary>
        private RelayCommand<string> addReplacementCommand;

        #endregion

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "FileHeaderViewModel"/> class.
        /// </summary>
        public FileHeaderViewModel()
        {
            this.Replacements = new List<string>()
            {"File Name", "Current Year", "Current Month", "Current Day", "Current Date", "Current Date Time", "User Name"};
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets a value indicating whether AddFileHeader
        /// </summary>
        public bool AddFileHeader
        {
            get
            {
                return this.addFileHeader;
            }

            set
            {
                this.addFileHeader = value;
                this.OnPropertyChanged("AddFileHeader");
            }
        }

        /// <summary>
        /// Gets or sets the Header
        /// </summary>
        public string Header
        {
            get
            {
                return this.header;
            }

            set
            {
                this.header = value;
                this.OnPropertyChanged("Header");
            }
        }

        /// <summary>
        /// Gets or sets the Replacements
        /// </summary>
        [JsonIgnore]
        public List<string> Replacements
        {
            get
            {
                return this.replacements;
            }

            set
            {
                this.replacements = value;
                this.OnPropertyChanged("Replacements");
            }
        }

        /// <summary>
        /// Gets or sets the Selection
        /// </summary>
        [JsonIgnore]
        public string Selection
        {
            get
            {
                return this.selection;
            }

            set
            {
                this.selection = value;
                this.OnPropertyChanged("Selection");
            }
        }

        #region Commands

        /// <summary>
        /// Gets the AddReplacementCommand
        /// </summary>
        [JsonIgnore]
        public RelayCommand<string> AddReplacementCommand
        {
            get
            {
                if (this.addReplacementCommand == null)
                {
                    this.addReplacementCommand = new RelayCommand<string>(command => this.ExecuteAddReplacement(command));
                }

                return this.addReplacementCommand;
            }
        }

        #endregion

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// The SaveSettings
        /// </summary>
        public void SaveSettings()
        {
            AppGlobal.SaveFileHeaderSettings(this);
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Executes AddReplacement
        /// </summary>
        private void ExecuteAddReplacement(string input)
        {
            this.Selection = string.Format("${0}$", input);
        }

        #endregion

        #endregion
    }
}