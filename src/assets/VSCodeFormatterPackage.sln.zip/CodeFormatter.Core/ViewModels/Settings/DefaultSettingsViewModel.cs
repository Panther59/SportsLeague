﻿// <copyright file="DefaultSettingsViewModel" company="Avanade">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>29-07-2017</date>

namespace CodeFormatter.Core.ViewModels.Settings
{
    using System.Collections.Generic;
    using CodeFormatter.Common.Contracts;
    using CodeFormatter.Common.Entities;
    using Newtonsoft.Json;

    /// <summary>
    /// Defines the <see cref = "DefaultSettingsViewModel"/>
    /// </summary>
    public class DefaultSettingsViewModel : BaseViewModel, IDefaultSettings
    {
        #region Fields

        /// <summary>
        /// The addClassHeader field
        /// </summary>
        private bool addClassHeader = true;

        /// <summary>
        /// The addConstructorHeader field
        /// </summary>
        private bool addConstructorHeader = true;

        /// <summary>
        /// The addDelegateHeader field
        /// </summary>
        private bool addDelegateHeader = true;

        /// <summary>
        /// The addEnumHeader field
        /// </summary>
        private bool addEnumHeader = true;

        /// <summary>
        /// The addEventHeader field
        /// </summary>
        private bool addEventHeader = true;

        /// <summary>
        /// The addFieldHeader field
        /// </summary>
        private bool addFieldHeader = true;

        /// <summary>
        /// The addMethodHeader field
        /// </summary>
        private bool addMethodHeader = true;

        /// <summary>
        /// The addMissingAccessModifier field
        /// </summary>
        private bool addMissingAccessModifier = true;

        /// <summary>
        /// The addPropertyHeader field
        /// </summary>
        private bool addPropertyHeader = true;

        /// <summary>
        /// The availabledModifiers field
        /// </summary>
        private List<string> availabledModifiers;

        /// <summary>
        /// The defaultAccessModifer field
        /// </summary>
        private string defaultAccessModifer = "internal";

        /// <summary>
        /// The moveUsingInsideNamespace field
        /// </summary>
        private bool moveUsingInsideNamespace = true;

        /// <summary>
        /// The removeUnwantedUsings field
        /// </summary>
        private bool removeUnwantedUsings = true;

        /// <summary>
        /// The statementFixes field
        /// </summary>
        private bool statementFixes = false;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "DefaultSettingsViewModel"/> class.
        /// </summary>
        public DefaultSettingsViewModel()
        {
            this.LoadData();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the AddClassHeader
        /// </summary>
        public bool AddClassHeader
        {
            get
            {
                return this.addClassHeader;
            }

            set
            {
                this.addClassHeader = value;
                this.OnPropertyChanged("AddClassHeader");
            }
        }

        /// <summary>
        /// Gets or sets the AddConstructorHeader
        /// </summary>
        public bool AddConstructorHeader
        {
            get
            {
                return this.addConstructorHeader;
            }

            set
            {
                this.addConstructorHeader = value;
                this.OnPropertyChanged("AddConstructorHeader");
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether AddDelegateHeader
        /// </summary>
        public bool AddDelegateHeader
        {
            get
            {
                return this.addDelegateHeader;
            }

            set
            {
                this.addDelegateHeader = value;
                this.OnPropertyChanged("AddDelegateHeader");
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether AddEnumHeader
        /// </summary>
        public bool AddEnumHeader
        {
            get
            {
                return this.addEnumHeader;
            }

            set
            {
                this.addEnumHeader = value;
                this.OnPropertyChanged("AddEnumHeader");
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether AddEventHeader
        /// </summary>
        public bool AddEventHeader
        {
            get
            {
                return this.addEventHeader;
            }

            set
            {
                this.addEventHeader = value;
                this.OnPropertyChanged("AddEventHeader");
            }
        }

        /// <summary>
        /// Gets or sets the AddFieldHeader
        /// </summary>
        public bool AddFieldHeader
        {
            get
            {
                return this.addFieldHeader;
            }

            set
            {
                this.addFieldHeader = value;
                this.OnPropertyChanged("AddFieldHeader");
            }
        }

        /// <summary>
        /// Gets or sets the AddMethodHeader
        /// </summary>
        public bool AddMethodHeader
        {
            get
            {
                return this.addMethodHeader;
            }

            set
            {
                this.addMethodHeader = value;
                this.OnPropertyChanged("AddMethodHeader");
            }
        }

        /// <summary>
        /// Gets or sets the AddMissingAccessModifier
        /// </summary>
        public bool AddMissingAccessModifier
        {
            get
            {
                return this.addMissingAccessModifier;
            }

            set
            {
                this.addMissingAccessModifier = value;
                this.OnPropertyChanged("AddMissingAccessModifier");
            }
        }

        /// <summary>
        /// Gets or sets the AddPropertyHeader
        /// </summary>
        public bool AddPropertyHeader
        {
            get
            {
                return this.addPropertyHeader;
            }

            set
            {
                this.addPropertyHeader = value;
                this.OnPropertyChanged("AddPropertyHeader");
            }
        }

        /// <summary>
        /// Gets or sets the AvailabledModifiers
        /// </summary>
        [JsonIgnore]
        public List<string> AvailabledModifiers
        {
            get
            {
                return this.availabledModifiers;
            }

            set
            {
                this.availabledModifiers = value;
                this.OnPropertyChanged("AvailabledModifiers");
            }
        }

        /// <summary>
        /// Gets or sets the DefaultAccessModifer
        /// </summary>
        public string DefaultAccessModifier
        {
            get
            {
                return this.defaultAccessModifer;
            }

            set
            {
                this.defaultAccessModifer = value;
                this.OnPropertyChanged("DefaultAccessModifer");
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether IsFirstLaunch
        /// </summary>
        public bool IsFirstLaunch { get; set; }

        /// <summary>
        /// Gets or sets the MoveUsingInsideNamespace
        /// </summary>
        public bool MoveUsingInsideNamespace
        {
            get
            {
                return this.moveUsingInsideNamespace;
            }

            set
            {
                this.moveUsingInsideNamespace = value;
                this.OnPropertyChanged("MoveUsingInsideNamespace");
            }
        }

        /// <summary>
        /// Gets or sets the RemoveUnwantedUsings
        /// </summary>
        public bool RemoveUnwantedUsings
        {
            get
            {
                return this.removeUnwantedUsings;
            }

            set
            {
                this.removeUnwantedUsings = value;
                this.OnPropertyChanged("RemoveUnwantedUsings");
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether StatementFixes
        /// </summary>
        public bool StatementFixes
        {
            get
            {
                return this.statementFixes;
            }

            set
            {
                this.statementFixes = value;
                this.OnPropertyChanged("StatementFixes");
            }
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// The Save
        /// </summary>
        public void Save()
        {
            AppGlobal.SaveDefaultSettings(this);
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// The LoadData
        /// </summary>
        private void LoadData()
        {
            this.AvailabledModifiers = new List<string>() { "public", "internal", "protected internal", "protected", "private" };
        }

        #endregion

        #endregion
    }
}
