﻿namespace CodeFormatter.Core.ViewModels.Settings
{
    using CodeFormatter.Common.Contracts;
    using CodeFormatter.Common.Entities;

    /// <summary>
    /// Defines the <see cref = "SettingsViewModel"/>
    /// </summary>
    public class SettingsViewModel : BaseViewModel
    {
        #region Fields

        /// <summary>
        /// The defaultSetting field
        /// </summary>
        private DefaultSettingsViewModel defaultSetting;

        /// <summary>
        /// The fileHeader field
        /// </summary>
        private FileHeaderViewModel fileHeader;

        /// <summary>
        /// The typeLayout field
        /// </summary>
        private TypeLayoutViewModel typeLayout;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="SettingsViewModel"/> class.
        /// </summary>
        /// <param name="defaultSettings">The <see cref="IDefaultSettings"/></param>
        /// <param name="fileHeader">The <see cref="IFileHeaderSettings"/></param>
        /// <param name="typeLayout">The <see cref="TypeLayoutViewModel"/></param>
        public SettingsViewModel(IDefaultSettings defaultSettings, TypeLayoutViewModel typeLayout)
        {
            this.DefaultSetting = defaultSettings as DefaultSettingsViewModel;
            this.FileHeader = AppGlobal.FileHeaderSettings as FileHeaderViewModel;
            this.TypeLayout = typeLayout;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the DefaultSetting
        /// </summary>
        public DefaultSettingsViewModel DefaultSetting
        {
            get
            {
                return this.defaultSetting;
            }

            set
            {
                this.defaultSetting = value;
                this.OnPropertyChanged("DefaultSetting");
            }
        }

        /// <summary>
        /// Gets or sets the FileHeader
        /// </summary>
        public FileHeaderViewModel FileHeader
        {
            get
            {
                return this.fileHeader;
            }

            set
            {
                this.fileHeader = value;
                this.OnPropertyChanged("FileHeader");
            }
        }

        /// <summary>
        /// Gets or sets the TypeLayout
        /// </summary>
        public TypeLayoutViewModel TypeLayout
        {
            get
            {
                return this.typeLayout;
            }

            set
            {
                this.typeLayout = value;
                this.OnPropertyChanged("TypeLayout");
            }
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// The SaveSettings
        /// </summary>
        public void SaveSettings()
        {
            AppGlobal.SaveTypeLayout(this.TypeLayout.RootGroup.MemberGroups[0]);
            this.FileHeader.SaveSettings();
            this.DefaultSetting.Save();
        }

        #endregion

        #endregion
    }
}