namespace CodeFormatter.Core.ViewModels.MemberGroups
{
    using CodeFormatter.Common;

    /// <summary>
    /// Defines the <see cref = "AndMemberGroupCollectionViewModel"/>
    /// </summary>
    public class AndMemberGroupCollectionViewModel : BaseMemberGroupViewModel
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "AndMemberGroupCollectionViewModel"/> class.
        /// </summary>
        public AndMemberGroupCollectionViewModel()
        {
            this.Name = Constants.And;
        }

        #endregion
    }
}
