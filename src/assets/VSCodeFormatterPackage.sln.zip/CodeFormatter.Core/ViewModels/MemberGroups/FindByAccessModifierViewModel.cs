// <copyright file="FindByAccessModifierViewModel.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>18-08-2017</date>

namespace CodeFormatter.Core.ViewModels.MemberGroups
{
    using System.Collections.Generic;
    using CodeFormatter.Common;
    using Newtonsoft.Json;

    /// <summary>
    /// Defines the <see cref = "FindByAccessModifierViewModel"/>
    /// </summary>
    public class FindByAccessModifierViewModel : FindMemberConditionViewModel
    {
        #region Fields

        /// <summary>
        /// The accessModifier field
        /// </summary>
        private string accessModifier;

        /// <summary>
        /// The availabledModifiers field
        /// </summary>
        private List<string> availabledModifiers;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "FindByTypeViewModel"/> class.
        /// </summary>
        public FindByAccessModifierViewModel()
        {
            this.Name = Constants.AccessModifier;
            this.LoadData();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the AccessModifier
        /// </summary>
        public string AccessModifier
        {
            get
            {
                return this.accessModifier;
            }

            set
            {
                this.accessModifier = value;
                this.OnPropertyChanged("AccessModifier");
            }
        }

        /// <summary>
        /// Gets or sets the AvailabledModifiers
        /// </summary>
        [JsonIgnore]
        public List<string> AvailabledModifiers
        {
            get
            {
                return this.availabledModifiers;
            }

            set
            {
                this.availabledModifiers = value;
                this.OnPropertyChanged("AvailabledModifiers");
            }
        }

        #endregion

        #region Methods

        #region Private Methods

        /// <summary>
        /// The LoadData
        /// </summary>
        private void LoadData()
        {
            this.AvailabledModifiers = new List<string>()
            {
                "public",
                "internal",
                "protected internal",
                "protected",
                "private"
            };

            this.AccessModifier = this.AvailabledModifiers[0];
        }

        #endregion

        #endregion
    }
}
