// <copyright file="BaseMemberGroupViewModel.cs" company="Avanade">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>24-04-2018</date>

namespace CodeFormatter.Core.ViewModels.MemberGroups
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using CodeFormatter.Common;
    using CodeFormatter.Common.Contracts;
    using CodeFormatter.Common.Entities;
    using CodeFormatter.Core.Binders;
    using CodeFormatter.Core.Startup;
    using CodeFormatter.Core.Syntaxs.MemberGroups;
    using Newtonsoft.Json;
    using Unity;

    /// <summary>
    /// Defines the <see cref = "BaseMemberGroupViewModel"/>
    /// </summary>
    public abstract class BaseMemberGroupViewModel : BaseViewModel, IMemberGroupCollection
    {
        #region Fields

        /// <summary>
        /// Defines the resolver
        /// </summary>
        private readonly IResolver resolver;

        /// <summary>
        /// The memberGroups field
        /// </summary>
        private List<IMemberGroup> memberGroups;

        /// <summary>
        /// The name field
        /// </summary>
        private string name;

        /// <summary>
        /// The region field
        /// </summary>
        private string region;

        /// <summary>
        /// The regionSeparationLinesCount field
        /// </summary>
        private int regionSeparationLinesCount = 1;

        /// <summary>
        /// The separationLines field
        /// </summary>
        private List<int> separationLines;

        /// <summary>
        /// The surroundWithRegion field
        /// </summary>
        private bool surroundWithRegion;

        #region Commands

        /// <summary>
        /// The addMemberGroupCommand field
        /// </summary>
        private RelayCommand<string> addMemberGroupCommand;

        /// <summary>
        /// The copyMemberGroupCommand field
        /// </summary>
        private RelayCommand<IMemberGroup> copyMemberGroupCommand;

        /// <summary>
        /// The cutMemberGroupCommand field
        /// </summary>
        private RelayCommand<IMemberGroup> cutMemberGroupCommand;

        /// <summary>
        /// The moveDownMemberGroupCommand field
        /// </summary>
        private RelayCommand<IMemberGroup> moveDownMemberGroupCommand;

        /// <summary>
        /// The moveUpMemberGroupCommand field
        /// </summary>
        private RelayCommand<IMemberGroup> moveUpMemberGroupCommand;

        /// <summary>
        /// The pasteMemberGroupCommand field
        /// </summary>
        private RelayCommand pasteMemberGroupCommand;

        /// <summary>
        /// The regionEnabledCommand field
        /// </summary>
        private RelayCommand<bool> regionEnabledCommand;

        /// <summary>
        /// The removeMemberGroupCommand field
        /// </summary>
        private RelayCommand<IMemberGroup> removeMemberGroupCommand;

        #endregion

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "BaseMemberGroupViewModel"/> class.
        /// </summary>
        public BaseMemberGroupViewModel()
        {
            this.GUID = Guid.NewGuid().ToString();
            this.resolver = UnityConfig.Container.Resolve<IResolver>();
            this.SeparationLines = new List<int> { 0, 1, 2 };
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets GUID
        /// </summary>
        public string GUID { get; set; }

        /// <summary>
        /// Gets or sets the MemberGroups
        /// </summary>
        public List<IMemberGroup> MemberGroups
        {
            get
            {
                return this.memberGroups;
            }

            set
            {
                this.memberGroups = value;
                this.OnPropertyChanged("MemberGroups");
            }
        }

        /// <summary>
        /// Gets or sets the Name
        /// </summary>
        public string Name
        {
            get
            {
                return this.name;
            }

            set
            {
                this.name = value;
                this.OnPropertyChanged("Name");
            }
        }

        /// <summary>
        /// Gets or sets the Region
        /// </summary>
        public string Region
        {
            get
            {
                return this.region;
            }

            set
            {
                this.region = value;
                this.OnPropertyChanged("Region");
            }
        }

        /// <summary>
        /// Gets or sets the RegionSeparationLinesCount
        /// </summary>
        public int RegionSeparationLinesCount
        {
            get
            {
                return this.regionSeparationLinesCount;
            }

            set
            {
                this.regionSeparationLinesCount = value;
                this.OnPropertyChanged("RegionSeparationLinesCount");
            }
        }

        /// <summary>
        /// Gets the Resolver
        /// </summary>
        [JsonIgnore]
        public IResolver Resolver
        {
            get
            {
                return this.resolver;
            }
        }

        /// <summary>
        /// Gets or sets the SeparationLines
        /// </summary>
        [JsonIgnore]
        public List<int> SeparationLines
        {
            get
            {
                return this.separationLines;
            }

            set
            {
                this.separationLines = value;
                this.OnPropertyChanged("SeparationLines");
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether SurroundWithRegion
        /// </summary>
        public bool SurroundWithRegion
        {
            get
            {
                return this.surroundWithRegion;
            }

            set
            {
                this.surroundWithRegion = value;
                this.OnPropertyChanged("SurroundWithRegion");
            }
        }

        #region Commands

        /// <summary>
        /// Gets the AddMemberGroupCommand
        /// </summary>
        [JsonIgnore]
        public RelayCommand<string> AddMemberGroupCommand
        {
            get
            {
                if (this.addMemberGroupCommand == null)
                {
                    this.addMemberGroupCommand = new RelayCommand<string>(command => this.ExecuteAddMemberGroup(command));
                }

                return this.addMemberGroupCommand;
            }
        }

        /// <summary>
        /// Gets the CopyMemberGroupCommand
        /// </summary>
        [JsonIgnore]
        public RelayCommand<IMemberGroup> CopyMemberGroupCommand
        {
            get
            {
                if (this.copyMemberGroupCommand == null)
                {
                    this.copyMemberGroupCommand = new RelayCommand<IMemberGroup>(command => this.ExecuteCopyMemberGroup(command), can => this.CanCopyMemberGroupExecute(can));
                }

                return this.copyMemberGroupCommand;
            }
        }

        /// <summary>
        /// Gets the CutMemberGroupCommand
        /// </summary>
        [JsonIgnore]
        public RelayCommand<IMemberGroup> CutMemberGroupCommand
        {
            get
            {
                if (this.cutMemberGroupCommand == null)
                {
                    this.cutMemberGroupCommand = new RelayCommand<IMemberGroup>(command => this.ExecuteCutMemberGroup(command), can => this.CanCutMemberGroupExecute(can));
                }

                return this.cutMemberGroupCommand;
            }
        }

        /// <summary>
        /// Gets the MoveDownMemberGroupCommand
        /// </summary>
        [JsonIgnore]
        public RelayCommand<IMemberGroup> MoveDownMemberGroupCommand
        {
            get
            {
                if (this.moveDownMemberGroupCommand == null)
                {
                    this.moveDownMemberGroupCommand = new RelayCommand<IMemberGroup>(command => this.ExecuteMoveDownMemberGroup(command), can => this.CanMoveDownMemberGroupExecute(can));
                }

                return this.moveDownMemberGroupCommand;
            }
        }

        /// <summary>
        /// Gets the MoveUpMemberGroupCommand
        /// </summary>
        [JsonIgnore]
        public RelayCommand<IMemberGroup> MoveUpMemberGroupCommand
        {
            get
            {
                if (this.moveUpMemberGroupCommand == null)
                {
                    this.moveUpMemberGroupCommand = new RelayCommand<IMemberGroup>(command => this.ExecuteMoveUpMemberGroup(command), can => this.CanMoveUpMemberGroupExecute(can));
                }

                return this.moveUpMemberGroupCommand;
            }
        }

        /// <summary>
        /// Gets the PasteMemberGroupCommand
        /// </summary>
        [JsonIgnore]
        public RelayCommand PasteMemberGroupCommand
        {
            get
            {
                if (this.pasteMemberGroupCommand == null)
                {
                    this.pasteMemberGroupCommand = new RelayCommand(command => this.ExecutePasteMemberGroup(), can => CanPasteMemberGroupExecute());
                }

                return this.pasteMemberGroupCommand;
            }
        }

        /// <summary>
        /// Gets the RegionEnabledCommand
        /// </summary>
        [JsonIgnore]
        public RelayCommand<bool> RegionEnabledCommand
        {
            get
            {
                if (this.regionEnabledCommand == null)
                {
                    this.regionEnabledCommand = new RelayCommand<bool>(command => this.ExecuteRegionEnabled(command));
                }

                return this.regionEnabledCommand;
            }
        }

        /// <summary>
        /// Gets the RemoveMemberGroupCommand
        /// </summary>
        [JsonIgnore]
        public RelayCommand<IMemberGroup> RemoveMemberGroupCommand
        {
            get
            {
                if (this.removeMemberGroupCommand == null)
                {
                    this.removeMemberGroupCommand = new RelayCommand<IMemberGroup>(command => this.ExecuteRemoveMemberGroup(command), can => this.CanRemoveMemberGroupExecute());
                }

                return this.removeMemberGroupCommand;
            }
        }

        #endregion

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// The AddMemberGroup
        /// </summary>
        /// <param name = "item">The <see cref = "IMemberGroup"/></param>
        public void AddMemberGroup(IMemberGroup item)
        {
            var memberGroups = this.MemberGroups;
            if (memberGroups == null)
            {
                memberGroups = new List<IMemberGroup>();
            }

            memberGroups.Add(item);
            this.MemberGroups = new List<IMemberGroup>(memberGroups);
        }

        /// <summary>
        /// The RemoveMemberGroup
        /// </summary>
        /// <param name = "item">The <see cref = "IMemberGroup"/></param>
        public void RemoveMemberGroup(IMemberGroup item)
        {
            var memberGroups = this.MemberGroups;
            memberGroups.Remove(item);
            this.MemberGroups = new List<IMemberGroup>(memberGroups);
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Determines whether CopyMemberGroup can be executed or not
        /// </summary>
        private bool CanCopyMemberGroupExecute(IMemberGroup input)
        {
            return input != null;
        }

        /// <summary>
        /// Determines whether CutMemberGroup can be executed or not
        /// </summary>
        private bool CanCutMemberGroupExecute(IMemberGroup input)
        {
            return input != null;
        }

        /// <summary>
        /// Determines whether MoveDownMemberGroup can be executed or not
        /// </summary>
        private bool CanMoveDownMemberGroupExecute(IMemberGroup input)
        {
            var index = this.FindSelectedMemberGroupIndex(input);
            if (index != -1 && this.MemberGroups != null && index < this.MemberGroups.Count - 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Determines whether MoveUpMemberGroup can be executed or not
        /// </summary>
        private bool CanMoveUpMemberGroupExecute(IMemberGroup input)
        {
            var index = this.FindSelectedMemberGroupIndex(input);
            if (index != -1 && this.MemberGroups != null && index > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// The CanPasteMemberGroupExecute
        /// </summary>
        /// <returns>The <see cref = "bool "/></returns>
        private bool CanPasteMemberGroupExecute()
        {
            return AppCommandManager.MemberGroup != null;
        }

        /// <summary>
        /// Determines whether RemoveMemberGroup can be executed or not
        /// </summary>
        private bool CanRemoveMemberGroupExecute()
        {
            return true;
        }

        /// <summary>
        /// Executes AddMemberGroup
        /// </summary>
        private void ExecuteAddMemberGroup(string input)
        {
            var memberGroup = this.Resolver.Resolve<IMemberGroup>(input + Constants.VM);
            memberGroup.Name = input;
            this.AddMemberGroup(memberGroup);
        }

        /// <summary>
        /// Executes CopyMemberGroup
        /// </summary>
        private void ExecuteCopyMemberGroup(IMemberGroup input)
        {
            AppCommandManager.MemberGroup = this.GetCloneObject(input);
        }

        /// <summary>
        /// Executes CutMemberGroup
        /// </summary>
        private void ExecuteCutMemberGroup(IMemberGroup input)
        {
            AppCommandManager.MemberGroup = this.GetCloneObject(input);
            this.RemoveMemberGroup(input);
        }

        /// <summary>
        /// Executes MoveDownMemberGroup
        /// </summary>
        private void ExecuteMoveDownMemberGroup(IMemberGroup input)
        {
            int index = this.FindSelectedMemberGroupIndex(input);
            var memberGroups = this.MemberGroups;
            if (memberGroups == null)
            {
                memberGroups = new List<IMemberGroup>();
            }

            var ops = memberGroups[index];
            memberGroups.RemoveAt(index);
            memberGroups.Insert(index + 1, ops);
            this.MemberGroups = new List<IMemberGroup>(memberGroups);
        }

        /// <summary>
        /// Executes MoveUpMemberGroup
        /// </summary>
        private void ExecuteMoveUpMemberGroup(IMemberGroup input)
        {
            int index = this.FindSelectedMemberGroupIndex(input);
            var memberGroups = this.MemberGroups;
            if (memberGroups == null)
            {
                memberGroups = new List<IMemberGroup>();
            }

            var ops = memberGroups[index];
            memberGroups.RemoveAt(index);
            memberGroups.Insert(index - 1, ops);
            this.MemberGroups = new List<IMemberGroup>(memberGroups);
        }

        /// <summary>
        /// Executes PasteMemberGroup
        /// </summary>
        private void ExecutePasteMemberGroup()
        {
            this.AddMemberGroup(AppCommandManager.MemberGroup);
            AppCommandManager.MemberGroup = null;
        }

        /// <summary>
        /// Executes RegionEnabled
        /// </summary>
        private void ExecuteRegionEnabled(bool input)
        {
            if (input)
            {
                var member = this.MemberGroups?.FirstOrDefault(x => x is MemberLayoutViewModel) as MemberLayoutViewModel;
                var kind = member?.Conditions?.FirstOrDefault(x => x is FindByKindViewModel) as FindByKindViewModel;
                this.Region = kind != null ? kind.Kind.ToString() : string.Empty;
            }
            else
            {
                this.region = string.Empty;
            }
        }

        /// <summary>
        /// Executes RemoveMemberGroup
        /// </summary>
        private void ExecuteRemoveMemberGroup(IMemberGroup input)
        {
            this.RemoveMemberGroup(input);
        }

        /// <summary>
        /// The FindSelectedMemberGroupIndex
        /// </summary>
        /// <param name = "memberGroup">The <see cref = "IMemberGroup"/></param>
        /// <returns>The <see cref = "int "/></returns>
        private int FindSelectedMemberGroupIndex(IMemberGroup memberGroup)
        {
            int index = -1;
            if (memberGroup != null && this.MemberGroups != null)
            {
                index = this.MemberGroups.IndexOf(memberGroup);
            }

            return index;
        }

        /// <summary>
        /// The GetCloneObject
        /// </summary>
        /// <param name = "input">The <see cref = "IMemberGroup"/></param>
        /// <returns>The <see cref = "IMemberGroup"/></returns>
        private IMemberGroup GetCloneObject(IMemberGroup input)
        {
            IMemberGroup output = GetCloneObject<BaseMemberGroupViewModel>(input as BaseMemberGroupViewModel);
            if (output != null)
            {
                return output;
            }

            output = GetCloneObject<MemberLayoutViewModel>(input as MemberLayoutViewModel);
            if (output != null)
            {
                return output;
            }

            return null;
        }

        /// <summary>
        /// The GetCloneObject
        /// </summary>
        /// <param name = "input">The <see cref = "T"/></param>
        /// <returns>The <see cref = "T"/></returns>
        private T GetCloneObject<T>(T input)
        {
            var binder = new TypeNameSerializationBinder("CodeFormatter.Core.ViewModels.MemberGroups.{0}, CodeFormatter.Core");
            string json = JsonConvert.SerializeObject(input, Formatting.Indented, new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.Auto, SerializationBinder = binder });
            var obj = JsonConvert.DeserializeObject<T>(json, new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.Auto, SerializationBinder = binder });
            return obj;
        }

        #endregion

        #endregion
    }
}
