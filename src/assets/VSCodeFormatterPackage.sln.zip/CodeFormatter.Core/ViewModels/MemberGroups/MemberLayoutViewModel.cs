// <copyright file="MemberLayoutViewModel.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>18-08-2017</date>

namespace CodeFormatter.Core.ViewModels.MemberGroups
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using CodeFormatter.Common;
    using CodeFormatter.Common.Contracts;
    using CodeFormatter.Common.Entities;
    using CodeFormatter.Core.Startup;
    using CodeFormatter.Core.Syntaxs.MemberGroups;
    using Newtonsoft.Json;
    using Unity;

    /// <summary>
    /// Defines the <see cref = "MemberLayoutViewModel"/>
    /// </summary>
    public class MemberLayoutViewModel : BaseViewModel, IMemberLayout
    {
        #region Fields

        /// <summary>
        /// Defines the resolver
        /// </summary>
        private readonly IResolver resolver;

        /// <summary>
        /// The conditions field
        /// </summary>
        private List<ICondition> conditions;

        /// <summary>
        /// The memberSeparationLinesCount field
        /// </summary>
        private int memberSeparationLinesCount = 1;

        /// <summary>
        /// The name field
        /// </summary>
        private string name;

        /// <summary>
        /// The region field
        /// </summary>
        private string region;

        /// <summary>
        /// The regionSeparationLinesCount field
        /// </summary>
        private int regionSeparationLinesCount = 1;

        /// <summary>
        /// The selectedCondition field
        /// </summary>
        private ICondition selectedCondition;

        /// <summary>
        /// The selectedSorting field
        /// </summary>
        private ISort selectedSorting;

        /// <summary>
        /// The separationLines field
        /// </summary>
        private List<int> separationLines;

        /// <summary>
        /// The sortings field
        /// </summary>
        private List<ISort> sortings;

        /// <summary>
        /// The surroundWithRegion field
        /// </summary>
        private bool surroundWithRegion;

        #region Commands

        /// <summary>
        /// The addConditionCommand field
        /// </summary>
        private RelayCommand<string> addConditionCommand;

        /// <summary>
        /// The addSortingCommand field
        /// </summary>
        private RelayCommand<string> addSortingCommand;

        /// <summary>
        /// The moveDownConditionCommand field
        /// </summary>
        private RelayCommand moveDownConditionCommand;

        /// <summary>
        /// The moveDownSortingCommand field
        /// </summary>
        private RelayCommand moveDownSortingCommand;

        /// <summary>
        /// The moveUpConditionCommand field
        /// </summary>
        private RelayCommand moveUpConditionCommand;

        /// <summary>
        /// The moveUpSortingCommand field
        /// </summary>
        private RelayCommand moveUpSortingCommand;

        /// <summary>
        /// The regionEnabledCommand field
        /// </summary>
        private RelayCommand<bool> regionEnabledCommand;

        /// <summary>
        /// The removeConditionCommand field
        /// </summary>
        private RelayCommand<ICondition> removeConditionCommand;

        /// <summary>
        /// The removeSortingCommand field
        /// </summary>
        private RelayCommand<ISort> removeSortingCommand;

        #endregion

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "MemberLayoutViewModel"/> class.
        /// </summary>
        public MemberLayoutViewModel()
        {
            this.Name = "Member";
            this.GUID = Guid.NewGuid().ToString();
            this.resolver = UnityConfig.Container.Resolve<IResolver>();
            this.LoadData();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the Conditions
        /// </summary>
        public List<ICondition> Conditions
        {
            get
            {
                return this.conditions;
            }

            set
            {
                this.conditions = value;
                this.OnPropertyChanged("Conditions");
            }
        }

        /// <summary>
        /// Gets or sets GUID
        /// </summary>
        public string GUID { get; set; }

        /// <summary>
        /// Gets or sets the MemberSeparationLinesCount
        /// </summary>
        public int MemberSeparationLinesCount
        {
            get
            {
                return this.memberSeparationLinesCount;
            }

            set
            {
                this.memberSeparationLinesCount = value;
                this.OnPropertyChanged("MemberSeparationLinesCount");
            }
        }

        /// <summary>
        /// Gets or sets the Name
        /// </summary>
        public string Name
        {
            get
            {
                return this.name;
            }

            set
            {
                this.name = value;
                this.OnPropertyChanged("Name");
            }
        }

        /// <summary>
        /// Gets or sets the Region
        /// </summary>
        public string Region
        {
            get
            {
                return this.region;
            }

            set
            {
                this.region = value;
                this.OnPropertyChanged("Region");
            }
        }

        /// <summary>
        /// Gets or sets the RegionSeparationLinesCount
        /// </summary>
        public int RegionSeparationLinesCount
        {
            get
            {
                return this.regionSeparationLinesCount;
            }

            set
            {
                this.regionSeparationLinesCount = value;
                this.OnPropertyChanged("RegionSeparationLinesCount");
            }
        }

        /// <summary>
        /// Gets or sets the SelectedCondition
        /// </summary>
        [JsonIgnore]
        public ICondition SelectedCondition
        {
            get
            {
                return this.selectedCondition;
            }

            set
            {
                this.selectedCondition = value;
                this.OnPropertyChanged("SelectedCondition");
            }
        }

        /// <summary>
        /// Gets or sets the SelectedSorting
        /// </summary>
        [JsonIgnore]
        public ISort SelectedSorting
        {
            get
            {
                return this.selectedSorting;
            }

            set
            {
                this.selectedSorting = value;
                this.OnPropertyChanged("SelectedSorting");
            }
        }

        /// <summary>
        /// Gets or sets the SeparationLines
        /// </summary>
        [JsonIgnore]
        public List<int> SeparationLines
        {
            get
            {
                return this.separationLines;
            }

            set
            {
                this.separationLines = value;
                this.OnPropertyChanged("SeparationLines");
            }
        }

        /// <summary>
        /// Gets or sets the Sortings
        /// </summary>
        public List<ISort> Sortings
        {
            get
            {
                return this.sortings;
            }

            set
            {
                this.sortings = value;
                this.OnPropertyChanged("Sortings");
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether SurroundWithRegion
        /// </summary>
        public bool SurroundWithRegion
        {
            get
            {
                return this.surroundWithRegion;
            }

            set
            {
                this.surroundWithRegion = value;
                this.OnPropertyChanged("SurroundWithRegion");
            }
        }

        #region Commands

        /// <summary>
        /// Gets the AddConditionCommand
        /// </summary>
        [JsonIgnore]
        public RelayCommand<string> AddConditionCommand
        {
            get
            {
                if (this.addConditionCommand == null)
                {
                    this.addConditionCommand = new RelayCommand<string>(command => this.ExecuteAddCondition(command), can => this.CanAddCondition(can));
                }

                return this.addConditionCommand;
            }
        }

        /// <summary>
        /// Gets the AddSortingCommand
        /// </summary>
        [JsonIgnore]
        public RelayCommand<string> AddSortingCommand
        {
            get
            {
                if (this.addSortingCommand == null)
                {
                    this.addSortingCommand = new RelayCommand<string>(command => this.ExecuteAddSorting(command), can => this.CanAddSorting(can));
                }

                return this.addSortingCommand;
            }
        }

        /// <summary>
        /// Gets the MoveDownConditionCommand
        /// </summary>
        [JsonIgnore]
        public RelayCommand MoveDownConditionCommand
        {
            get
            {
                if (this.moveDownConditionCommand == null)
                {
                    this.moveDownConditionCommand = new RelayCommand(command => this.ExecuteMoveDownCondition(), can => this.CanMoveDownConditionExecute());
                }

                return this.moveDownConditionCommand;
            }
        }

        /// <summary>
        /// Gets the MoveDownSortingCommand
        /// </summary>
        [JsonIgnore]
        public RelayCommand MoveDownSortingCommand
        {
            get
            {
                if (this.moveDownSortingCommand == null)
                {
                    this.moveDownSortingCommand = new RelayCommand(command => this.ExecuteMoveDownSorting(), can => this.CanMoveDownSortingExecute());
                }

                return this.moveDownSortingCommand;
            }
        }

        /// <summary>
        /// Gets the MoveUpConditionCommand
        /// </summary>
        [JsonIgnore]
        public RelayCommand MoveUpConditionCommand
        {
            get
            {
                if (this.moveUpConditionCommand == null)
                {
                    this.moveUpConditionCommand = new RelayCommand(command => this.ExecuteMoveUpCondition(), can => this.CanMoveUpConditionExecute());
                }

                return this.moveUpConditionCommand;
            }
        }

        /// <summary>
        /// Gets the MoveUpSortingCommand
        /// </summary>
        [JsonIgnore]
        public RelayCommand MoveUpSortingCommand
        {
            get
            {
                if (this.moveUpSortingCommand == null)
                {
                    this.moveUpSortingCommand = new RelayCommand(command => this.ExecuteMoveUpSorting(), can => this.CanMoveUpSortingExecute());
                }

                return this.moveUpSortingCommand;
            }
        }

        /// <summary>
        /// Gets the RegionEnabledCommand
        /// </summary>
        [JsonIgnore]
        public RelayCommand<bool> RegionEnabledCommand
        {
            get
            {
                if (this.regionEnabledCommand == null)
                {
                    this.regionEnabledCommand = new RelayCommand<bool>(command => this.ExecuteRegionEnabled(command));
                }

                return this.regionEnabledCommand;
            }
        }

        /// <summary>
        /// Gets the RemoveConditionCommand
        /// </summary>
        [JsonIgnore]
        public RelayCommand<ICondition> RemoveConditionCommand
        {
            get
            {
                if (this.removeConditionCommand == null)
                {
                    this.removeConditionCommand = new RelayCommand<ICondition>(command => this.ExecuteRemoveCondition(command), can => this.CanRemoveCondition());
                }

                return this.removeConditionCommand;
            }
        }

        /// <summary>
        /// Gets the RemoveSortingCommand
        /// </summary>
        [JsonIgnore]
        public RelayCommand<ISort> RemoveSortingCommand
        {
            get
            {
                if (this.removeSortingCommand == null)
                {
                    this.removeSortingCommand = new RelayCommand<ISort>(command => this.ExecuteRemoveSorting(command), can => this.CanRemoveSorting());
                }

                return this.removeSortingCommand;
            }
        }

        #endregion

        #endregion

        #region Methods

        #region Private Methods

        /// <summary>
        /// The CanAddCondition
        /// </summary>
        /// <param name = "input">The <see cref = "string "/></param>
        /// <returns>The <see cref = "bool "/></returns>
        private bool CanAddCondition(string input)
        {
            return !(this.Conditions != null && this.Conditions.Any(x => x.Name == input));
        }

        /// <summary>
        /// The CanAddSorting
        /// </summary>
        /// <param name = "input">The <see cref = "string "/></param>
        /// <returns>The <see cref = "bool "/></returns>
        private bool CanAddSorting(string input)
        {
            return !(this.Sortings != null && this.Sortings.Any(x => x.Name == input));
        }

        /// <summary>
        /// Determines whether MoveDownCondition can be executed or not
        /// </summary>
        private bool CanMoveDownConditionExecute()
        {
            var index = this.FindSelectedConditionIndex();
            if (index != -1 && this.Conditions != null && index < this.Conditions.Count - 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Determines whether MoveDownSorting can be executed or not
        /// </summary>
        private bool CanMoveDownSortingExecute()
        {
            var index = this.FindSelectedSortingIndex();
            if (index != -1 && this.Sortings != null && index < this.Sortings.Count - 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Determines whether MoveUpCondition can be executed or not
        /// </summary>
        private bool CanMoveUpConditionExecute()
        {
            var index = this.FindSelectedConditionIndex();
            if (index != -1 && this.Conditions != null && index > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Determines whether MoveUpSorting can be executed or not
        /// </summary>
        private bool CanMoveUpSortingExecute()
        {
            var index = this.FindSelectedSortingIndex();
            if (index != -1 && this.Sortings != null && index > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Determines whether RemoveCondition can be executed or not
        /// </summary>
        private bool CanRemoveCondition()
        {
            return true;
        }

        /// <summary>
        /// Determines whether RemoveSorting can be executed or not
        /// </summary>
        private bool CanRemoveSorting()
        {
            return true;
        }

        /// <summary>
        /// Executes AddCondition
        /// </summary>
        private void ExecuteAddCondition(string input)
        {
            var Conditions = this.Conditions;
            if (Conditions == null)
            {
                Conditions = new List<ICondition>();
            }

            Conditions.Add(this.resolver.Resolve<ICondition>(input + Constants.VM));
            this.Conditions = new List<ICondition>(Conditions);
        }

        /// <summary>
        /// Executes AddSorting
        /// </summary>
        private void ExecuteAddSorting(string input)
        {
            var Sortings = this.Sortings;
            if (Sortings == null)
            {
                Sortings = new List<ISort>();
            }

            Sortings.Add(this.resolver.Resolve<ISort>(input + Constants.VM));
            this.Sortings = new List<ISort>(Sortings);
        }

        /// <summary>
        /// Executes MoveDownCondition
        /// </summary>
        private void ExecuteMoveDownCondition()
        {
            int index = this.FindSelectedConditionIndex();
            var Conditions = this.Conditions;
            if (Conditions == null)
            {
                Conditions = new List<ICondition>();
            }

            var ops = Conditions[index];
            Conditions.RemoveAt(index);
            Conditions.Insert(index + 1, ops);
            this.Conditions = new List<ICondition>(Conditions);
            this.SelectedCondition = ops;
        }

        /// <summary>
        /// Executes MoveDownSorting
        /// </summary>
        private void ExecuteMoveDownSorting()
        {
            int index = this.FindSelectedSortingIndex();
            var Sortings = this.Sortings;
            if (Sortings == null)
            {
                Sortings = new List<ISort>();
            }

            var ops = Sortings[index];
            Sortings.RemoveAt(index);
            Sortings.Insert(index + 1, ops);
            this.Sortings = new List<ISort>(Sortings);
            this.SelectedSorting = ops;
        }

        /// <summary>
        /// Executes MoveUpCondition
        /// </summary>
        private void ExecuteMoveUpCondition()
        {
            int index = this.FindSelectedConditionIndex();
            var Conditions = this.Conditions;
            if (Conditions == null)
            {
                Conditions = new List<ICondition>();
            }

            var ops = Conditions[index];
            Conditions.RemoveAt(index);
            Conditions.Insert(index - 1, ops);
            this.Conditions = new List<ICondition>(Conditions);
            this.SelectedCondition = ops;
        }

        /// <summary>
        /// Executes MoveUpSorting
        /// </summary>
        private void ExecuteMoveUpSorting()
        {
            int index = this.FindSelectedSortingIndex();
            var Sortings = this.Sortings;
            if (Sortings == null)
            {
                Sortings = new List<ISort>();
            }

            var ops = Sortings[index];
            Sortings.RemoveAt(index);
            Sortings.Insert(index - 1, ops);
            this.Sortings = new List<ISort>(Sortings);
            this.SelectedSorting = ops;
        }

        /// <summary>
        /// Executes RegionEnabled
        /// </summary>
        private void ExecuteRegionEnabled(bool input)
        {
            if (input)
            {
                var kind = this.Conditions?.FirstOrDefault(x => x is FindByKindViewModel) as FindByKindViewModel;
                this.Region = kind != null ? kind.Kind.ToString() : string.Empty;
            }
            else
            {
                this.region = string.Empty;
            }
        }

        /// <summary>
        /// Executes RemoveCondition
        /// </summary>
        private void ExecuteRemoveCondition(ICondition condition)
        {
            var conditions = this.Conditions;
            conditions.Remove(condition);
            this.Conditions = new List<ICondition>(conditions);
        }

        /// <summary>
        /// Executes RemoveSorting
        /// </summary>
        private void ExecuteRemoveSorting(ISort sorting)
        {
            var sortings = this.Sortings;
            sortings.Remove(sorting);
            this.Sortings = new List<ISort>(sortings);
        }

        /// <summary>
        /// The FindSelectedConditionIndex
        /// </summary>
        /// <returns>The <see cref = "int "/></returns>
        private int FindSelectedConditionIndex()
        {
            return this.FindSelectedConditionIndex(this.SelectedCondition);
        }

        /// <summary>
        /// The FindSelectedConditionIndex
        /// </summary>
        /// <param name = "Condition">The <see cref = "ICondition"/></param>
        /// <returns>The <see cref = "int "/></returns>
        private int FindSelectedConditionIndex(ICondition Condition)
        {
            int index = -1;
            if (Condition != null && this.Conditions != null)
            {
                index = this.Conditions.IndexOf(Condition);
            }

            return index;
        }

        /// <summary>
        /// The FindSelectedSortingIndex
        /// </summary>
        /// <returns>The <see cref = "int "/></returns>
        private int FindSelectedSortingIndex()
        {
            return this.FindSelectedSortingIndex(this.SelectedSorting);
        }

        /// <summary>
        /// The FindSelectedSortingIndex
        /// </summary>
        /// <param name = "Sorting">The <see cref = "ISort"/></param>
        /// <returns>The <see cref = "int "/></returns>
        private int FindSelectedSortingIndex(ISort Sorting)
        {
            int index = -1;
            if (Sorting != null && this.Sortings != null)
            {
                index = this.Sortings.IndexOf(Sorting);
            }

            return index;
        }

        /// <summary>
        /// The LoadData
        /// </summary>
        private void LoadData()
        {
            this.SeparationLines = new List<int> { 0, 1, 2 };
        }

        #endregion

        #endregion
    }
}
