namespace CodeFormatter.Core.ViewModels.Operations
{
    using System;
    using System.Collections.Generic;
    using CodeFormatter.Common;
    using CodeFormatter.Common.Contracts;
    using CodeFormatter.Common.Entities;
    using CodeFormatter.Common.Models.Operations;
    using CodeFormatter.Core.Startup;
    using Microsoft.Practices.Unity;
    using Newtonsoft.Json;

    /// <summary>
    /// Defines the <see cref = "BaseOperationViewModel"/>
    /// </summary>
    public abstract class BaseOperationViewModel : BaseViewModel, IOperation
    {
        #region Fields

        /// <summary>
        /// The name field
        /// </summary>
        private string name;

        /// <summary>
        /// The addOperationCommand field
        /// </summary>
        private RelayCommand<string> addOperationCommand;

        /// <summary>
        /// The operations field
        /// </summary>
        private List<IOperation> operations;

        /// <summary>
        /// Defines the resolver
        /// </summary>
        private readonly IResolver resolver;

        /// <summary>
        /// The selectedOpaeration field
        /// </summary>
        private IOperation selectedOpaeration;

        #region Commands

        /// <summary>
        /// The moveDownOperationCommand field
        /// </summary>
        private RelayCommand moveDownOperationCommand;

        /// <summary>
        /// The moveUpOperationCommand field
        /// </summary>
        private RelayCommand moveUpOperationCommand;

        /// <summary>
        /// The removeOperationCommand field
        /// </summary>
        private RelayCommand removeOperationCommand;

        #endregion

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "BaseOperationViewModel"/> class.
        /// </summary>
        public BaseOperationViewModel()
        {
            this.GUID = Guid.NewGuid().ToString();
            this.resolver = UnityConfig.Container.Resolve<IResolver>();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets GUID
        /// </summary>
        public string GUID
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the Name
        /// </summary>
        public string Name
        {
            get
            {
                return this.name;
            }

            set
            {
                this.name = value;
                this.OnPropertyChanged("Name");
            }
        }

        /// <summary>
        /// Gets the AddOperationCommand
        /// </summary>
        [JsonIgnore]
        public RelayCommand<string> AddOperationCommand
        {
            get
            {
                if (this.addOperationCommand == null)
                {
                    this.addOperationCommand = new RelayCommand<string>(command => this.ExecuteAddOperation(command));
                }

                return this.addOperationCommand;
            }
        }

        /// <summary>
        /// Gets or sets the Operations
        /// </summary>
        public List<IOperation> Operations
        {
            get
            {
                return this.operations;
            }

            set
            {
                this.operations = value;
                this.OnPropertyChanged("Operations");
            }
        }

        /// <summary>
        /// Gets the Resolver
        /// </summary>
        [JsonIgnore]
        public IResolver Resolver
        {
            get
            {
                return this.resolver;
            }
        }

        /// <summary>
        /// Gets or sets the SelectedOperation
        /// </summary>
        [JsonIgnore]
        public IOperation SelectedOperation
        {
            get
            {
                return this.selectedOpaeration;
            }

            set
            {
                this.selectedOpaeration = value;
                this.OnPropertyChanged("SelectedOperation");
            }
        }

        #region Commands

        /// <summary>
        /// Gets the MoveDownOperationCommand
        /// </summary>
        [JsonIgnore]
        public RelayCommand MoveDownOperationCommand
        {
            get
            {
                if (this.moveDownOperationCommand == null)
                {
                    this.moveDownOperationCommand = new RelayCommand(command => this.ExecuteMoveDownOperation(), can => this.CanMoveDownOperationExecute());
                }

                return this.moveDownOperationCommand;
            }
        }

        /// <summary>
        /// Gets the MoveUpOperationCommand
        /// </summary>
        [JsonIgnore]
        public RelayCommand MoveUpOperationCommand
        {
            get
            {
                if (this.moveUpOperationCommand == null)
                {
                    this.moveUpOperationCommand = new RelayCommand(command => this.ExecuteMoveUpOperation(), can => this.CanMoveUpOperationExecute());
                }

                return this.moveUpOperationCommand;
            }
        }

        /// <summary>
        /// Gets the RemoveOperationCommand
        /// </summary>
        [JsonIgnore]
        public RelayCommand RemoveOperationCommand
        {
            get
            {
                if (this.removeOperationCommand == null)
                {
                    this.removeOperationCommand = new RelayCommand(command => this.ExecuteRemoveOperation(), can => this.CanRemoveOperation());
                }

                return this.removeOperationCommand;
            }
        }

        #endregion

        #endregion

        #region Methods

        /// <summary>
        /// The AddOperation
        /// </summary>
        /// <param name = "item">The <see cref = "IOperation"/></param>
        public void AddOperation(IOperation item)
        {
            var operations = this.Operations;
            if (operations == null)
            {
                operations = new List<IOperation>();
            }

            operations.Add(item);
            this.Operations = new List<IOperation>(operations);
            this.SelectedOperation = item;
        }

        /// <summary>
        /// The RemoveOperation
        /// </summary>
        /// <param name = "item">The <see cref = "IOperation"/></param>
        public void RemoveOperation(IOperation item)
        {
            var operations = this.Operations;
            operations.Remove(item);
            this.Operations = new List<IOperation>(operations);
        }

        /// <summary>
        /// Determines whether MoveDownOperation can be executed or not
        /// </summary>
        private bool CanMoveDownOperationExecute()
        {
            var index = this.FindSelectedOperationIndex();
            if (index != -1 && this.Operations != null && index < this.Operations.Count - 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Determines whether MoveUpOperation can be executed or not
        /// </summary>
        private bool CanMoveUpOperationExecute()
        {
            var index = this.FindSelectedOperationIndex();
            if (index != -1 && this.Operations != null && index > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Determines whether RemoveOperation can be executed or not
        /// </summary>
        private bool CanRemoveOperation()
        {
            return this.SelectedOperation != null;
        }

        /// <summary>
        /// Executes AddOperation
        /// </summary>
        private void ExecuteAddOperation(string input)
        {
            var operation = this.Resolver.Resolve<IOperation>(input + Constants.VM);
            this.AddOperation(operation);
        }

        /// <summary>
        /// Executes MoveDownOperation
        /// </summary>
        private void ExecuteMoveDownOperation()
        {
            int index = this.FindSelectedOperationIndex();
            var operations = this.Operations;
            if (operations == null)
            {
                operations = new List<IOperation>();
            }

            var ops = operations[index];
            operations.RemoveAt(index);
            operations.Insert(index + 1, ops);
            this.Operations = new List<IOperation>(operations);
            this.SelectedOperation = ops;
        }

        /// <summary>
        /// Executes MoveUpOperation
        /// </summary>
        private void ExecuteMoveUpOperation()
        {
            int index = this.FindSelectedOperationIndex();
            var operations = this.Operations;
            if (operations == null)
            {
                operations = new List<IOperation>();
            }

            var ops = operations[index];
            operations.RemoveAt(index);
            operations.Insert(index - 1, ops);
            this.Operations = new List<IOperation>(operations);
            this.SelectedOperation = ops;
        }

        /// <summary>
        /// Executes RemoveOperation
        /// </summary>
        private void ExecuteRemoveOperation()
        {
            this.RemoveOperation(this.SelectedOperation);
        }

        /// <summary>
        /// The FindSelectedOperationIndex
        /// </summary>
        /// <returns>The <see cref = "int "/></returns>
        private int FindSelectedOperationIndex()
        {
            return this.FindSelectedOperationIndex(this.SelectedOperation);
        }

        /// <summary>
        /// The FindSelectedOperationIndex
        /// </summary>
        /// <param name = "operation">The <see cref = "IOperation"/></param>
        /// <returns>The <see cref = "int "/></returns>
        private int FindSelectedOperationIndex(IOperation operation)
        {
            int index = -1;
            if (operation != null && this.Operations != null)
            {
                index = this.Operations.IndexOf(operation);
            }

            return index;
        }

        #endregion
    }
}
