namespace CodeFormatter.Core.ViewModels.MemberGroups
{
    using CodeFormatter.Common;

    /// <summary>
    /// Defines the <see cref = "OrMemberGroupCollectionViewModel"/>
    /// </summary>
    public class OrMemberGroupCollectionViewModel : BaseMemberGroupViewModel
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "OrMemberGroupCollectionViewModel"/> class.
        /// </summary>
        public OrMemberGroupCollectionViewModel()
        {
            this.Name = Constants.Or;
        }

        #endregion
    }
}
