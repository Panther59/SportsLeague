namespace CodeFormatter.Core.ViewModels.MemberGroups
{
    using CodeFormatter.Common;
    using CodeFormatter.Core.Syntaxs.MemberGroups;

    /// <summary>
    /// Defines the <see cref = "SortByModifierViewModel"/>
    /// </summary>
    public class SortByModifierViewModel : BaseSortViewModel
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "SortByModifierViewModel"/> class.
        /// </summary>
        public SortByModifierViewModel()
        {
            this.Name = Constants.AccessModifier;
        }

        #endregion
    }
}
