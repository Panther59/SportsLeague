namespace CodeFormatter.Core.ViewModels.MemberGroups
{
    using CodeFormatter.Common.Entities;
    using CodeFormatter.Core.Syntaxs.MemberGroups;

    /// <summary>
    /// Defines the <see cref = "BaseSort"/>
    /// </summary>
    public abstract class BaseSortViewModel : BaseViewModel, ISort
    {
        #region Fields

        /// <summary>
        /// The name field
        /// </summary>
        private string name;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the Name
        /// </summary>
        public string Name
        {
            get
            {
                return this.name;
            }

            set
            {
                this.name = value;
                this.OnPropertyChanged("Name");
            }
        }

        #endregion
    }
}
