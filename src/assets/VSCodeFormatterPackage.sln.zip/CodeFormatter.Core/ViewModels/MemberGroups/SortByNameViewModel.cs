namespace CodeFormatter.Core.ViewModels.MemberGroups
{
    using CodeFormatter.Common;

    /// <summary>
    /// Defines the <see cref = "SortByNameViewModel"/>
    /// </summary>
    public class SortByNameViewModel : BaseSortViewModel
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "SortByNameViewModel"/> class.
        /// </summary>
        public SortByNameViewModel()
        {
            this.Name = Constants.Name;
        }

        #endregion
    }
}
