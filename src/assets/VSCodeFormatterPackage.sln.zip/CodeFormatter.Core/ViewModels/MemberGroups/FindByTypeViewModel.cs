namespace CodeFormatter.Core.ViewModels.MemberGroups
{
    using CodeFormatter.Common;

    /// <summary>
    /// Defines the <see cref = "FindByTypeViewModel"/>
    /// </summary>
    public class FindByTypeViewModel : FindMemberConditionViewModel
    {
        #region Fields

        /// <summary>
        /// The type field
        /// </summary>
        private string type;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "FindByTypeViewModel"/> class.
        /// </summary>
        public FindByTypeViewModel()
        {
            this.Name = Constants.Type;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the Type
        /// </summary>
        public string Type
        {
            get
            {
                return this.type;
            }

            set
            {
                this.type = value;
                this.OnPropertyChanged("Type");
            }
        }

        #endregion
    }
}
