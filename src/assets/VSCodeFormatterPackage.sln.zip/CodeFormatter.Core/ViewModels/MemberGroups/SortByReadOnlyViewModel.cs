namespace CodeFormatter.Core.ViewModels.MemberGroups
{
    using CodeFormatter.Common;

    /// <summary>
    /// Defines the <see cref = "SortByReadOnlyViewModel"/>
    /// </summary>
    public class SortByReadOnlyViewModel : BaseSortViewModel
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "SortByReadOnlyViewModel"/> class.
        /// </summary>
        public SortByReadOnlyViewModel()
        {
            this.Name = Constants.ReadOnly;
        }

        #endregion
    }
}
