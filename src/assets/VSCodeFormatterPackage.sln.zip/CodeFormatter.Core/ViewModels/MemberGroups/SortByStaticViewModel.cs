namespace CodeFormatter.Core.ViewModels.MemberGroups
{
    using CodeFormatter.Common;

    /// <summary>
    /// Defines the <see cref = "SortByStaticViewModel"/>
    /// </summary>
    public class SortByStaticViewModel : BaseSortViewModel
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "SortByStaticViewModel"/> class.
        /// </summary>
        public SortByStaticViewModel()
        {
            this.Name = Constants.IsStatic;
        }

        #endregion
    }
}
