namespace CodeFormatter.Core.ViewModels.MemberGroups
{
    using CodeFormatter.Common.Entities;

    /// <summary>
    /// Defines the <see cref = "FindByKindViewModel"/>
    /// </summary>
    public class FindByKindViewModel : FindMemberConditionViewModel
    {
        #region Fields

        /// <summary>
        /// The kind field
        /// </summary>
        private MemberKinds kind;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "FindByKindViewModel"/> class.
        /// </summary>
        public FindByKindViewModel()
        {
            this.Name = "Kind";
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the Kind
        /// </summary>
        public MemberKinds Kind
        {
            get
            {
                return this.kind;
            }

            set
            {
                this.kind = value;
                this.OnPropertyChanged("Kind");
            }
        }

        #endregion
    }
}
