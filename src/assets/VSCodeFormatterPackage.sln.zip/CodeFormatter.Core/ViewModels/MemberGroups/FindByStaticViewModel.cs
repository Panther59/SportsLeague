namespace CodeFormatter.Core.ViewModels.MemberGroups
{
    using CodeFormatter.Common;

    /// <summary>
    /// Defines the <see cref = "FindByStaticViewModel"/>
    /// </summary>
    public class FindByStaticViewModel : FindMemberConditionViewModel
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "FindByStaticViewModel"/> class.
        /// </summary>
        public FindByStaticViewModel()
        {
            this.Name = Constants.IsStatic;
        }

        #endregion
    }
}
