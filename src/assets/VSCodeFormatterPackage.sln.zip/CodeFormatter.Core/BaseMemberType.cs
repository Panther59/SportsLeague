﻿// <copyright file="BaseMemberType.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>30-07-2017</date>

namespace CodeFormatter.Core
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using CodeFormatter.Common.Contracts;
    using Microsoft.CodeAnalysis;
    using Microsoft.CodeAnalysis.CSharp;
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    /// <summary>
    /// Defines the <see cref = "BaseMemberType"/>
    /// </summary>
    public abstract class BaseMemberType
    {
        #region Fields

        /// <summary>
        /// Defines the resolver
        /// </summary>
        private readonly IResolver resolver;

        /// <summary>
        /// Defines the setting
        /// </summary>
        private readonly IDefaultSettings setting;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "BaseMemberType"/> class.
        /// </summary>
        /// <param name = "setting">The <see cref = "IDefaultSettings"/></param>
        /// <param name = "resolver">The <see cref = "IResolver"/></param>
        public BaseMemberType(IDefaultSettings setting, IResolver resolver)
        {
            this.setting = setting;
            this.resolver = resolver;
            this.GUID = Guid.NewGuid().ToString();
            //this.headerModifiersRootObject = resolver.ResolveAll<IBaseRootSyntax>();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the Level
        /// </summary>
        public int Level
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the GUID
        /// </summary>
        public string GUID
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets or sets the Identifier
        /// </summary>
        public string Identifier
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the MemberDesc
        /// </summary>
        public string MemberDesc
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the MemberRank
        /// </summary>
        public int MemberRank
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the ModifierDesc
        /// </summary>
        public string ModifierDesc
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the ModifierRank
        /// </summary>
        public int ModifierRank
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the ParameterText
        /// </summary>
        public string ParameterText
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the TypeText
        /// </summary>
        public string TypeText
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the Member
        /// </summary>
        public MemberDeclarationSyntax Member
        {
            get;
            set;
        }

        #endregion

        #region Methods

        /// <summary>
        /// The GetDefaultAccessToken
        /// </summary>
        /// <returns>The <see cref = "SyntaxToken"/></returns>
        protected SyntaxTokenList GetDefaultAccessToken()
        {
            SyntaxKind def = SyntaxKind.InternalKeyword;
            switch (this.setting.DefaultAccessModifier)
            {
                case "public":
                    def = SyntaxKind.PublicKeyword;
                    break;
                case "protected":
                    def = SyntaxKind.ProtectedKeyword;
                    break;
                case "private":
                    def = SyntaxKind.PrivateKeyword;
                    break;
                case "internal":
                    def = SyntaxKind.InternalKeyword;
                    break;
                default:
                    break;
            }

            return new SyntaxTokenList().Add(SyntaxFactory.Token(def).WithTrailingTrivia(SyntaxFactory.Whitespace(" ")));
        }

        /// <summary>
        /// The GetDefaultAccessToken
        /// </summary>
        /// <returns>The <see cref = "SyntaxToken"/></returns>
        protected SyntaxTokenList GetDefaultAccessToken(SyntaxTokenList modifier)
        {
            SyntaxKind def = SyntaxKind.InternalKeyword;
            switch (this.setting.DefaultAccessModifier)
            {
                case "public":
                    def = SyntaxKind.PublicKeyword;
                    break;
                case "protected":
                    def = SyntaxKind.ProtectedKeyword;
                    break;
                case "private":
                    def = SyntaxKind.PrivateKeyword;
                    break;
                case "internal":
                    def = SyntaxKind.InternalKeyword;
                    break;
                default:
                    break;
            }

            var firstTrivia = modifier.First().LeadingTrivia;
            modifier = modifier.Replace(modifier[0], modifier[0].WithLeadingTrivia());
            modifier = modifier.Insert(0, SyntaxFactory.Token(def).WithLeadingTrivia(firstTrivia).WithTrailingTrivia(SyntaxFactory.Whitespace(" ")));
            return modifier;
        }

        /// <summary>
        /// The IsModifierPresent
        /// </summary>
        /// <param name = "modifiers">The <see cref = "SyntaxTokenList"/></param>
        /// <returns>The <see cref = "bool "/></returns>
        protected bool IsModifierPresent(IEnumerable<SyntaxToken> modifiers)
        {
            return modifiers.Any(x => AppGlobal.ModifierRank.Any(y => y.Key.Equals(x.Text.Trim(), StringComparison.CurrentCulture))) == false;
        }

        /// <summary>
        /// The SwitchKind
        /// </summary>
        /// <param name = "source">The <see cref = "MemberDeclarationSyntax"/></param>
        /// <param name = "isParentInterface">The <see cref = "bool "/></param>
        protected void SwitchKind(MemberDeclarationSyntax source, bool isParentInterface = false)
        {
            switch (source.Kind())
            {
                case Microsoft.CodeAnalysis.CSharp.SyntaxKind.ClassDeclaration:
                    {
                        this.MemberDesc = "Class";
                        ClassDeclarationSyntax cls = source as ClassDeclarationSyntax;
                        this.ModifierDesc = cls.Modifiers.ToString();
                        this.Identifier = cls.Identifier.ValueText;
                        if (isParentInterface == false && this.setting.AddMissingAccessModifier && this.IsModifierPresent(cls.Modifiers))
                        {
                            SyntaxTokenList modifiers = cls.Modifiers.Any() ? GetDefaultAccessToken(cls.Modifiers) : GetDefaultAccessToken();
                            var leadingTrivia = cls.GetLeadingTrivia();
                            cls = cls.WithoutLeadingTrivia().WithModifiers(modifiers).WithLeadingTrivia(leadingTrivia);
                            source = cls;
                            this.ModifierDesc = cls.Modifiers.ToString();
                        }
                    }

                    break;
                case Microsoft.CodeAnalysis.CSharp.SyntaxKind.InterfaceDeclaration:
                    {
                        this.MemberDesc = "Interface";
                        InterfaceDeclarationSyntax interf = source as InterfaceDeclarationSyntax;
                        this.ModifierDesc = interf.Modifiers.ToString();
                        this.Identifier = interf.Identifier.ValueText;
                        if (isParentInterface == false && this.setting.AddMissingAccessModifier && this.IsModifierPresent(interf.Modifiers))
                        {
                            SyntaxTokenList modifiers = interf.Modifiers.Any() ? GetDefaultAccessToken(interf.Modifiers) : GetDefaultAccessToken();
                            var leadingTrivia = interf.GetLeadingTrivia();
                            interf = interf.WithoutLeadingTrivia().WithModifiers(modifiers).WithLeadingTrivia(leadingTrivia);
                            source = interf;
                            this.ModifierDesc = interf.Modifiers.ToString();
                        }
                    }

                    break;
                case Microsoft.CodeAnalysis.CSharp.SyntaxKind.EventDeclaration:
                    {
                        this.MemberDesc = "Enum";
                        EnumDeclarationSyntax enm = source as EnumDeclarationSyntax;
                        this.ModifierDesc = enm.Modifiers.ToString();
                        this.Identifier = enm.Identifier.ValueText;
                        if (isParentInterface == false && this.setting.AddMissingAccessModifier && this.IsModifierPresent(enm.Modifiers))
                        {
                            SyntaxTokenList modifiers = enm.Modifiers.Any() ? GetDefaultAccessToken(enm.Modifiers) : GetDefaultAccessToken();
                            var leadingTrivia = enm.GetLeadingTrivia();
                            enm = enm.WithoutLeadingTrivia().WithModifiers(modifiers).WithLeadingTrivia(leadingTrivia);
                            source = enm;
                            this.ModifierDesc = enm.Modifiers.ToString();
                        }
                    }

                    break;
                case Microsoft.CodeAnalysis.CSharp.SyntaxKind.EventFieldDeclaration:
                    {
                        this.MemberDesc = "Event";
                        EventFieldDeclarationSyntax eventSyntax = source as EventFieldDeclarationSyntax;
                        this.ModifierDesc = eventSyntax.Modifiers.ToString();
                        this.Identifier = eventSyntax.Declaration.Variables.First().Identifier.ValueText;
                        if (isParentInterface == false && this.setting.AddMissingAccessModifier && this.IsModifierPresent(eventSyntax.Modifiers))
                        {
                            SyntaxTokenList modifiers = eventSyntax.Modifiers.Any() ? GetDefaultAccessToken(eventSyntax.Modifiers) : GetDefaultAccessToken();
                            var leadingTrivia = eventSyntax.GetLeadingTrivia();
                            eventSyntax = eventSyntax.WithoutLeadingTrivia().WithModifiers(modifiers).WithLeadingTrivia(leadingTrivia);
                            source = eventSyntax;
                            this.ModifierDesc = eventSyntax.Modifiers.ToString();
                        }
                    }

                    break;
                case Microsoft.CodeAnalysis.CSharp.SyntaxKind.FieldDeclaration:
                    {
                        this.MemberDesc = "Field";
                        FieldDeclarationSyntax field = source as FieldDeclarationSyntax;
                        this.ModifierDesc = field.Modifiers.ToString();
                        this.TypeText = field.Declaration.Type.ToFullString().Trim();
                        this.Identifier = field.Declaration.Variables.First().Identifier.ValueText;
                        if (isParentInterface == false && this.setting.AddMissingAccessModifier && this.IsModifierPresent(field.Modifiers))
                        {
                            SyntaxTokenList modifiers = field.Modifiers.Any() ? GetDefaultAccessToken(field.Modifiers) : GetDefaultAccessToken();
                            var leadingTrivia = field.GetLeadingTrivia();
                            field = field.WithoutLeadingTrivia().WithModifiers(modifiers).WithLeadingTrivia(leadingTrivia);
                            //field = this.FixField(field);
                            source = field;
                            this.ModifierDesc = field.Modifiers.ToString();
                        }
                    }

                    break;
                case Microsoft.CodeAnalysis.CSharp.SyntaxKind.PropertyDeclaration:
                    {
                        this.MemberDesc = "Property";
                        PropertyDeclarationSyntax prop = source as PropertyDeclarationSyntax;
                        this.ModifierDesc = prop.Modifiers.ToString();
                        this.TypeText = prop.Type.ToFullString().Trim();
                        this.Identifier = prop.Identifier.ValueText;
                        if (isParentInterface == false && this.setting.AddMissingAccessModifier && this.IsModifierPresent(prop.Modifiers) && prop.ExplicitInterfaceSpecifier == null)
                        {
                            SyntaxTokenList modifiers = prop.Modifiers.Any() ? GetDefaultAccessToken(prop.Modifiers) : GetDefaultAccessToken();
                            var leadingTrivia = prop.GetLeadingTrivia();
                            prop = prop.WithoutLeadingTrivia().WithModifiers(modifiers).WithLeadingTrivia(leadingTrivia);
                            source = prop;
                            this.ModifierDesc = prop.Modifiers.ToString();
                        }
                    }

                    break;
                case Microsoft.CodeAnalysis.CSharp.SyntaxKind.ConstructorDeclaration:
                    {
                        this.MemberDesc = "Constructor";
                        ConstructorDeclarationSyntax construct = source as ConstructorDeclarationSyntax;
                        this.ModifierDesc = construct.Modifiers.ToString();
                        this.Identifier = construct.Identifier.ValueText;
                        this.ParameterText = construct.ParameterList.ToFullString().Trim();
                        this.ParameterText = this.ParameterText.Substring(1, this.ParameterText.Length - 2);
                        ////if (isParentInterface == false && this.setting.AddMissingAccessModifier && AppGlobal.ModifierRank.Any(x => this.ModifierDesc.StartsWith(x.Key)) == false)
                        ////{
                        ////    SyntaxTokenList modifiers = new SyntaxTokenList();
                        ////    modifiers = modifiers.Add(this.GetDefaultAccessToken());
                        ////    if (construct.Modifiers.Any())
                        ////    {
                        ////        var extMod = construct.Modifiers.First();
                        ////        extMod = extMod.WithoutTrivia().WithLeadingTrivia(SyntaxFactory.Whitespace(" "));
                        ////        modifiers = modifiers.Add(extMod);
                        ////    }
                        ////    construct = construct.WithModifiers(modifiers);
                        ////    source = construct;
                        ////    this.ModifierDesc = construct.Modifiers.ToString();
                        ////}
                    }

                    break;
                case Microsoft.CodeAnalysis.CSharp.SyntaxKind.DestructorDeclaration:
                    {
                        this.MemberDesc = "Destructor";
                        ConstructorDeclarationSyntax construct = source as ConstructorDeclarationSyntax;
                        this.ModifierDesc = construct.Modifiers.ToString();
                        this.Identifier = construct.Identifier.ValueText;
                        this.ParameterText = construct.ParameterList.ToFullString().Trim();
                        this.ParameterText = this.ParameterText.Substring(1, this.ParameterText.Length - 2);
                        ////if (isParentInterface == false && this.setting.AddMissingAccessModifier && AppGlobal.ModifierRank.Any(x => this.ModifierDesc.StartsWith(x.Key)) == false)
                        ////{
                        ////    SyntaxTokenList modifiers = new SyntaxTokenList();
                        ////    modifiers = modifiers.Add(this.GetDefaultAccessToken());
                        ////    if (construct.Modifiers.Any())
                        ////    {
                        ////        var extMod = construct.Modifiers.First();
                        ////        extMod = extMod.WithoutTrivia().WithLeadingTrivia(SyntaxFactory.Whitespace(" "));
                        ////        modifiers = modifiers.Add(extMod);
                        ////    }
                        ////    construct = construct.WithModifiers(modifiers);
                        ////    source = construct;
                        ////    this.ModifierDesc = construct.Modifiers.ToString();
                        ////}
                    }

                    break;
                case Microsoft.CodeAnalysis.CSharp.SyntaxKind.MethodDeclaration:
                    {
                        this.MemberDesc = "Method";
                        MethodDeclarationSyntax method = source as MethodDeclarationSyntax;
                        this.ModifierDesc = method.Modifiers.ToString();
                        this.ParameterText = method.ParameterList.ToFullString().Trim();
                        this.ParameterText = this.ParameterText.Substring(1, this.ParameterText.Length - 2);
                        this.Identifier = method.Identifier.ValueText;
                        if (isParentInterface == false && this.setting.AddMissingAccessModifier && this.IsModifierPresent(method.Modifiers) && method.ExplicitInterfaceSpecifier == null)
                        {
                            SyntaxTokenList modifiers = method.Modifiers.Any() ? GetDefaultAccessToken(method.Modifiers) : GetDefaultAccessToken();
                            var leadingTrivia = method.GetLeadingTrivia();
                            method = method.WithoutLeadingTrivia().WithModifiers(modifiers).WithLeadingTrivia(leadingTrivia);
                            source = method;
                            this.ModifierDesc = method.Modifiers.ToString();
                        }
                    }

                    break;
                case Microsoft.CodeAnalysis.CSharp.SyntaxKind.DelegateDeclaration:
                    {
                        this.MemberDesc = "Delegate";
                        DelegateDeclarationSyntax delega = source as DelegateDeclarationSyntax;
                        this.ModifierDesc = delega.Modifiers.ToString();
                        this.Identifier = delega.Identifier.ValueText;
                        this.ParameterText = delega.ParameterList.ToFullString().Trim();
                        this.ParameterText = this.ParameterText.Substring(1, this.ParameterText.Length - 2);
                        if (isParentInterface == false && this.setting.AddMissingAccessModifier && this.IsModifierPresent(delega.Modifiers))
                        {
                            SyntaxTokenList modifiers = delega.Modifiers.Any() ? GetDefaultAccessToken(delega.Modifiers) : GetDefaultAccessToken();
                            var leadingTrivia = delega.GetLeadingTrivia();
                            delega = delega.WithoutLeadingTrivia().WithModifiers(modifiers).WithLeadingTrivia(leadingTrivia);
                            source = delega;
                            this.ModifierDesc = delega.Modifiers.ToString();
                        }
                    }

                    break;
                default:
                    this.MemberDesc = "Unknown";
                    this.ModifierDesc = "Unknown";
                    break;
            }

            this.Member = source;
            this.ModifierDesc = this.ModifierDesc.Replace(" async", "").Replace("async", "");
            this.MemberRank = AppGlobal.MemberRank.First(x => x.Key == this.MemberDesc).Value;
            var ranks = AppGlobal.ModifierRank.Where(x => this.ModifierDesc.StartsWith(x.Key));
            this.ModifierRank = ranks.Any() ? ranks.Last().Value : 999;
        }

        #endregion
        ///// <summary>
        ///// The FixField
        ///// </summary>
        ///// <param name = "field">The <see cref = "FieldDeclarationSyntax"/></param>
        ///// <returns>The <see cref = "FieldDeclarationSyntax"/></returns>
        //private FieldDeclarationSyntax FixField(FieldDeclarationSyntax field)
        //{
        //    var leadingTrivia = field.GetLeadingTrivia().ToString().Trim();
        //    if (string.IsNullOrEmpty(leadingTrivia))
        //    {
        //        var comment = string.Format(@"
        ///// <summary>
        ///// Defines the {0}
        ///// </summary>
        //", field.Declaration.Variables.First().ToString());
        //        field = field.WithLeadingTrivia(SyntaxFactory.Whitespace(comment));
        //    }
        //    return field;
        //}
    }
}