﻿// <copyright file="ExpressionStatementFixer.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>18-08-2017</date>

namespace CodeFormatter.Core.Syntaxs.Statements
{
    using System;
    using Microsoft.CodeAnalysis.CSharp;
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    /// <summary>
    /// Defines the <see cref="LocalObjectStatement" />
    /// </summary>
    public class ExpressionStatementFixer : BaseStatementSyntax<ExpressionStatementSyntax>
    {
        #region Properties

        /// <summary>
        /// Gets the StatementType
        /// </summary>
        public override SyntaxKind StatementType => SyntaxKind.ExpressionStatement;

        #endregion

        #region Methods

        /// <inheritdoc />
        protected override ExpressionStatementSyntax InternalFixStatement(ExpressionStatementSyntax input)
        {
            if (input.SemicolonToken == null || string.IsNullOrWhiteSpace(input.SemicolonToken.Text))
            {
                var existingTrailingTrivia = input.Expression.GetTrailingTrivia().ToFullString();
                var expression = input.Expression.ToFullString();
                input = input.WithExpression(SyntaxFactory.ParseExpression(expression.TrimEnd()));
                input = input.WithSemicolonToken(SyntaxFactory.ParseToken(";" + Environment.NewLine));
            }
            else
            {
                input = input.WithSemicolonToken(input.SemicolonToken.WithTrailingTrivia(SyntaxFactory.ParseTrailingTrivia(Environment.NewLine)));
            }

            return input;
        }

        #endregion
    }
}
