﻿// <copyright file="BaseStatementSyntax.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>18-08-2017</date>

namespace CodeFormatter.Core.Syntaxs.Statements
{
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.CodeAnalysis.CSharp;
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    /// <summary>
    /// Defines the <see cref="BaseStatementSyntax{T}" />
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public abstract class BaseStatementSyntax<T> : IBaseStatementSyntax
        where T : StatementSyntax
    {
        #region Properties

        /// <summary>
        /// Gets or sets the Level
        /// </summary>
        public int Level { get; private set; }

        /// <summary>
        /// Gets the StatementType
        /// </summary>
        public abstract SyntaxKind StatementType { get; }

        /// <summary>
        /// Gets the Type
        /// </summary>
        public SyntaxKind Type
        {
            get
            {
                return this.StatementType;
            }
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// The FixStatement
        /// </summary>
        /// <param name="input">The <see cref="StatementSyntax"/></param>
        /// <returns>The <see cref="StatementSyntax"/></returns>
        public StatementSyntax FixStatement(StatementSyntax input, int level)
        {
            this.Level = level;
            var output = this.InternalFixStatement(input as T);
            return output;
        }

        #endregion

        /// <summary>
        /// The InternalFixStatement
        /// </summary>
        /// <param name="input">The <see cref="T"/></param>
        /// <returns>The <see cref="T"/></returns>
        protected abstract T InternalFixStatement(T input);

        public List<string> GetLines(string input)
        {
            List<string> lines = new List<string>();
            if (input != null)
            {
                input = input.Replace("\r\n", "\n");
                lines = input.Split('\n').ToList();
                return lines;
            }

            return lines;
        }

        public bool HasLeadingEmptyLine(string input)
        {
            List<string> lines = this.GetLines(input);

            if (lines.Count > 1 && string.IsNullOrWhiteSpace(lines[0]))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        #endregion
    }
}
