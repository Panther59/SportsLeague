﻿// <copyright file="ReturnStatement.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>18-08-2017</date>

namespace CodeFormatter.Core.Syntaxs.Statements
{
    using System;
    using Microsoft.CodeAnalysis.CSharp;
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    /// <summary>
    /// Defines the <see cref="LocalObjectStatement" />
    /// </summary>
    public class ReturnStatementFixer : BaseStatementSyntax<ReturnStatementSyntax>
    {
        #region Properties

        /// <summary>
        /// Gets the StatementType
        /// </summary>
        public override SyntaxKind StatementType => SyntaxKind.ReturnStatement;

        #endregion

        #region Methods

        /// <inheritdoc />
        protected override ReturnStatementSyntax InternalFixStatement(ReturnStatementSyntax input)
        {
            var oldTrivia = input.ReturnKeyword.LeadingTrivia.ToFullString();
            string leadTriviaFormat = string.Empty;
            if (string.IsNullOrWhiteSpace(oldTrivia))
            {
                leadTriviaFormat = @"{2}{0}";
            }
            else
            {
                leadTriviaFormat = @"{2}{0}{1}
{0}";
            }

            var leadTrivia = string.Format(leadTriviaFormat, AppGlobal.GetIndendation(this.Level), oldTrivia.Trim(), (this.HasLeadingEmptyLine(oldTrivia) ? Environment.NewLine : string.Empty));

            input = input.WithReturnKeyword(input.ReturnKeyword.WithLeadingTrivia(SyntaxFactory.ParseLeadingTrivia(leadTrivia)));
            input = input.WithSemicolonToken(input.SemicolonToken.WithTrailingTrivia(SyntaxFactory.ParseTrailingTrivia(Environment.NewLine)));

            return input;
        }

        #endregion
    }
}
