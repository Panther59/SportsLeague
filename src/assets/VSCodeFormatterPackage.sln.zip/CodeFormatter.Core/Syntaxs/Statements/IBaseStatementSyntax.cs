﻿// <copyright file="IBaseStatementSyntax.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>18-08-2017</date>

namespace CodeFormatter.Core.Syntaxs.Statements
{
    using Microsoft.CodeAnalysis.CSharp;
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    #region Interfaces

    /// <summary>
    /// Defines the <see cref="IBaseStatementSyntax" />
    /// </summary>
    public interface IBaseStatementSyntax
    {
        #region Properties

        /// <summary>
        /// Gets the Type
        /// </summary>
        SyntaxKind Type { get; }

        #endregion

        #region Methods

        /// <summary>
        /// The FixStatement
        /// </summary>
        /// <param name="input">The <see cref="StatementSyntax"/></param>
        /// <param name="level">The <see cref="int"/></param>
        /// <returns>The <see cref="StatementSyntax"/></returns>
        StatementSyntax FixStatement(StatementSyntax input, int level);

        #endregion
    }

    #endregion
}
