﻿// <copyright file="LocalObjectStatement.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>18-08-2017</date>

namespace CodeFormatter.Core.Syntaxs.Statements
{
    using System;
    using Microsoft.CodeAnalysis.CSharp;
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    /// <summary>
    /// Defines the <see cref="LocalObjectStatement" />
    /// </summary>
    public class LocalObjectStatement : BaseStatementSyntax<LocalDeclarationStatementSyntax>
    {
        #region Properties

        /// <summary>
        /// Gets the StatementType
        /// </summary>
        public override SyntaxKind StatementType => SyntaxKind.LocalDeclarationStatement;

        #endregion

        #region Methods

        /// <inheritdoc />
        protected override LocalDeclarationStatementSyntax InternalFixStatement(LocalDeclarationStatementSyntax input)
        {
            if (input.SemicolonToken == null || string.IsNullOrWhiteSpace(input.SemicolonToken.Text))
            {
                var existingTrailingTrivia = input.Declaration.GetTrailingTrivia().ToFullString();
                var declaration = input.Declaration.ToFullString();
                input = SyntaxFactory.ParseStatement(declaration.TrimEnd() + ";" + Environment.NewLine) as LocalDeclarationStatementSyntax;
            }

            return input;
        }

        #endregion
    }
}
