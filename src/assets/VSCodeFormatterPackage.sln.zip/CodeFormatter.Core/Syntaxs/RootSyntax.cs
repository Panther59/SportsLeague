﻿// <copyright file="RootSyntax.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>31-07-2017</date>

namespace CodeFormatter.Core.Syntaxs
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using CodeFormatter.Common.Contracts;
    using CodeFormatter.Core.Syntaxs.MemberGroups;
    using Microsoft.CodeAnalysis;
    using Microsoft.CodeAnalysis.CSharp;
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    /// <summary>
    /// Defines the <see cref = "RootSyntax"/>
    /// </summary>
    public class RootSyntax
    {
        #region Fields

        /// <summary>
        /// Defines the resolver
        /// </summary>
        private readonly IResolver resolver;

        /// <summary>
        /// Defines the settings
        /// </summary>
        private readonly IDefaultSettings settings;

        /// <summary>
        /// The 
        /// </summary>
        internal SyntaxList<UsingDirectiveSyntax> outsideUsing;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "RootSyntax"/> class.
        /// </summary>
        /// <param name = "setting">The setting file</param>
        public RootSyntax(IDefaultSettings setting, IResolver resolver)
        {
            this.resolver = resolver;
            this.settings = setting;
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// The ChangeNodeSyntax
        /// </summary>
        /// <param name = "input">The <see cref = "CompilationUnitSyntax"/></param>
        /// <returns>The <see cref = "CompilationUnitSyntax"/></returns>
        public CompilationUnitSyntax ChangeNodeSyntax(CompilationUnitSyntax rootElememt, string fileName, string header)
        {
            rootElememt = RemoveRegionLines(rootElememt);
            //rootElememt = rootElememt.NormalizeWhitespace();
            string fileHeader = rootElememt.ToFullString().Substring(0, rootElememt.SpanStart);
            var namespaceses = rootElememt.Members.Where(x => x.Kind() == SyntaxKind.NamespaceDeclaration);

            if (string.IsNullOrEmpty(fileHeader.Trim()))
            {
                fileHeader = GetHeaderContentFromTemplate(header, fileName);
            }
            rootElememt = rootElememt.WithoutLeadingTrivia();
            if (rootElememt.DescendantNodes().OfType<NamespaceDeclarationSyntax>().Any())
            {
                outsideUsing = rootElememt.Usings;
                rootElememt = rootElememt.ReplaceNodes(rootElememt.DescendantNodes().OfType<NamespaceDeclarationSyntax>(), (_, node) => this.ReapplyUsings(node));
                if (this.settings.MoveUsingInsideNamespace)
                {
                    SyntaxList<UsingDirectiveSyntax> blankUsings;
                    rootElememt = rootElememt.WithUsings(blankUsings);
                }
                else
                {
                    rootElememt = rootElememt.WithUsings(this.FixUsings(outsideUsing, 0));
                }
            }
            else
            {
                outsideUsing = rootElememt.Usings;
                rootElememt = rootElememt.WithUsings(this.FixUsings(outsideUsing, 0));
            }

            List<ClassMemberType> finalList = new List<ClassMemberType>();
            foreach (var item in rootElememt.Members)
            {
                ClassMemberType internalMember = this.resolver.Resolve<ClassMemberType>();
                internalMember.Load(item, 0, item is InterfaceDeclarationSyntax);
                finalList.Add(internalMember);
            }

            var typeLayout = this.resolver.Resolve<TypeLayout>();
            finalList = typeLayout.ApplyLayout(finalList);
            SyntaxList<MemberDeclarationSyntax> classMembers;
            foreach (var item in finalList)
            {
                classMembers = classMembers.Add(item.Member);
            }

            classMembers = this.TriviaChangesForBorderMembers(classMembers);
            rootElememt = rootElememt.ReplaceNodes(rootElememt.DescendantNodesAndSelf().OfType<CompilationUnitSyntax>(), (_, d) => this.ReplaceCompilation(d));
            rootElememt = rootElememt.WithMembers(classMembers);
            rootElememt = rootElememt.WithTrailingTrivia(this.GetTrailingTrivia(rootElememt));
            rootElememt = rootElememt.WithLeadingTrivia(this.GetLeadingTrivia(rootElememt, fileHeader));
            //newNode = newNode.NormalizeWhitespace();
            return rootElememt;
        }

        /// <summary>
        /// The ClearCommentFromNodeSyntax
        /// </summary>
        /// <param name = "input">The <see cref = "CompilationUnitSyntax"/></param>
        /// <returns>The <see cref = "CompilationUnitSyntax"/></returns>
        public CompilationUnitSyntax ClearCommentFromNodeSyntax(CompilationUnitSyntax rootElememt, string fileName, string header)
        {
            rootElememt = RemoveRegionLines(rootElememt);
            //rootElememt = rootElememt.NormalizeWhitespace();
            string fileHeader = rootElememt.ToFullString().Substring(0, rootElememt.SpanStart);
            var namespaceses = rootElememt.Members.Where(x => x.Kind() == SyntaxKind.NamespaceDeclaration);

            if (string.IsNullOrEmpty(fileHeader.Trim()))
            {
                fileHeader = GetHeaderContentFromTemplate(header, fileName);
            }
            rootElememt = rootElememt.WithoutLeadingTrivia();
            if (rootElememt.DescendantNodes().OfType<NamespaceDeclarationSyntax>().Any())
            {
                outsideUsing = rootElememt.Usings;
                rootElememt = rootElememt.ReplaceNodes(rootElememt.DescendantNodes().OfType<NamespaceDeclarationSyntax>(), (_, node) => this.ReapplyUsings(node));
                if (this.settings.MoveUsingInsideNamespace)
                {
                    SyntaxList<UsingDirectiveSyntax> blankUsings;
                    rootElememt = rootElememt.WithUsings(blankUsings);
                }
                else
                {
                    rootElememt = rootElememt.WithUsings(this.FixUsings(outsideUsing, 0));
                }
            }

            List<ClassMemberType> finalList = new List<ClassMemberType>();
            foreach (var item in rootElememt.Members)
            {
                ClassMemberType internalMember = this.resolver.Resolve<ClassMemberType>();
                internalMember.ClearComment(item, 0, item is InterfaceDeclarationSyntax);
                finalList.Add(internalMember);
            }

            var typeLayout = this.resolver.Resolve<TypeLayout>();
            finalList = typeLayout.ApplyLayout(finalList);
            SyntaxList<MemberDeclarationSyntax> classMembers;
            foreach (var item in finalList)
            {
                classMembers = classMembers.Add(item.Member);
            }

            classMembers = this.TriviaChangesForBorderMembers(classMembers);
            rootElememt = rootElememt.ReplaceNodes(rootElememt.DescendantNodesAndSelf().OfType<CompilationUnitSyntax>(), (_, d) => this.ReplaceCompilation(d));
            rootElememt = rootElememt.WithMembers(classMembers);
            rootElememt = rootElememt.WithTrailingTrivia(this.GetTrailingTrivia(rootElememt));
            rootElememt = rootElememt.WithLeadingTrivia(this.GetLeadingTrivia(rootElememt, fileHeader));
            //newNode = newNode.NormalizeWhitespace();
            return rootElememt;
        }

        /// <summary>
        /// The GetLeadingTrivia
        /// </summary>
        /// <param name="syntax">The <see cref="CompilationUnitSyntax"/></param>
        /// <returns>The <see cref="SyntaxTrivia"/></returns>
        public SyntaxTrivia GetLeadingTrivia(CompilationUnitSyntax syntax, string header)
        {
            var existingTrivia = syntax.GetLeadingTrivia().ToFullString();

            if (header != null && string.IsNullOrEmpty(header.ToString().Trim()) == false)
            {
                if (string.IsNullOrWhiteSpace(existingTrivia))
                {
                    return SyntaxFactory.Whitespace(header.ToString().Trim() + Environment.NewLine + Environment.NewLine);
                }
                else
                {
                    return SyntaxFactory.Whitespace(header.ToString().Trim() + Environment.NewLine + Environment.NewLine + existingTrivia.TrimStart().TrimEnd() + Environment.NewLine);
                }
            }
            else
            {
                return SyntaxFactory.Whitespace(string.Empty);
            }
        }

        /// <summary>
        /// The GetTrailingTrivia
        /// </summary>
        /// <param name="syntax">The <see cref="CompilationUnitSyntax"/></param>
        /// <returns>The <see cref="SyntaxTrivia"/></returns>
        public SyntaxTrivia GetTrailingTrivia(CompilationUnitSyntax syntax)
        {
            return SyntaxFactory.Whitespace(string.Empty);
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// The FixUsings
        /// </summary>
        /// <param name="outsideUsing">The <see cref="SyntaxList{UsingDirectiveSyntax}"/></param>
        /// <param name="level">The <see cref="int"/></param>
        /// <returns>The <see cref="SyntaxList{UsingDirectiveSyntax}"/></returns>
        private SyntaxList<UsingDirectiveSyntax> FixUsings(SyntaxList<UsingDirectiveSyntax> outsideUsing, int level)
        {
            outsideUsing = SortNamespaces(outsideUsing);
            SyntaxList<UsingDirectiveSyntax> output;
            foreach (UsingDirectiveSyntax item in outsideUsing)
            {
                var usingToken = item.WithoutLeadingTrivia().WithLeadingTrivia(SyntaxFactory.Whitespace(AppGlobal.GetIndendation(level)));
                if (output.Count == outsideUsing.Count - 1)
                {
                    usingToken = usingToken.WithTrailingTrivia(SyntaxFactory.Whitespace(usingToken.GetTrailingTrivia().ToString() + Environment.NewLine));
                }

                output = output.Add(usingToken);
            }

            return output;
        }

        /// <summary>
        /// The GetHeaderContentFromTemplate
        /// </summary>
        /// <param name="header">The <see cref="string"/></param>
        /// <param name="fileName">The <see cref="string"/></param>
        /// <returns>The <see cref="string"/></returns>
        private string GetHeaderContentFromTemplate(string header, string fileName)
        {
            if (header == null)
            {
                return null;
            }

            //{ "Select", "File Name", "Current Year", "Current Month", "Current Day", "Current Date", "Current Date Time", "User Name"};
            header = header.Replace("$File Name$", fileName);
            header = header.Replace("$Current Year$", DateTime.Now.ToString("yyyy"));
            header = header.Replace("$Current Month$", DateTime.Now.ToString("MM"));
            header = header.Replace("$Current Day$", DateTime.Now.ToString("dd"));
            header = header.Replace("$Current Date$", DateTime.Now.ToShortDateString());
            header = header.Replace("$Current Date Time$", DateTime.Now.ToString());
            header = header.Replace("$User Name$", System.Security.Principal.WindowsIdentity.GetCurrent().Name);

            return header;
        }

        /// <summary>
        /// The ReapplyUsings
        /// </summary>
        /// <param name="node">The <see cref="NamespaceDeclarationSyntax"/></param>
        /// <returns>The <see cref="NamespaceDeclarationSyntax"/></returns>
        private NamespaceDeclarationSyntax ReapplyUsings(NamespaceDeclarationSyntax node)
        {
            var namespaceUsing = node.Usings;
            if (this.settings.MoveUsingInsideNamespace)
            {
                namespaceUsing = namespaceUsing.AddRange(outsideUsing);
            }

            node = node.WithUsings(namespaceUsing);

            return node;
        }

        /// <summary>
        /// Removes the Region and endregion lines from the code
        /// </summary>
        /// <param name = "input">The root object</param>
        /// <returns>The root object after removing region code</returns>
        private CompilationUnitSyntax RemoveRegionLines(CompilationUnitSyntax input)
        {
            var trivia = input.DescendantTrivia().Where(t => t.HasStructure && (t.GetStructure().Kind() == SyntaxKind.RegionDirectiveTrivia || t.GetStructure().Kind() == SyntaxKind.EndRegionDirectiveTrivia));
            input = input.ReplaceTrivia(trivia, (t, t2) => SyntaxFactory.Whitespace(string.Empty));
            return input;
        }

        /// <summary>
        /// The ReplaceCompilation
        /// </summary>
        /// <param name="syntax">The <see cref="CompilationUnitSyntax"/></param>
        /// <returns>The <see cref="SyntaxNode"/></returns>
        private SyntaxNode ReplaceCompilation(CompilationUnitSyntax syntax)
        {
            string endOfFileTokenStr = syntax.EndOfFileToken.ToFullString()?.Trim();
            syntax = syntax.WithEndOfFileToken(SyntaxFactory.ParseToken(endOfFileTokenStr));
            return syntax;
        }

        /// <summary>
        /// The SortNamespaces
        /// </summary>
        /// <param name = "usingDirectives">The <see cref = "SyntaxList{UsingDirectiveSyntax}"/></param>
        /// <param name = "placeSystemNamespaceFirst">The <see cref = "bool "/></param>
        /// <returns>The <see cref = "SyntaxList{UsingDirectiveSyntax}"/></returns>
        private SyntaxList<UsingDirectiveSyntax> SortNamespaces(SyntaxList<UsingDirectiveSyntax> usingDirectives, bool placeSystemNamespaceFirst = false)
        {
            var output = SyntaxFactory.List(usingDirectives.OrderBy(x => x.StaticKeyword.IsKind(SyntaxKind.StaticKeyword) ? 1 : x.Alias == null ? 0 : 2).ThenBy(x => x.Alias?.ToString()).ThenByDescending(x => placeSystemNamespaceFirst && (x.Name.ToString().StartsWith(nameof(System) + ".") || (x.Name.ToString() == "System"))).ThenBy(x => x.Name.ToString()));
            return output;
        }

        /// <summary>
        /// The TriviaChangesForBorderMembers
        /// </summary>
        /// <param name = "classMembers">The <see cref = "SyntaxList{MemberDeclarationSyntax}"/></param>
        /// <returns>The <see cref = "SyntaxList{MemberDeclarationSyntax}"/></returns>
        private SyntaxList<MemberDeclarationSyntax> TriviaChangesForBorderMembers(SyntaxList<MemberDeclarationSyntax> classMembers)
        {
            if (classMembers.Count > 0)
            {
                var last = classMembers[classMembers.Count - 1];
                var lastTrailing = last.GetTrailingTrivia().ToFullString().TrimEnd() + System.Environment.NewLine;
                last = last.WithoutTrailingTrivia().WithTrailingTrivia(SyntaxFactory.Whitespace(lastTrailing));
                classMembers = classMembers.RemoveAt(classMembers.Count - 1);
                classMembers = classMembers.Insert(classMembers.Count, last);
            }

            return classMembers;
        }

        #endregion

        #endregion
    }
}
