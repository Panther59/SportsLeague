﻿// <copyright file="IBaseRootMemberSyntax.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>31-07-2017</date>

namespace CodeFormatter.Core.Syntaxs
{
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    #region Interfaces

    /// <summary>
    /// Defines the <see cref = IBaseMemberSyntax / >
    /// </summary>
    public interface IBaseMemberSyntax
    {
        #region Properties

        /// <summary>
        /// Gets or sets Level
        /// </summary>
        int Level { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// The ApplyLineSeparation
        /// </summary>
        /// <param name="source">The <see cref="MemberDeclarationSyntax"/></param>
        /// <param name="memberSeparationLinesCount">The <see cref="int"/></param>
        /// <returns>The <see cref="MemberDeclarationSyntax"/></returns>
        MemberDeclarationSyntax ApplyLineSeparation(MemberDeclarationSyntax source, int memberSeparationLinesCount);

        /// <summary>
        /// The FixNode
        /// </summary>
        /// <param name = "source">The <see cref = "MemberDeclarationSyntax"/></param>
        /// <returns>The <see cref = "MemberDeclarationSyntax"/></returns>
        MemberDeclarationSyntax FixNode(MemberDeclarationSyntax source, int level);

        /// <summary>
        /// The ClearComment
        /// </summary>
        /// <param name = "source">The <see cref = "MemberDeclarationSyntax"/></param>
        /// <returns>The <see cref = "MemberDeclarationSyntax"/></returns>
        MemberDeclarationSyntax ClearComment(MemberDeclarationSyntax source, int level);

        #endregion
    }

    #endregion
}
