﻿namespace CodeFormatter.Core.Syntaxs
{
    using CodeFormatter.Common.Contracts;
    using Microsoft.CodeAnalysis;
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    /// <summary>
    /// Defines the <see cref = "InterfaceTypeSyntax"/>
    /// </summary>
    public class InterfaceTypeSyntax : BaseTypeMemberSyntax<InterfaceDeclarationSyntax>
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "InterfaceTypeSyntax"/> class.
        /// </summary>
        /// <param name = "setting">The <see cref = "IDefaultSettings"/></param>
        /// <param name = "resolver">The <see cref = "IResolver"/></param>
        public InterfaceTypeSyntax(IDefaultSettings setting, IResolver resolver) : base(setting, resolver)
        {
        }

        #endregion

        #region Methods

        /// <inheritdoc/>
        protected override InterfaceDeclarationSyntax AddMembersToType(InterfaceDeclarationSyntax type, SyntaxList<MemberDeclarationSyntax> classMembers)
        {
            type = type.WithMembers(classMembers);
            return type;
        }

        #endregion
    }
}
