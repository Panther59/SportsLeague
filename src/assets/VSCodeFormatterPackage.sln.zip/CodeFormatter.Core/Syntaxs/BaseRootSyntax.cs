﻿// <copyright file="BaseRootSyntax.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>31-07-2017</date>

namespace CodeFormatter.Core.Syntaxs
{
    using CodeFormatter.Common.Contracts;
    using CodeFormatter.Core.Syntaxs.TypeMembers;
    using Microsoft.CodeAnalysis;
    using Microsoft.CodeAnalysis.CSharp;
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    /// <summary>
    /// Defines the <see cref = "BaseRootSyntax{T}"/>
    /// </summary>
    /// <typeparam name = "T">The Member Declaration type</typeparam>
    public abstract class BaseRootSyntax<T> : BaseMemberSyntax, IBaseMemberSyntax where T : MemberDeclarationSyntax
    {
        #region Fields

        /// <summary>
        /// Defines the setting
        /// </summary>
        private readonly IDefaultSettings setting;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "BaseRootSyntax{T}"/> class.
        /// </summary>
        /// <param name = "setting">The setting file</param>
        public BaseRootSyntax(IDefaultSettings setting)
        {
            this.setting = setting;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the Settings
        /// </summary>
        public IDefaultSettings Setting
        {
            get
            {
                return setting;
            }
        }

        /// <summary>
        /// Gets or sets the Level
        /// </summary>
        public int Level
        {
            get;
            set;
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// The CanSyntaxHeaderBeModified
        /// </summary>
        /// <param name="syntax">The <see cref="T"/></param>
        /// <returns>The <see cref="bool"/></returns>
        public abstract bool CanSyntaxHeaderBeModified(T syntax);

        /// <inheritdoc/>
        public MemberDeclarationSyntax FixNode(MemberDeclarationSyntax input, int level)
        {
            this.Level = level;
            var obj = input as T;
            if (obj != null)
            {
                return this.ChangeNodeSyntax(obj);
            }

            return null;
        }

        /// <summary>
        /// The GetNewLeadingTrivia
        /// </summary>
        /// <param name = "syntax">The <see cref = "T"/></param>
        /// <returns>The <see cref = "SyntaxTrivia"/></returns>
        public abstract SyntaxTrivia GetNewLeadingTrivia(T syntax);

        /// <summary>
        /// The GetExistingLeadingTrivia
        /// </summary>
        /// <param name = "syntax">The <see cref = "T"/></param>
        /// <returns>The <see cref = "SyntaxTrivia"/></returns>
        public virtual SyntaxTrivia GetExistingLeadingTrivia(T syntax)
        {
            var commentFormat = @"{1}{0}
{1}";
            var finalComment = string.Format(commentFormat, syntax.GetLeadingTrivia().ToString().Trim(), AppGlobal.GetIndendation(this.Level));

            return SyntaxFactory.Whitespace(finalComment);
        }

        /// <summary>
        /// The GetTrailingTrivia
        /// </summary>
        /// <param name = "syntax">The <see cref = "T"/></param>
        /// <returns>The <see cref = "SyntaxTrivia"/></returns>
        public abstract SyntaxTrivia GetTrailingTrivia(T syntax);

        #endregion

        /// <summary>
        /// The ChangeNodeSyntax
        /// </summary>
        /// <param name = "input">The <see cref = "T"/></param>
        /// <returns>The <see cref = "T"/></returns>
        protected virtual T ChangeNodeSyntax(T input)
        {
            var newNode = input.WithTrailingTrivia(this.GetTrailingTrivia(input));
            bool existingComment = string.IsNullOrEmpty(input.GetLeadingTrivia().ToString().Trim()) == false;
            bool summaryTagPresent = existingComment ? input.GetLeadingTrivia().ToString().Contains("summary") : false;
            SyntaxTrivia leadingSyntax;

            if (summaryTagPresent || this.CanSyntaxHeaderBeModified(input) == false)
            {
                leadingSyntax = this.GetExistingLeadingTrivia(input);
            }
            else
            {
                leadingSyntax = this.GetNewLeadingTrivia(input);
            }

            newNode = newNode.WithLeadingTrivia(leadingSyntax);
            return newNode;
        }

        #endregion
    }
}