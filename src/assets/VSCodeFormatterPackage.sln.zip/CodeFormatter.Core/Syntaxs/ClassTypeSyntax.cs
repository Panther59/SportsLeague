﻿// <copyright file="ClassTypeSyntax.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>21-08-2017</date>

namespace CodeFormatter.Core.Syntaxs
{
    using System;
    using System.Linq;
    using CodeFormatter.Common;
    using CodeFormatter.Common.Contracts;
    using Microsoft.CodeAnalysis;
    using Microsoft.CodeAnalysis.CSharp;
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    /// <summary>
    /// Defines the <see cref = "ClassTypeSyntax"/>
    /// </summary>
    public class ClassTypeSyntax : BaseTypeMemberSyntax<ClassDeclarationSyntax>
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "ClassTypeSyntax"/> class.
        /// </summary>
        /// <param name = "setting">The <see cref = "IDefaultSettings"/></param>
        /// <param name = "resolver">The <see cref = "IResolver"/></param>
        public ClassTypeSyntax(IDefaultSettings setting, IResolver resolver) : base(setting, resolver)
        {
        }

        #endregion

        #region Methods

        /// <inheritdoc/>
        protected override ClassDeclarationSyntax AddMembersToType(ClassDeclarationSyntax type, SyntaxList<MemberDeclarationSyntax> classMembers)
        {
            //type = type.Update(type.AttributeLists, type.Modifiers, type.Keyword, type.Identifier, type.TypeParameterList, type.BaseList, type.ConstraintClauses, type.OpenBraceToken, classMembers, type.CloseBraceToken, type.SemicolonToken);
            type = type.WithMembers(classMembers);
            if (this.Setting.StatementFixes)
            {
                type = this.AddMissingThisKeyword(type);
            }
            return type;
        }

        #region Private Methods

        /// <summary>
        /// The AddMissingThisKeyword
        /// </summary>
        /// <param name="type">The <see cref="ClassDeclarationSyntax"/></param>
        /// <returns>The <see cref="ClassDeclarationSyntax"/></returns>
        private ClassDeclarationSyntax AddMissingThisKeyword(ClassDeclarationSyntax type)
        {

            type = type.ReplaceNodes(type.DescendantNodes().OfType<IdentifierNameSyntax>(), (_, e) => this.ReplaceInvocation(type, e));
            //type = type.ReplaceNodes(type.DescendantNodes().OfType<InvocationExpressionSyntax>(), (_, e) => this.ReplaceInvocation(type, e));
            return type;
        }

        /// <summary>
        /// The IsNonStaticMember
        /// </summary>
        /// <param name="member">The <see cref="MemberDeclarationSyntax"/></param>
        /// <param name="memberName">The <see cref="string"/></param>
        /// <returns>The <see cref="bool"/></returns>
        private bool IsNonStaticMember(MemberDeclarationSyntax member, string memberName)
        {
            if (member is MethodDeclarationSyntax)
            {
                var mem = member as MethodDeclarationSyntax;
                if (mem.Identifier.Text.Trim() == memberName && mem.Modifiers.Any(x => x.Text.Trim() == Constants.Static) == false)
                {
                    return true;
                }
            }
            else if (member is BaseFieldDeclarationSyntax) //// will cover field and event
            {
                var field = member as BaseFieldDeclarationSyntax;
                if (field.Declaration.Variables.Any(x => x.Identifier.Text.Trim() == memberName) && field.Modifiers.Any(x => x.Text.Trim() == Constants.Static) == false)
                {
                    return true;
                }
            }
            else if (member is PropertyDeclarationSyntax)
            {
                var prop = member as PropertyDeclarationSyntax;
                if (prop.Identifier.Text.Trim() == memberName && prop.Modifiers.Any(x => x.Text.Trim() == Constants.Static) == false)
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// The ReplaceInvocation
        /// </summary>
        /// <param name="type">The <see cref="ClassDeclarationSyntax"/></param>
        /// <param name="e">The <see cref="IdentifierNameSyntax"/></param>
        /// <returns>The <see cref="SyntaxNode"/></returns>
        private SyntaxNode ReplaceInvocation(ClassDeclarationSyntax type, IdentifierNameSyntax e)
        {
            if (e.Parent != null && e.Parent.Kind() == SyntaxKind.SimpleMemberAccessExpression)
            {
                //// Since already this is present
                return e;
            }

            var existingMember = type.Members.Any(x => this.IsNonStaticMember(x, e.Identifier.Text.Trim()));
            if (existingMember)
            {
                var leadingTrivia = e.GetLeadingTrivia();
                return SyntaxFactory.ParseName(leadingTrivia + "this." + e.ToFullString().TrimStart());
            }

            return e;
        }

        /// <summary>
        /// The ReplaceInvocation
        /// </summary>
        /// <param name="type">The <see cref="ClassDeclarationSyntax"/></param>
        /// <param name="exp">The <see cref="InvocationExpressionSyntax"/></param>
        /// <returns>The <see cref="SyntaxNode"/></returns>
        private SyntaxNode ReplaceInvocation(ClassDeclarationSyntax type, InvocationExpressionSyntax exp)
        {
            if (exp.Expression != null && exp.Expression.Kind() == SyntaxKind.SimpleMemberAccessExpression)
            {
                //// nothing needs to be done in this case;
                return exp;
            }

            if (exp.Expression != null && exp.Expression.Kind() == SyntaxKind.IdentifierName)
            {
                IdentifierNameSyntax nameSyn = (IdentifierNameSyntax)exp.Expression;
                var existingMember = type.Members.FirstOrDefault(x => (x is MethodDeclarationSyntax) && ((MethodDeclarationSyntax)x).Identifier.Text.Trim() == nameSyn.Identifier.Text.Trim()) as MethodDeclarationSyntax;
                if (existingMember != null && existingMember.Modifiers.Any(x => x.Text.Trim() == "static") == false)
                {
                    var leadingTrivia = exp.Expression.GetLeadingTrivia();
                    return SyntaxFactory.MemberAccessExpression(SyntaxKind.SimpleMemberAccessExpression, SyntaxFactory.ParseExpression("this").WithLeadingTrivia(leadingTrivia), SyntaxFactory.ParseToken("."), (SimpleNameSyntax)SyntaxFactory.ParseName(exp.Expression.ToFullString().TrimStart()));
                }
                //MemberAccessExpressionSyntax memberAccess = new MemberAccessExpressionSyntax(
                //memberAccess = memberAccess.WithExpression(SyntaxFactory.ParseExpression("this"));
                //, SyntaxFactory.ParseToken("."), exp.Expression);
            }

            return exp;
        }

        #endregion

        #endregion
    }
}
