namespace CodeFormatter.Core.Syntaxs.MemberGroups
{
    using CodeFormatter.Common;

    /// <summary>
    /// Defines the <see cref = "FindByAccessModifier"/>
    /// </summary>
    public class FindByAccessModifier : BaseCondition, ICondition
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "FindByAccessModifier"/> class.
        /// </summary>
        public FindByAccessModifier()
        {
            this.Name = Constants.AccessModifier;
            this.Priority = 4;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets AccessModifier
        /// </summary>
        public string AccessModifier
        {
            get;
            set;
        }

        #endregion

        #region Methods

        /// <inheritdoc/>
        public override bool IsMatch(ClassMemberType member)
        {
            return member.ModifierDesc.Contains(this.AccessModifier);
        }

        #endregion
    }
}
