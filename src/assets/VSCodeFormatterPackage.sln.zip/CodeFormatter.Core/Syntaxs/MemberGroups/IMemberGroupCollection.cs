namespace CodeFormatter.Core.Syntaxs.MemberGroups
{
    using System.Collections.Generic;

    /// <summary>
    /// Declares the <see cref = "IMemberGroupCollection"/>
    /// </summary>
    public interface IMemberGroupCollection : IMemberGroup
    {
        #region Properties

        /// <summary>
        /// Gets or sets the MemberGroups
        /// </summary>
        List<IMemberGroup> MemberGroups
        {
            get;
            set;
        }

        #endregion
    }
}
