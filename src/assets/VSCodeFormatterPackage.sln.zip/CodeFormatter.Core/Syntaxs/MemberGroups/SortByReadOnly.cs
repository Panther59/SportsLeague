namespace CodeFormatter.Core.Syntaxs.MemberGroups
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using CodeFormatter.Common;

    /// <summary>
    /// Defines the <see cref = "SortByReadOnly"/>
    /// </summary>
    public class SortByReadOnly : BaseSort
    {
        
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "SortByReadOnly"/> class.
        /// </summary>
        public SortByReadOnly()
        {
            this.Name = Constants.ReadOnly;
        }

        public override List<ClassMemberType> ApplySorting(List<ClassMemberType> matchedMembers)
        {
            matchedMembers = matchedMembers?.OrderByDescending(x => x.ModifierDesc.Contains("readonly") ? 1 : 0).ToList();

            return matchedMembers;
        }

        #endregion
    }
}
