namespace CodeFormatter.Core.Syntaxs.MemberGroups
{
    using System.Collections.Generic;
    using System.Linq;
    using CodeFormatter.Common;

    /// <summary>
    /// Defines the <see cref = "SortByModifier"/>
    /// </summary>
    public class SortByModifier : BaseSort
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "SortByModifier"/> class.
        /// </summary>
        public SortByModifier()
        {
            this.Name = Constants.AccessModifier;
        }

        #endregion

        #region Methods

        /// <summary>
        /// The ApplySorting
        /// </summary>
        /// <param name="matchedMembers">The <see cref="List{ClassMemberType}"/></param>
        /// <returns>The <see cref="List{ClassMemberType}"/></returns>
        public override List<ClassMemberType> ApplySorting(List<ClassMemberType> matchedMembers)
        {
            matchedMembers = matchedMembers?.OrderBy(x => x.ModifierRank).ToList();
            return matchedMembers;
        }

        #endregion
    }
}
