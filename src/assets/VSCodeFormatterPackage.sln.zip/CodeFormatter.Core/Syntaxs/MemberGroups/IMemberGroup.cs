namespace CodeFormatter.Core.Syntaxs.MemberGroups
{
    using System.Collections.Generic;

    public interface IMemberGroup
    {
        #region Properties

        /// <summary>
        /// Gets the GUID
        /// </summary>
        string GUID
        {
            get;
            set;
        }

        /// <summary>
        /// Gets Name
        /// </summary>
        string Name
        {
            get;
            set;
        }

        #endregion
    }
}
