namespace CodeFormatter.Core.Syntaxs.MemberGroups
{
    using System;

    /// <summary>
    /// Defines the <see cref = "BaseCondition"/>
    /// </summary>
    public abstract class BaseCondition : ICondition
    {
        #region Properties

        /// <summary>
        /// Gets the Name
        /// </summary>
        public string Name
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the Priority
        /// </summary>
        public int Priority
        {
            get;
            set;
        }

        #endregion

        #region Methods

        /// <summary>
        /// The IsMatch
        /// </summary>
        /// <param name="member">The <see cref="ClassMemberType"/></param>
        /// <returns>The <see cref="bool"/></returns>
        public abstract bool IsMatch(ClassMemberType member);

        #endregion
    }
}
