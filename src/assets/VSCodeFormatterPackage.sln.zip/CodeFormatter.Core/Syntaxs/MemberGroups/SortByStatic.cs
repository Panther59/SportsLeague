namespace CodeFormatter.Core.Syntaxs.MemberGroups
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using CodeFormatter.Common;

    /// <summary>
    /// Defines the <see cref = "SortByStatic"/>
    /// </summary>
    public class SortByStatic : BaseSort
    {
        
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "SortByStatic"/> class.
        /// </summary>
        public SortByStatic()
        {
            this.Name = Constants.IsStatic;
        }

        public override List<ClassMemberType> ApplySorting(List<ClassMemberType> matchedMembers)
        {
            matchedMembers = matchedMembers?.OrderByDescending(x => x.ModifierDesc.Contains("static") ? 1 : 0).ToList();

            return matchedMembers;
        }

        #endregion
    }
}
