namespace CodeFormatter.Core.Syntaxs.MemberGroups
{
    using System.Collections.Generic;

    /// <summary>
    /// Defines the <see cref = "BaseSort"/>
    /// </summary>
    public abstract class BaseSort : ISort
    {
        #region Properties

        /// <summary>
        /// Gets the Name
        /// </summary>
        public string Name
        {
            get;
            set;
        }

        #endregion

        #region Methods

        /// <summary>
        /// The ApplySorting
        /// </summary>
        /// <param name="matchedMembers">The <see cref="List{ClassMemberType}"/></param>
        /// <returns>The <see cref="List{ClassMemberType}"/></returns>
        public abstract List<ClassMemberType> ApplySorting(List<ClassMemberType> matchedMembers);

        #endregion
    }
}
