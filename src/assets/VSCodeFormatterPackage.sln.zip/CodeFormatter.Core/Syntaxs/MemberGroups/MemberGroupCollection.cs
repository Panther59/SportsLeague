namespace CodeFormatter.Core.Syntaxs.MemberGroups
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    /// <summary>
    /// Defines the <see cref = "MemberGroupCollection"/>
    /// </summary>
    public class MemberGroupCollection : BaseMemberGroup, IMemberGroupCollection
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "MemberGroupCollection"/> class.
        /// </summary>
        public MemberGroupCollection()
        {
            this.GUID = Guid.NewGuid().ToString();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the Priority
        /// </summary>
        public int Priority
        {
            get
            {
                int? priority = this.MemberGroups?.Max(x => x is MemberLayout ? ((MemberLayout)x).Priority : ((MemberGroupCollection)x).Priority);
                return priority ?? 0;
            }
        }

        /// <summary>
        /// Gets or sets Operations
        /// </summary>
        public List<IMemberGroup> MemberGroups
        {
            get;
            set;
        }

        #endregion

        #region Methods

        /// <summary>
        /// The MatchMembers
        /// </summary>
        /// <param name = "input">The <see cref = "List{ClassMemberType}"/></param>
        /// <returns>The <see cref = "List{ClassMemberType}"/></returns>
        public List<ClassMemberType> MatchMembers(List<ClassMemberType> input)
        {
            var sortedMembers = this.MemberGroups?.OrderByDescending(x => x is MemberLayout ? ((MemberLayout)x).Priority : ((MemberGroupCollection)x).Priority);
            foreach (var member in input)
            {
                if (sortedMembers != null)
                {
                    foreach (var childMemberGroup in sortedMembers)
                    {
                        MemberLayout memberLayout = childMemberGroup as MemberLayout;
                        if (memberLayout != null)
                        {
                            //// Match the mathching members and return the remaining members so that it can be tried in the other member group
                            input = memberLayout.MatchMembers(input);
                        }
                        else
                        {
                            MemberGroupCollection collection = childMemberGroup as MemberGroupCollection;
                            //// Match the mathching members and return the remaining members so that it can be tried in the other member group
                            input = collection.MatchMembers(input);
                        }
                    }
                }
            }

            return input;
        }

        /// <inheritdoc/>
        protected override List<ClassMemberType> InternalGetMembers()
        {
            List<ClassMemberType> newlist = new List<ClassMemberType>();
            if (this.MemberGroups != null)
            {
                foreach (var memberGroup in this.MemberGroups)
                {
                    MemberLayout memberLayout = memberGroup as MemberLayout;
                    if (memberLayout != null)
                    {
                        List<ClassMemberType> subList = memberLayout.GetMembers();
                        if (subList != null)
                        {
                            newlist.AddRange(subList);
                        }
                    }
                    else
                    {
                        MemberGroupCollection collection = memberGroup as MemberGroupCollection;
                        List<ClassMemberType> subList = collection.GetMembers();
                        if (subList != null)
                        {
                            newlist.AddRange(subList);
                        }
                    }
                }
            }

            this.MatchedMembers = newlist;
            this.ApplyRegions();
            return this.MatchedMembers;
        }

        #endregion
    }
}
