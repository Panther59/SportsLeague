namespace CodeFormatter.Core.Syntaxs.MemberGroups
{
    public interface ISort
    {
        #region Properties

        /// <summary>
        /// Gets the Name
        /// </summary>
        string Name
        {
            get;
            set;
        }

        #endregion
    }
}
