namespace CodeFormatter.Core.Syntaxs.MemberGroups
{
    using CodeFormatter.Common;

    /// <summary>
    /// Defines the <see cref = "OrMemberGroupCollection"/>
    /// </summary>
    public class OrMemberGroupCollection : MemberGroupCollection, IMemberGroup
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "OrMemberGroupCollection"/> class.
        /// </summary>
        public OrMemberGroupCollection()
        {
            this.Name = Constants.Or;
        }

        #endregion
    }
}
