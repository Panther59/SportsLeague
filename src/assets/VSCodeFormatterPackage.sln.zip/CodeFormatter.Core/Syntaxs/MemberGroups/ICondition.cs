namespace CodeFormatter.Core.Syntaxs.MemberGroups
{
    /// <summary>
    /// Declares the <see cref = "ICondition"/>
    /// </summary>
    public interface ICondition
    {
        #region Properties

        /// <summary>
        /// Gets Name
        /// </summary>
        string Name
        {
            get;
            set;
        }

        #endregion
    }
}
