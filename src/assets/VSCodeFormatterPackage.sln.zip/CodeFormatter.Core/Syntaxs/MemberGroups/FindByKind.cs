namespace CodeFormatter.Core.Syntaxs.MemberGroups
{
    using System;
    using System.Linq;
    using CodeFormatter.Common;
    using CodeFormatter.Common.Entities;
    using Microsoft.CodeAnalysis.CSharp;
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    /// <summary>
    /// Defines the <see cref = "FindByKind"/>
    /// </summary>
    public class FindByKind : BaseCondition
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "FindByKind"/> class.
        /// </summary>
        public FindByKind()
        {
            this.Name = Constants.Kind;
            this.Priority = 1;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        public MemberKinds Kind
        {
            get;
            set;
        }

        #endregion

        #region Methods

        /// <inheritdoc/>
        public override bool IsMatch(ClassMemberType member)
        {
            SyntaxKind actualKind = member.Member.Kind();

            switch (Kind)
            {
                case MemberKinds.Constants:
                    {
                        if (actualKind == SyntaxKind.FieldDeclaration && this.HasConstantModifier(member.Member))
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                case MemberKinds.Fields:
                    if (actualKind == SyntaxKind.FieldDeclaration && this.HasConstantModifier(member.Member) == false)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                case MemberKinds.Constructors:
                    return actualKind == SyntaxKind.ConstructorDeclaration;
                case MemberKinds.Destructors:
                    return actualKind == SyntaxKind.DestructorDeclaration;
                case MemberKinds.Delegates:
                    return actualKind == SyntaxKind.DelegateDeclaration;
                case MemberKinds.Events:
                    return actualKind == SyntaxKind.EventFieldDeclaration;
                case MemberKinds.Enums:
                    return actualKind == SyntaxKind.EnumDeclaration;
                case MemberKinds.Interfaces:
                    return actualKind == SyntaxKind.InterfaceDeclaration;
                case MemberKinds.Indexers:
                    return actualKind == SyntaxKind.IndexerDeclaration;
                case MemberKinds.Properties:
                    return actualKind == SyntaxKind.PropertyDeclaration;
                case MemberKinds.Methods:
                    return actualKind == SyntaxKind.MethodDeclaration;
                case MemberKinds.Structs:
                    return actualKind == SyntaxKind.StructDeclaration;
                case MemberKinds.Classes:
                    return actualKind == SyntaxKind.ClassDeclaration;
                case MemberKinds.Namespaces:
                    return actualKind == SyntaxKind.NamespaceDeclaration;
                default:
                    return false;
            }
        }

        private bool HasConstantModifier(MemberDeclarationSyntax member)
        {
            var fieldDes = member as FieldDeclarationSyntax;
            if (fieldDes != null &&
                fieldDes.Modifiers != null &&
                fieldDes.Modifiers.Any(x => x.Kind() == SyntaxKind.ConstKeyword))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        #endregion
    }
}
