// <copyright file="memberlayout.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>18-08-2017</date>

namespace CodeFormatter.Core.Syntaxs.MemberGroups
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using CodeFormatter.Common;
    using Microsoft.CodeAnalysis;

    /// <summary>
    /// Defines the <see cref = "MemberLayout"/>
    /// </summary>
    public class MemberLayout : BaseMemberGroup, IMemberLayout
    {
        #region Fields

        /// <summary>
        /// Defines the memberSeparationLinesCount
        /// </summary>
        private int memberSeparationLinesCount = 1;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "MemberLayout"/> class.
        /// </summary>
        public MemberLayout()
        {
            this.Name = Constants.Member;
            this.GUID = Guid.NewGuid().ToString();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets Conditions
        /// </summary>
        public List<ICondition> Conditions { get; set; }
        
        /// <summary>
        /// Gets or sets the MemberSeparationLinesCount
        /// </summary>
        public int MemberSeparationLinesCount
        {
            get { return memberSeparationLinesCount; }
            set { memberSeparationLinesCount = value; }
        }

        /// <summary>
        /// Gets the Priority
        /// </summary>
        public int Priority
        {
            get
            {
                IEnumerable<BaseCondition> mappedCondition = this.MappedConditions;
                int? priority = mappedCondition?.Max(x => x.Priority);
                return priority ?? 0;
            }
        }

        /// <summary>
        /// Gets or sets Sortings
        /// </summary>
        public List<ISort> Sortings { get; set; }

        /// <summary>
        /// Gets the MappedConditions
        /// </summary>
        private IEnumerable<BaseCondition> MappedConditions
        {
            get
            {
                if (this.Conditions != null)
                {
                    IEnumerable<BaseCondition> mappedCondition = this.Conditions.Select(x => x as BaseCondition);
                    return mappedCondition;
                }

                return null;
            }
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// The MatchMembers
        /// </summary>
        /// <param name = "input">The <see cref = "List{ClassMemberType}"/></param>
        /// <returns>The <see cref = "List{ClassMemberType}"/></returns>
        public List<ClassMemberType> MatchMembers(List<ClassMemberType> input)
        {
            var sortedCondition = this.MappedConditions?.OrderByDescending(x => x.Priority);
            foreach (var member in input)
            {
                var isMatch = false;
                if (sortedCondition != null)
                {
                    foreach (var condition in sortedCondition)
                    {
                        isMatch = condition.IsMatch(member);
                        if (isMatch == false)
                        {
                            break;
                        }
                    }
                }

                if (isMatch)
                {
                    if (this.MatchedMembers == null)
                    {
                        this.MatchedMembers = new List<ClassMemberType>();
                    }

                    member.ApplyLineSeparation(this.MemberSeparationLinesCount);
                    this.MatchedMembers.Add(member);
                }
            }

            input = input.Where(x => this.MatchedMembers == null || MatchedMembers.Any(y => y.GUID == x.GUID) == false).ToList();
            return input;
        }

        #endregion

        /// <inheritdoc/>
        protected override List<ClassMemberType> InternalGetMembers()
        {
            this.ApplySorting();
            this.ApplyRegions();
            return this.MatchedMembers;
        }

        #region Private Methods

        /// <summary>
        /// The ApplySorting
        /// </summary>
        private void ApplySorting()
        {
            if (this.MatchedMembers != null)
            {
                IEnumerable<BaseSort> mappedSort = this.Sortings?.Select(x => x as BaseSort).Reverse();
                if (mappedSort != null)
                {
                    foreach (var sort in mappedSort)
                    {
                        this.MatchedMembers = sort.ApplySorting(this.MatchedMembers);
                    }
                }
            }
        }

        #endregion

        #endregion
    }
}
