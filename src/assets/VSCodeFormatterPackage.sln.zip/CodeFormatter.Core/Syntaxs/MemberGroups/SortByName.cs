namespace CodeFormatter.Core.Syntaxs.MemberGroups
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using CodeFormatter.Common;

    /// <summary>
    /// Defines the <see cref = "SortByName"/>
    /// </summary>
    public class SortByName : BaseSort
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "SortByName"/> class.
        /// </summary>
        public SortByName()
        {
            this.Name = Constants.Name;
        }

        public override List<ClassMemberType> ApplySorting(List<ClassMemberType> matchedMembers)
        {
            matchedMembers = matchedMembers?.OrderBy(x => x.ParameterText).ToList();
            matchedMembers = matchedMembers?.OrderBy(x => x.Identifier).ToList();

            return matchedMembers;
        }

        #endregion
    }
}
