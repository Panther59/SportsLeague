﻿// <copyright file="BaseMemberGroup.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>18-08-2017</date>

namespace CodeFormatter.Core.Syntaxs.MemberGroups
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.CodeAnalysis;
    using Microsoft.CodeAnalysis.CSharp;
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    /// <summary>
    /// Defines the <see cref = "BaseMemberGroup"/>
    /// </summary>
    public abstract class BaseMemberGroup : IMemberGroup
    {
        #region Fields

        /// <summary>
        /// Defines the regionSeparationLinesCount
        /// </summary>
        private int regionSeparationLinesCount = 1;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the GUID
        /// </summary>
        public string GUID { get; set; }

        /// <summary>
        /// Gets or sets the MatchedMembers
        /// </summary>
        public List<ClassMemberType> MatchedMembers { get; set; }

        /// <summary>
        /// Gets or sets Name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets Region
        /// </summary>
        public string Region { get; set; }

        /// <summary>
        /// Gets or sets the RegionSeparationLinesCount
        /// </summary>
        public int RegionSeparationLinesCount
        {
            get { return regionSeparationLinesCount; }
            set { regionSeparationLinesCount = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether SurroundWithRegion
        /// </summary>
        public bool SurroundWithRegion { get; set; }

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// The GetMembers
        /// </summary>
        /// <returns>The <see cref = "List{ClassMemberType}"/></returns>
        public List<ClassMemberType> GetMembers()
        {
            return this.InternalGetMembers();
        }

        #endregion

        /// <summary>
        /// The AddEndRegionCode
        /// </summary>
        /// <param name = "node">The <see cref = "T"/></param>
        /// <returns>The <see cref = "SyntaxNode"/></returns>
        protected virtual SyntaxNode AddEndRegionCode(MemberDeclarationSyntax node, int level)
        {
            var trailingTrivia = node.GetTrailingTrivia().ToFullString().TrimEnd();
            trailingTrivia = trailingTrivia + this.GetSeparationLineText(this.RegionSeparationLinesCount) + Environment.NewLine + AppGlobal.GetIndendation(level) + "#endregion" + Environment.NewLine + Environment.NewLine;
            node = node.WithoutTrailingTrivia().WithTrailingTrivia(SyntaxFactory.Whitespace(trailingTrivia));
            return node;
        }

        /// <summary>
        /// The AddStartRegionCode
        /// </summary>
        /// <param name = "node">The <see cref = "T"/></param>
        /// <returns>The <see cref = "MemberDeclarationSyntax"/></returns>
        protected virtual SyntaxNode AddStartRegionCode(MemberDeclarationSyntax node, int level)
        {
            var leadingTrivia = node.GetLeadingTrivia().ToFullString();
            leadingTrivia = AppGlobal.GetIndendation(level) + "#region " + this.Region + Environment.NewLine + this.GetSeparationLineText(this.RegionSeparationLinesCount) + leadingTrivia;
            node = node.WithoutLeadingTrivia().WithLeadingTrivia(SyntaxFactory.Whitespace(leadingTrivia));
            return node;
        }

        /// <summary>
        /// The ApplyRegions
        /// </summary>
        protected virtual void ApplyRegions()
        {
            if (this.SurroundWithRegion && this.MatchedMembers != null && this.MatchedMembers.Count > 0 && string.IsNullOrEmpty(this.Region) == false)
            {
                var firstMember = this.MatchedMembers.FirstOrDefault();
                firstMember.Member = this.AddStartRegionCode(firstMember.Member, firstMember.Level) as MemberDeclarationSyntax;
                var lastMember = this.MatchedMembers.LastOrDefault();
                lastMember.Member = this.AddEndRegionCode(lastMember.Member, lastMember.Level) as MemberDeclarationSyntax;
            }
        }

        /// <summary>
        /// The InternalGetMembers
        /// </summary>
        /// <returns>The <see cref="List{ClassMemberType}"/></returns>
        protected abstract List<ClassMemberType> InternalGetMembers();

        /// <summary>
        /// The GetSeparationLineText
        /// </summary>
        /// <param name="numberOfSeparationLines">The <see cref="int"/></param>
        /// <returns>The <see cref="string"/></returns>
        protected string GetSeparationLineText(int numberOfSeparationLines)
        {
            string output = string.Empty;
            for (int i = 0; i < numberOfSeparationLines; i++)
            {
                output += Environment.NewLine;
            }

            return output;
        }

        #endregion
    }
}
