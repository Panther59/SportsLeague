﻿// <copyright file="TypeLayout.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>02-08-2017</date>

namespace CodeFormatter.Core.Syntaxs.MemberGroups
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using CodeFormatter.Core.Binders;
    using Newtonsoft.Json;

    /// <summary>
    /// Defines the <see cref = "TypeLayout"/>
    /// </summary>
    public class TypeLayout
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "TypeLayout"/> class.
        /// </summary>
        public TypeLayout()
        {
            var layout = this.LoadLayout();
            this.MemberGroups = layout?.MemberGroups;
            this.AddNamespaceMemberGroup();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the MemberGroups
        /// </summary>
        public List<IMemberGroup> MemberGroups
        {
            get;
            private set;
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// The ApplyLayout
        /// </summary>
        /// <param name = "finalList">The <see cref = "List{ClassMemberType}"/></param>
        /// <returns>The <see cref = "List{ClassMemberType}"/></returns>
        public List<ClassMemberType> ApplyLayout(List<ClassMemberType> input)
        {
            var members = this.MemberGroups?.OrderByDescending(x => x is MemberLayout ? ((MemberLayout)x).Priority : ((MemberGroupCollection)x).Priority);
            if (members != null)
            {
                foreach (var memberGroup in members)
                {
                    MemberLayout memberLayout = memberGroup as MemberLayout;
                    if (memberLayout != null)
                    {
                        //// Match the mathching members and return the remaining members so that it can be tried in the other member group
                        input = memberLayout.MatchMembers(input);
                    }
                    else
                    {
                        MemberGroupCollection collection = memberGroup as MemberGroupCollection;
                        //// Match the mathching members and return the remaining members so that it can be tried in the other member group
                        input = collection.MatchMembers(input);
                    }
                }
            }

            List<ClassMemberType> newlist = new List<ClassMemberType>();
            if (this.MemberGroups != null)
            {
                foreach (var memberGroup in this.MemberGroups)
                {
                    MemberLayout memberLayout = memberGroup as MemberLayout;
                    if (memberLayout != null)
                    {
                        List<ClassMemberType> subList = memberLayout.GetMembers();
                        if (subList != null && subList.Count > 0)
                        {
                            newlist.AddRange(subList);
                        }
                    }
                    else
                    {
                        MemberGroupCollection collection = memberGroup as MemberGroupCollection;
                        List<ClassMemberType> subList = collection.GetMembers();
                        if (subList != null && subList.Count > 0)
                        {
                            newlist.AddRange(subList);
                        }
                    }
                }
            }

            //// add any additional tags which are not configured in the layout
            newlist.AddRange(input);
            return newlist;
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// The AddNamespaceMemberGroup
        /// </summary>
        private void AddNamespaceMemberGroup()
        {
            if (this.MemberGroups == null)
            {
                this.MemberGroups = new List<IMemberGroup>();
            }

            this.MemberGroups.Insert(0, new MemberLayout()
            {
                Conditions = new List<ICondition>()
                {
                    new FindByKind()
                    {
                        Kind = Common.Entities.MemberKinds.Namespaces
                    }
                },
                Sortings = new List<ISort>()
                {
                    new SortByName()
                },
                SurroundWithRegion = false
            });
        }

        ///// <summary>
        ///// The GetTypeLayout
        ///// </summary>
        ///// <returns>The <see cref="IMemberGroup"/></returns>
        //public static IMemberGroup GetTypeLayout()
        //{
        //    try
        //    {
        //        var file = GetSavedLayoutFilePath();
        //        FileInfo info = new FileInfo(file);
        //        if (info.Exists)
        //        {
        //            string json = File.ReadAllText(file);
        //            return GetTypeLayout(json);
        //        }
        //        else
        //        {
        //            var defaultFilePath = GetDefaultLayoutFolderPath() + "\\DefaultWithRegion.txt";
        //            FileInfo defInfo = new FileInfo(defaultFilePath);
        //            if (defInfo.Exists)
        //            {
        //                string json = File.ReadAllText(file);
        //                SaveTypeLayout(json);
        //                return GetTypeLayout();
        //            }
        //            else
        //            {
        //                return null;
        //            }
        //        }
        //    }
        //    catch (Exception)
        //    {
        //        return null;
        //    }
        //}
        //public static IMemberGroup GetTypeLayout(string json)
        //{
        //    var binder = new TypeNameSerializationBinder("CodeFormatter.Core.ViewModels.MemberGroups.{0}, CodeFormatter.Core");
        //    var obj = JsonConvert.DeserializeObject<AndMemberGroupCollectionViewModel>(json, new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.Auto, NullValueHandling = NullValueHandling.Ignore, SerializationBinder = binder });
        //    return obj;
        //}
        ///// <summary>
        ///// The SaveTypeLayout
        ///// </summary>
        ///// <param name="input">The <see cref="object"/></param>
        //public static void SaveTypeLayout(object input)
        //{
        //    var binder = new TypeNameSerializationBinder("CodeFormatter.Core.ViewModels.MemberGroups.{0}, CodeFormatter.Core");
        //    string json = JsonConvert.SerializeObject(input, Formatting.Indented, new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.Auto, NullValueHandling = NullValueHandling.Ignore, SerializationBinder = binder });
        //    SaveTypeLayout(json);
        //}
        ///// <summary>
        ///// The SaveTypeLayout
        ///// </summary>
        ///// <param name="content">The <see cref="string"/></param>
        //public static void SaveTypeLayout(string content)
        //{
        //    var file = GetSavedLayoutFilePath();
        //    FileInfo info = new FileInfo(file);
        //    if (info.Directory.Exists == false)
        //    {
        //        Directory.CreateDirectory(info.Directory.FullName);
        //    }
        //    File.WriteAllText(file, content);
        //}
        ///// <summary>
        ///// The GetDefaultLayoutFolderPath
        ///// </summary>
        ///// <returns>The <see cref="string"/></returns>
        //public static string GetDefaultLayoutFolderPath()
        //{
        //    var dllPath = Assembly.GetExecutingAssembly().Location;
        //    var folderPath = Path.GetDirectoryName(dllPath);
        //    var folder = folderPath + "\\Layouts\\";
        //    return folder;
        //}
        ///// <summary>
        ///// The GetSavedLayoutFilePath
        ///// </summary>
        ///// <returns>The <see cref="string"/></returns>
        //public static string GetSavedLayoutFilePath()
        //{
        //    var file = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\Ayvan\\Code Formatter\\Type Layout.txt";
        //    return file;
        //}
        /// <summary>
        /// The LoadLayout
        /// </summary>
        /// <returns>The <see cref = "AndMemberGroupCollection"/></returns>
        private AndMemberGroupCollection LoadLayout()
        {
            try
            {
                var binder = new TypeNameSerializationBinder("CodeFormatter.Core.Syntaxs.MemberGroups.{0}, CodeFormatter.Core");
                var file = AppGlobal.TypeLayoutFile;
                FileInfo info = new FileInfo(file);
                if (info.Exists)
                {
                    string json = File.ReadAllText(file);
                    json = json.Replace("ViewModel\"", "\"");
                    var obj = JsonConvert.DeserializeObject<AndMemberGroupCollection>(json, new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.Auto, NullValueHandling = NullValueHandling.Ignore, SerializationBinder = binder });
                    return obj;
                }
                else
                {
                    var defaultFilePath = AppGlobal.GetDefaultLayoutFolderPath() + "\\DefaultWithRegion.txt";
                    FileInfo defInfo = new FileInfo(defaultFilePath);
                    if (defInfo.Exists)
                    {
                        string json = File.ReadAllText(file);
                        AppGlobal.SaveTypeLayout(json);
                        return LoadLayout();
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        #endregion

        #endregion
    }
}