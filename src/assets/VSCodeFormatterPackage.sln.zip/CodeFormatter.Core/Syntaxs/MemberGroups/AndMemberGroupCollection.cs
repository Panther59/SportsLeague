namespace CodeFormatter.Core.Syntaxs.MemberGroups
{
    using CodeFormatter.Common;

    /// <summary>
    /// Defines the <see cref = "AndMemberGroupCollection"/>
    /// </summary>
    public class AndMemberGroupCollection : MemberGroupCollection, IMemberGroup
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "AndMemberGroupCollection"/> class.
        /// </summary>
        public AndMemberGroupCollection()
        {
            this.Name = Constants.And;
        }

        #endregion
    }
}
