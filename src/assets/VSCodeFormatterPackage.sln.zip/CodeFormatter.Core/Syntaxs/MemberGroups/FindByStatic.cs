namespace CodeFormatter.Core.Syntaxs.MemberGroups
{
    using System;
    using CodeFormatter.Common;

    /// <summary>
    /// Defines the <see cref = "FindByStatic"/>
    /// </summary>
    public class FindByStatic : BaseCondition
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "FindByStatic"/> class.
        /// </summary>
        public FindByStatic()
        {
            this.Name = Constants.IsStatic;
            this.Priority = 2;
        }

        /// <inheritdoc />
        public override bool IsMatch(ClassMemberType member)
        {
            return member.ModifierDesc.Contains("static");
        }

        #endregion
    }
}
