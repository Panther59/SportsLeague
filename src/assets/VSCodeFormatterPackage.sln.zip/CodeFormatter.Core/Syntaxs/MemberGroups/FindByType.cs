namespace CodeFormatter.Core.Syntaxs.MemberGroups
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using CodeFormatter.Common;

    /// <summary>
    /// Defines the <see cref = "FindByType"/>
    /// </summary>
    public class FindByType : BaseCondition
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "FindByType"/> class.
        /// </summary>
        public FindByType()
        {
            this.Name = Constants.Type;
            this.Priority = 3;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        public string Type
        {
            get;
            set;
        }

        #endregion

        #region Methods

        /// <inheritdoc/>
        public override bool IsMatch(ClassMemberType member)
        {
            if (member.TypeText == null)
            {
                return false;
            }

            var types = this.GetTypes();
            var typeFound = types?.Any(t => member.TypeText.Equals(t, StringComparison.CurrentCultureIgnoreCase) || member.TypeText.StartsWith(t + "<", StringComparison.CurrentCultureIgnoreCase));
            return typeFound ?? false;
        }

        /// <summary>
        /// The GetTypes
        /// </summary>
        /// <returns>The <see cref = "List{string}"/></returns>
        public List<string> GetTypes()
        {
            if (this.Type == null)
            {
                return null;
            }

            return this.Type.Split(',').Where(x => x != null && string.IsNullOrEmpty(x.Trim()) == false).Select(y => y.Trim()).ToList();
        }


        #endregion
    }
}
