namespace CodeFormatter.Core.Syntaxs.MemberGroups
{
    using System.Collections.Generic;

    public interface IMemberLayout : IMemberGroup
    {
        #region Properties

        /// <summary>
        /// Gets or sets Region
        /// </summary>
        string Region
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets Conditions
        /// </summary>
        List<ICondition> Conditions
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets Sortings
        /// </summary>
        List<ISort> Sortings
        {
            get;
            set;
        }

        #endregion
    }
}
