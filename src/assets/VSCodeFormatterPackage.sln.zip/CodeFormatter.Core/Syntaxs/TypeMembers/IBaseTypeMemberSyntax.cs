﻿// <copyright file="IBaseSyntax.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>31-07-2017</date>

namespace CodeFormatter.Core.Syntaxs.TypeMembers
{
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    /// <summary>
    /// Defines the <see cref = IBaseTypeMemberSyntax / >
    /// </summary>
    public interface IBaseTypeMemberSyntax
    {
        #region Methods

        /// <summary>
        /// The FixNode
        /// </summary>
        /// <param name = "input">The <see cref = "MemberDeclarationSyntax"/></param>
        /// <returns>The <see cref = "MemberDeclarationSyntax"/></returns>
        MemberDeclarationSyntax FixNode(MemberDeclarationSyntax input);

        #endregion
    }
}