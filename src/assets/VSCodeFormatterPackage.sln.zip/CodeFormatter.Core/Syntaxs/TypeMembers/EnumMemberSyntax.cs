﻿// <copyright file="EnumMemberSyntax.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>31-07-2017</date>

namespace CodeFormatter.Core.Syntaxs.TypeMembers
{
    using System;
    using CodeFormatter.Common.Contracts;
    using Microsoft.CodeAnalysis;
    using Microsoft.CodeAnalysis.CSharp;
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    /// <summary>
    /// Defines the <see cref = "EnumMemberSyntax"/>
    /// </summary>
    public class EnumMemberSyntax : BaseClassMemberSyntax<EnumMemberDeclarationSyntax>
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "EnumMemberSyntax"/> class.
        /// </summary>
        /// <param name = "setting">The setting file</param>
        public EnumMemberSyntax(IDefaultSettings setting) : base(setting)
        {
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <inheritdoc/>
        public override bool CanSyntaxHeaderBeModified(EnumMemberDeclarationSyntax syntax)
        {
            return this.Setting.AddEnumHeader;
        }

        /// <inheritdoc/>
        public override SyntaxTrivia GetNewLeadingTrivia(EnumMemberDeclarationSyntax syntax)
        {
            var fieldComment = @"{1}/// <summary>
{1}/// Defines the {0}
{1}/// </summary>
        ";
            var finalComment = string.Format(fieldComment, syntax.Identifier.ToString(), AppGlobal.GetIndendation(this.Level));
            return SyntaxFactory.Whitespace(Environment.NewLine + finalComment);
        }

        /// <inheritdoc/>
        public override SyntaxTrivia GetTrailingTrivia(EnumMemberDeclarationSyntax syntax)
        {
            return SyntaxFactory.Whitespace(syntax.GetTrailingTrivia().ToFullString().Trim());
        }

        #endregion

        #endregion
    }
}