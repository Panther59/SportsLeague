﻿// <copyright file="PropertySyntax.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>02-08-2017</date>

namespace CodeFormatter.Core.Syntaxs.TypeMembers
{
    using System;
    using System.Linq;
    using System.Text.RegularExpressions;
    using CodeFormatter.Common;
    using CodeFormatter.Common.Contracts;
    using Microsoft.CodeAnalysis;
    using Microsoft.CodeAnalysis.CSharp;
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    /// <summary>
    /// Defines the <see cref = "PropertySyntax"/>
    /// </summary>
    public class PropertySyntax : BaseClassMemberSyntax<PropertyDeclarationSyntax>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref = "PropertySyntax"/> class.
        /// </summary>
        /// <param name = "setting">The setting file</param>
        public PropertySyntax(IDefaultSettings setting) : base(setting)
        {
        }

        #region Methods

        #region Public Methods

        /// <inheritdoc/>
        public override bool CanSyntaxHeaderBeModified(PropertyDeclarationSyntax syntax)
        {
            return this.Setting.AddPropertyHeader;
        }

        /// <inheritdoc/>
        public override SyntaxTrivia GetNewLeadingTrivia(PropertyDeclarationSyntax syntax)
        {
            string existingComment = syntax.GetLeadingTrivia().ToString();
            bool isBoolType = syntax.Type.ToFullString().Trim() == "bool";
            bool hasGet = syntax.AccessorList != null
                ? syntax.AccessorList.Accessors.ToList()
                .Any(y => y.Kind() == SyntaxKind.GetAccessorDeclaration && (y.Modifiers == null || y.Modifiers.Any(m => m.Kind() == SyntaxKind.PrivateKeyword) == false))
                : false;
            bool hasSet = syntax.AccessorList != null
                ? syntax.AccessorList.Accessors.ToList()
                .Any(y => y.Kind() == SyntaxKind.SetAccessorDeclaration && (y.Modifiers == null || y.Modifiers.Any(m => m.Kind() == SyntaxKind.PrivateKeyword) == false))
                : false;
            var decStr = "Gets"; //// Default it Gets since, now there is a new way of gets implementation where Gets word is not used
            if (hasGet & hasSet)
            {
                decStr = "Gets or sets";
            }
            else if (hasGet & !hasSet)
            {
                decStr = "Gets";
            }
            else if (!hasGet & hasSet)
            {
                decStr = "Sets";
            }

            var comment = syntax?.GetLeadingTrivia().ToFullString()?.Trim();
            if (isBoolType)
            {
                var propBoolCommentRegex = string.Format(Constants.PropertyCommentRegex, decStr + " a value indicating whether");
                var propBoolDefaultCommentRegex = string.Format(Constants.PropertyDefaultCommentRegex, decStr + " a value indicating whether");

                var oldFormattedSummary = string.Empty;
                var oldSummary = string.Empty;
                var matchPropDefault = Regex.Match(comment, propBoolDefaultCommentRegex, RegexOptions.Multiline);
                var matchProp = Regex.Match(comment, propBoolCommentRegex, RegexOptions.Multiline);
                if (matchProp.Success && matchProp.Length > 0 && matchProp.Groups.Count > 1 && string.IsNullOrWhiteSpace(matchProp.Groups[1].Value) == false)
                {
                    oldFormattedSummary = matchProp.Groups[1].Value?.Trim();
                }

                var matchPropSummary = Regex.Match(comment, Constants.SummaryCommentRegex, RegexOptions.Multiline);
                if (matchPropSummary.Success && matchPropSummary.Length > 0 && matchPropSummary.Groups.Count > 1 && string.IsNullOrWhiteSpace(matchPropSummary.Groups[1].Value) == false)
                {
                    oldSummary = matchPropSummary.Groups[1].Value?.Trim();
                }

                var propNewBoolComment = @"{2}/// <summary>
{2}/// {0} a value indicating whether {1}{3}
{2}/// </summary>
{2}";
                if (matchPropDefault.Success || string.IsNullOrWhiteSpace(oldFormattedSummary))
                {

                    var finalComment = string.Format(propNewBoolComment, decStr, syntax.Identifier.ValueText, AppGlobal.GetIndendation(this.Level), string.IsNullOrWhiteSpace(oldSummary) == false && matchPropDefault.Success == false ? string.Format(@"{0}{1}/// {2}", Environment.NewLine, AppGlobal.GetIndendation(this.Level), oldSummary) : string.Empty);
                    return SyntaxFactory.Whitespace(finalComment);
                }
                else
                {
                    var finalComment = string.Format(propNewBoolComment, decStr, oldFormattedSummary.Trim(), AppGlobal.GetIndendation(this.Level), string.Empty);
                    return SyntaxFactory.Whitespace(finalComment);
                }
            }
            else
            {
                var propCommentRegex = string.Format(Constants.PropertyCommentRegex, decStr + " the");
                var propDefaultCommentRegex = string.Format(Constants.PropertyDefaultCommentRegex, decStr + " the");

                var oldFormattedSummary = string.Empty;
                var oldSummary = string.Empty;
                var matchPropDefault = Regex.Match(comment, propDefaultCommentRegex, RegexOptions.Multiline);
                var matchProp = Regex.Match(comment, propCommentRegex, RegexOptions.Multiline);
                if (matchProp.Success && matchProp.Length > 0 && matchProp.Groups.Count > 1 && string.IsNullOrWhiteSpace(matchProp.Groups[1].Value) == false)
                {
                    oldFormattedSummary = matchProp.Groups[1].Value?.Trim();
                }

                var matchPropSummary = Regex.Match(comment, Constants.SummaryCommentRegex, RegexOptions.Multiline);
                if (matchPropSummary.Success && matchPropSummary.Length > 0 && matchPropSummary.Groups.Count > 1 && string.IsNullOrWhiteSpace(matchPropSummary.Groups[1].Value) == false)
                {
                    oldSummary = matchPropSummary.Groups[1].Value?.Trim();
                }

                var propComment = @"{2}/// <summary>
{2}/// {0} the {1}{3}
{2}/// </summary>
{2}";
                if (matchPropDefault.Success || string.IsNullOrWhiteSpace(oldFormattedSummary))
                {
                    var finalComment = string.Format(propComment, decStr, syntax.Identifier.ValueText, AppGlobal.GetIndendation(this.Level), string.IsNullOrWhiteSpace(oldSummary) == false && matchPropDefault.Success == false ? string.Format(@"{0}{1}/// {2}", Environment.NewLine, AppGlobal.GetIndendation(this.Level), oldSummary) : string.Empty);
                    return SyntaxFactory.Whitespace(finalComment);
                }
                else
                {
                    var finalComment = string.Format(propComment, decStr, oldFormattedSummary, AppGlobal.GetIndendation(this.Level), string.Empty);
                    return SyntaxFactory.Whitespace(finalComment);
                }
            }

        }

        /// <inheritdoc/>
        public override SyntaxTrivia GetTrailingTrivia(PropertyDeclarationSyntax syntax)
        {
            return SyntaxFactory.Whitespace(syntax.GetTrailingTrivia().ToFullString().Trim() + Environment.NewLine + Environment.NewLine);
        }

        #endregion

        /// <inheritdoc/>
        protected override PropertyDeclarationSyntax ChangeNodeSyntax(PropertyDeclarationSyntax input)
        {
            var node = base.ChangeNodeSyntax(input);
            node = node.ReplaceToken(node.Identifier, node.Identifier.WithLeadingTrivia(SyntaxFactory.ParseLeadingTrivia("")).WithTrailingTrivia(SyntaxFactory.ParseTrailingTrivia("")));
            if (node.AccessorList != null && node.AccessorList.OpenBraceToken != null && node.AccessorList.CloseBraceToken != null)
            {
                var accessor = node.AccessorList;
                var getter = accessor != null && accessor.Accessors != null ? accessor.Accessors.FirstOrDefault(x => x.Kind() == SyntaxKind.GetAccessorDeclaration) : null;
                var setter = accessor != null && accessor.Accessors != null ? accessor.Accessors.FirstOrDefault(x => x.Kind() == SyntaxKind.SetAccessorDeclaration) : null;

                //// Multiline property code
                if ((getter != null && getter.Body != null) || (setter != null && setter.Body != null))
                {
                    accessor = accessor.ReplaceToken(accessor.OpenBraceToken, accessor.OpenBraceToken.WithLeadingTrivia(SyntaxFactory.ParseLeadingTrivia(Environment.NewLine + AppGlobal.GetIndendation(this.Level))).WithTrailingTrivia(SyntaxFactory.ParseLeadingTrivia(Environment.NewLine)));
                    accessor = accessor.ReplaceToken(accessor.CloseBraceToken, accessor.CloseBraceToken.WithLeadingTrivia(SyntaxFactory.ParseLeadingTrivia(AppGlobal.GetIndendation(this.Level))).WithTrailingTrivia(SyntaxFactory.ParseLeadingTrivia(Environment.NewLine + Environment.NewLine)));
                    node = node.WithAccessorList(accessor);
                }
                else
                {
                    //// Single line property code
                    if (getter != null)
                    {
                        getter = getter.ReplaceToken(getter.Keyword, getter.Keyword.WithLeadingTrivia(SyntaxFactory.ParseLeadingTrivia("")).WithTrailingTrivia(SyntaxFactory.ParseTrailingTrivia("")));
                        getter = getter.ReplaceToken(getter.SemicolonToken, getter.SemicolonToken.WithLeadingTrivia(SyntaxFactory.ParseLeadingTrivia("")).WithTrailingTrivia(SyntaxFactory.ParseTrailingTrivia(" ")));

                        accessor = accessor.ReplaceNode(accessor.Accessors.FirstOrDefault(x => x.Kind() == SyntaxKind.GetAccessorDeclaration), getter.WithLeadingTrivia(SyntaxFactory.ParseLeadingTrivia(" ")).WithTrailingTrivia(SyntaxFactory.ParseTrailingTrivia("")));
                    }

                    if (setter != null)
                    {
                        setter = setter.ReplaceToken(setter.Keyword, setter.Keyword.WithLeadingTrivia(SyntaxFactory.ParseLeadingTrivia("")).WithTrailingTrivia(SyntaxFactory.ParseTrailingTrivia("")));
                        setter = setter.ReplaceToken(setter.SemicolonToken, setter.SemicolonToken.WithLeadingTrivia(SyntaxFactory.ParseLeadingTrivia("")).WithTrailingTrivia(SyntaxFactory.ParseTrailingTrivia(" ")));
                        accessor = accessor.ReplaceNode(accessor.Accessors.FirstOrDefault(x => x.Kind() == SyntaxKind.SetAccessorDeclaration), setter.WithLeadingTrivia(SyntaxFactory.ParseLeadingTrivia(" ")).WithTrailingTrivia(SyntaxFactory.ParseTrailingTrivia("")));
                    }

                    accessor = accessor.ReplaceToken(accessor.OpenBraceToken, accessor.OpenBraceToken.WithLeadingTrivia(SyntaxFactory.ParseLeadingTrivia(" ")).WithTrailingTrivia(SyntaxFactory.ParseTrailingTrivia("")));
                    if (input.Initializer == null)
                    {
                        accessor = accessor.ReplaceToken(accessor.CloseBraceToken, accessor.CloseBraceToken.WithLeadingTrivia(SyntaxFactory.ParseLeadingTrivia(" ")).WithTrailingTrivia(SyntaxFactory.ParseLeadingTrivia(Environment.NewLine + Environment.NewLine)));
                    }
                    else
                    {
                        accessor = accessor.ReplaceToken(accessor.CloseBraceToken, accessor.CloseBraceToken.WithLeadingTrivia(SyntaxFactory.ParseLeadingTrivia(" ")).WithTrailingTrivia(SyntaxFactory.ParseLeadingTrivia(" ")));
                        node.WithInitializer(node.Initializer.WithTrailingTrivia(SyntaxFactory.ParseLeadingTrivia((Environment.NewLine + Environment.NewLine))));
                    }

                    node = node.WithAccessorList(accessor);
                }
            }

            return node;
        }

        /// <inheritdoc />
        protected override bool IsCommentMathchesSignature(PropertyDeclarationSyntax input, string comment)
        {
            return false;
        }

        #endregion
    }
}