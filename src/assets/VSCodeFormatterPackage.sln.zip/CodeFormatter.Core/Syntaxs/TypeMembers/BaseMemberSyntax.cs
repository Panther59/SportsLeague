﻿namespace CodeFormatter.Core.Syntaxs.TypeMembers
{
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    /// <summary>
    /// Defines the <see cref = "BaseMemberSyntax"/>
    /// </summary>
    public class BaseMemberSyntax
    {
        #region Methods

        /// <summary>
        /// The GetTypeNameForComment
        /// </summary>
        /// <param name = "syntax">The <see cref = "TypeDeclarationSyntax"/></param>
        /// <returns>The <see cref = "string "/></returns>
        public string GetTypeNameForComment(TypeDeclarationSyntax syntax)
        {
            return syntax.Identifier.ValueText + (syntax.TypeParameterList != null ? syntax.TypeParameterList.ToString().Replace("<", "{").Replace(">", "}") : string.Empty);
        }

        #endregion
    }
}
