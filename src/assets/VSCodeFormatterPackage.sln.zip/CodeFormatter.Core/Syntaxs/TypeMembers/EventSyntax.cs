﻿// <copyright file="EventSyntax.cs" company="Avanade">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>30-05-2018</date>

namespace CodeFormatter.Core.Syntaxs.TypeMembers
{
    using System;
    using System.Linq;
    using System.Text.RegularExpressions;
    using CodeFormatter.Common;
    using CodeFormatter.Common.Contracts;
    using Microsoft.CodeAnalysis;
    using Microsoft.CodeAnalysis.CSharp;
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    /// <summary>
    /// Defines the <see cref = "EventSyntax"/>
    /// </summary>
    public class EventSyntax : BaseClassMemberSyntax<EventFieldDeclarationSyntax>
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="EventSyntax"/> class.
        /// </summary>
        /// <param name="setting">The setting<see cref="IDefaultSettings"/></param>
        public EventSyntax(IDefaultSettings setting) : base(setting)
        {
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <inheritdoc/>
        public override bool CanSyntaxHeaderBeModified(EventFieldDeclarationSyntax syntax)
        {
            return this.Setting.AddEventHeader;
        }

        /// <inheritdoc/>
        public override SyntaxTrivia GetNewLeadingTrivia(EventFieldDeclarationSyntax syntax)
        {
            bool existingComment = string.IsNullOrEmpty(syntax.GetLeadingTrivia().ToString().Trim()) == false;
            bool summaryTagPresent = existingComment ? syntax.GetLeadingTrivia().ToString().Contains("summary") : false;
            string finalComment = string.Empty;
            var comment = syntax?.GetLeadingTrivia().ToFullString()?.Trim();
            var matchField = Regex.Match(comment, Constants.FieldCommentRegex, RegexOptions.Multiline);
            var matchSummary = Regex.Match(comment, Constants.SummaryCommentRegex, RegexOptions.Multiline);
            string oldSummary = string.Empty;
            if (matchSummary.Success && matchSummary.Length > 0 && matchSummary.Groups.Count > 1 && string.IsNullOrWhiteSpace(matchSummary.Groups[1].Value) == false)
            {
                oldSummary = matchSummary.Groups[1].Value?.Trim();
            }

            if (matchField.Success || string.IsNullOrEmpty(oldSummary))
            {
                var fieldComment = @"{1}{2}/// <summary>
{2}/// Defines the {0}
{2}/// </summary>
{2}";
                var varNames = string.Empty;
                syntax.Declaration?.Variables.Select(x => x.Identifier.Text.Trim()).ToList().ForEach((y) =>
                {
                    if (string.IsNullOrEmpty(varNames))
                    {
                        varNames += y;
                    }
                    else
                    {
                        varNames += (", " + y);
                    }
                });

                finalComment = string.Format(fieldComment, varNames, string.Empty, AppGlobal.GetIndendation(this.Level));
            }
            else
            {
                var fieldComment = @"{1}{2}/// <summary>
{2}/// {0}
{2}/// </summary>
{2}";

                finalComment = string.Format(fieldComment, oldSummary.Trim(), string.Empty, AppGlobal.GetIndendation(this.Level));
            }

            return SyntaxFactory.Whitespace(finalComment);
        }

        /// <inheritdoc/>
        public override SyntaxTrivia GetTrailingTrivia(EventFieldDeclarationSyntax syntax)
        {
            return SyntaxFactory.Whitespace(syntax.GetTrailingTrivia().ToFullString().Trim() + Environment.NewLine + Environment.NewLine);
        }

        /// <inheritdoc/>
        protected override bool IsCommentMathchesSignature(EventFieldDeclarationSyntax input, string comment)
        {
            return false;
        }

        #endregion

        #endregion
    }
}
