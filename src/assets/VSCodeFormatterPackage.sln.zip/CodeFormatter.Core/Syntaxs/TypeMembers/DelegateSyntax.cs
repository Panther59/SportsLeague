﻿namespace CodeFormatter.Core.Syntaxs.TypeMembers
{
    using System;
    using System.Linq;
    using System.Text;
    using System.Text.RegularExpressions;
    using CodeFormatter.Common;
    using CodeFormatter.Common.Contracts;
    using Microsoft.CodeAnalysis;
    using Microsoft.CodeAnalysis.CSharp;
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    /// <summary>
    /// Defines the <see cref = "DelegateSyntax"/>
    /// </summary>
    public class DelegateSyntax : BaseClassMemberSyntax<DelegateDeclarationSyntax>
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "DelegateSyntax"/> class.
        /// </summary>
        /// <param name = "setting">The setting file</param>
        public DelegateSyntax(IDefaultSettings setting) : base(setting)
        {
        }

        #endregion

        #region Methods

        /// <inheritdoc/>
        public override bool CanSyntaxHeaderBeModified(DelegateDeclarationSyntax syntax)
        {
            return this.Setting.AddDelegateHeader;
        }

        /// <inheritdoc/>
        public override SyntaxTrivia GetNewLeadingTrivia(DelegateDeclarationSyntax syntax)
        {
            var comment = syntax?.GetLeadingTrivia().ToFullString()?.Trim();
            var methodSummary = string.Empty;
            var indendation = AppGlobal.GetIndendation(this.Level);
            var methodCommentFormat = @"{2}/// <summary>
{2}/// {0}
{2}/// </summary>
{3}{1}{2}";

            var matchMethod = Regex.Match(comment, Constants.SummaryCommentRegex, RegexOptions.Multiline);
            if (matchMethod.Success && matchMethod.Length > 0 && matchMethod.Groups.Count > 1 && string.IsNullOrWhiteSpace(matchMethod.Groups[1].Value) == false)
            {
                methodSummary = matchMethod.Groups[1].Value?.Trim();
            }
            else
            {
                methodSummary = "The " + syntax.Identifier.ValueText;
            }

            StringBuilder sb = new StringBuilder();
            //var typeParamFormat = @"{1}/// <typeparam name=""{0}""></typeparam>";
            StringBuilder typeSB = new StringBuilder();
            if (syntax.TypeParameterList != null)
            {
                foreach (var param in syntax.TypeParameterList.Parameters)
                {
                    string typeParamRegex = @"\/\/\/.\<typeparam name\=""" + param.Identifier.Text.Replace("<", "{").Replace(">", "}") + @"""\>(.*)\<\/typeparam\>";
                    var match = Regex.Match(comment, typeParamRegex);
                    if (match.Success && match.Length > 0 && match.Groups.Count > 1)
                    {
                        var typeParamFormat = @"{1}/// <typeparam name=""{0}"">{2}</typeparam>";
                        typeSB.AppendLine(string.Format(typeParamFormat, param.Identifier.Text.Replace("<", "{").Replace(">", "}"), AppGlobal.GetIndendation(this.Level), match.Groups[1].Value));
                    }
                    else
                    {
                        var typeParamFormat = @"{1}/// <typeparam name=""{0}""></typeparam>";
                        typeSB.AppendLine(string.Format(typeParamFormat, param.Identifier.Text.Replace("<", "{").Replace(">", "}"), AppGlobal.GetIndendation(this.Level)));
                    }

                }
            }

            foreach (var param in syntax.ParameterList.Parameters)
            {
                string paramRegex = @"\/\/\/.\<param name\=""" + param.Identifier.ValueText + @"""\>(.*)\<\/param\>";
                var match = Regex.Match(comment, paramRegex);
                if (match.Success && match.Length > 0 && match.Groups.Count > 1)
                {
                    var paramFormat = @"{3}/// <param name=""{0}"">{2}</param>"; ;
                    sb.AppendLine(string.Format(paramFormat, param.Identifier.Text, param.Type.ToString().Replace("<", "{").Replace(">", "}"), match.Groups[1].Value, indendation));
                }
                else
                {
                    var paramFormat = @"{3}/// <param name=""{0}"">The {2}<see cref=""{1}""/></param>";
                    sb.AppendLine(string.Format(paramFormat, param.Identifier.Text, param.Type.ToString().Replace("<", "{").Replace(">", "}"), param.Identifier.ValueText, indendation));
                }
            }

            if (syntax.ReturnType.ToString() != "void")
            {
                string returnRegex = @"\/\/\/.\<returns\>(.*)\<\/returns\>";
                var match = Regex.Match(comment, returnRegex);
                if (match.Success && match.Length > 0 && match.Groups.Count > 1)
                {
                    var returnFormat = @"{1}/// <returns>{0}</returns>";
                    sb.AppendLine(string.Format(returnFormat, match.Groups[1].Value, indendation));
                }
                else
                {
                    var returnFormat = @"{1}/// <returns>The <see cref=""{0}""/></returns>";
                    sb.AppendLine(string.Format(returnFormat, syntax.ReturnType.ToString().Replace("<", "{").Replace(">", "}"), indendation));
                }
            }

            var finalComment = string.Format(methodCommentFormat, methodSummary, sb.ToString(), indendation, typeSB.ToString());
            return SyntaxFactory.Whitespace(finalComment);
        }

        /// <inheritdoc/>
        public override SyntaxTrivia GetTrailingTrivia(DelegateDeclarationSyntax syntax)
        {
            return SyntaxFactory.Whitespace(syntax.GetTrailingTrivia().ToFullString().Trim() + Environment.NewLine + Environment.NewLine);
        }

        #endregion
    }
}
