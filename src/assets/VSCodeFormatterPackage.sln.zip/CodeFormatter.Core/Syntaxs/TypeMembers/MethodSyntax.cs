﻿// <copyright file="MethodSyntax.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>02-08-2017</date>

namespace CodeFormatter.Core.Syntaxs.TypeMembers
{
    using System;
    using System.Linq;
    using System.Text;
    using System.Text.RegularExpressions;
    using CodeFormatter.Common;
    using CodeFormatter.Common.Contracts;
    using CodeFormatter.Core.Syntaxs.Statements;
    using Microsoft.CodeAnalysis;
    using Microsoft.CodeAnalysis.CSharp;
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    /// <summary>
    /// Defines the <see cref = "MethodSyntax"/>
    /// </summary>
    public class MethodSyntax : BaseClassMemberSyntax<MethodDeclarationSyntax>
    {
        #region Fields

        /// <summary>
        /// Defines the 
        /// </summary>
        private readonly IResolver resolver;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="MethodSyntax"/> class.
        /// </summary>
        /// <param name="resolver">The <see cref="IResolver"/></param>
        /// <param name="setting">The <see cref="IDefaultSettings"/></param>
        public MethodSyntax(IResolver resolver, IDefaultSettings setting) : base(setting)
        {
            this.resolver = resolver;
        }

        #endregion

        #region Methods

        #region Public Methods
            
        /// <inheritdoc/>
        public override bool CanSyntaxHeaderBeModified(MethodDeclarationSyntax syntax)
        {
            return this.Setting.AddMethodHeader;
        }

        /// <inheritdoc/>
        public override SyntaxTrivia GetNewLeadingTrivia(MethodDeclarationSyntax syntax)
        {
            var comment = syntax?.GetLeadingTrivia().ToFullString()?.Trim();
            var methodSummary = string.Empty;
            var indendation = AppGlobal.GetIndendation(this.Level);
            var methodCommentFormat = @"{2}/// <summary>
{2}/// {0}
{2}/// </summary>
{3}{1}{2}";

            var matchMethod = Regex.Match(comment, Constants.SummaryCommentRegex, RegexOptions.Multiline);
            if (matchMethod.Success && matchMethod.Length > 0 && matchMethod.Groups.Count > 1 && string.IsNullOrWhiteSpace(matchMethod.Groups[1].Value) == false)
            {
                methodSummary = matchMethod.Groups[1].Value?.Trim();
            }
            else
            {
                methodSummary = "The " + syntax.Identifier.ValueText;
            }

            StringBuilder sb = new StringBuilder();
            //var typeParamFormat = @"{1}/// <typeparam name=""{0}""></typeparam>";
            StringBuilder typeSB = new StringBuilder();
            if (syntax.TypeParameterList != null)
            {
                foreach (var param in syntax.TypeParameterList.Parameters)
                {
                    string typeParamRegex = @"\/\/\/.\<typeparam name\=""" + param.Identifier.Text.Replace("<", "{").Replace(">", "}") + @"""\>(.*)\<\/typeparam\>";
                    var match = Regex.Match(comment, typeParamRegex);
                    if (match.Success && match.Length > 0 && match.Groups.Count > 1)
                    {
                        var typeParamFormat = @"{1}/// <typeparam name=""{0}"">{2}</typeparam>";
                        typeSB.AppendLine(string.Format(typeParamFormat, param.Identifier.Text.Replace("<", "{").Replace(">", "}"), AppGlobal.GetIndendation(this.Level), match.Groups[1].Value));
                    }
                    else
                    {
                        var typeParamFormat = @"{1}/// <typeparam name=""{0}""></typeparam>";
                        typeSB.AppendLine(string.Format(typeParamFormat, param.Identifier.Text.Replace("<", "{").Replace(">", "}"), AppGlobal.GetIndendation(this.Level)));
                    }

                }
            }

            foreach (var param in syntax.ParameterList.Parameters)
            {
                string paramRegex = @"\/\/\/.\<param name\=""" + param.Identifier.ValueText + @"""\>(.*)\<\/param\>";
                var match = Regex.Match(comment, paramRegex);
                if (match.Success && match.Length > 0 && match.Groups.Count > 1)
                {
                    var paramFormat = @"{3}/// <param name=""{0}"">{2}</param>"; ;
                    sb.AppendLine(string.Format(paramFormat, param.Identifier.Text, param.Type.ToString().Replace("<", "{").Replace(">", "}"), match.Groups[1].Value, indendation));
                }
                else
                {
                    var paramFormat = @"{3}/// <param name=""{0}"">The {2}<see cref=""{1}""/></param>";
                    sb.AppendLine(string.Format(paramFormat, param.Identifier.Text, param.Type.ToString().Replace("<", "{").Replace(">", "}"), param.Identifier.ValueText, indendation));
                }
            }

            if (syntax.ReturnType.ToString() != "void")
            {
                string returnRegex = @"\/\/\/.\<returns\>(.*)\<\/returns\>";
                var match = Regex.Match(comment, returnRegex);
                if (match.Success && match.Length > 0 && match.Groups.Count > 1)
                {
                    var returnFormat = @"{1}/// <returns>{0}</returns>";
                    sb.AppendLine(string.Format(returnFormat, match.Groups[1].Value, indendation));
                }
                else
                {
                    var returnFormat = @"{1}/// <returns>The <see cref=""{0}""/></returns>";
                    sb.AppendLine(string.Format(returnFormat, syntax.ReturnType.ToString().Replace("<", "{").Replace(">", "}"), indendation));
                }
            }

            var finalComment = string.Format(methodCommentFormat, methodSummary, sb.ToString(), indendation, typeSB.ToString());
            return SyntaxFactory.Whitespace(finalComment);
        }

        /// <inheritdoc/>
        public override SyntaxTrivia GetTrailingTrivia(MethodDeclarationSyntax syntax)
        {
            return SyntaxFactory.Whitespace(syntax.GetTrailingTrivia().ToFullString().Trim() + Environment.NewLine + Environment.NewLine);
        }

        #endregion

        /// <inheritdoc/>
        protected override MethodDeclarationSyntax ChangeNodeSyntax(MethodDeclarationSyntax input)
        {
            var node = base.ChangeNodeSyntax(input);
            if (node.Body != null && node.Body.OpenBraceToken != null && node.Body.CloseBraceToken != null)
            {
                var body = input.Body;
                if (this.Setting.StatementFixes)
                {
                    body = body.ReplaceNodes(input.DescendantNodes().OfType<StatementSyntax>(), (_, d) => this.ReplaceStatementNode(d));
                }

                body = body.ReplaceToken(body.OpenBraceToken, body.OpenBraceToken.WithLeadingTrivia(SyntaxFactory.ParseLeadingTrivia(AppGlobal.GetIndendation(this.Level))).WithTrailingTrivia(SyntaxFactory.ParseLeadingTrivia(Environment.NewLine)));
                body = body.ReplaceToken(body.CloseBraceToken, body.CloseBraceToken.WithLeadingTrivia(SyntaxFactory.ParseLeadingTrivia(AppGlobal.GetIndendation(this.Level))).WithTrailingTrivia(SyntaxFactory.ParseLeadingTrivia(Environment.NewLine + Environment.NewLine)));
                node = node.WithBody(body);
            }


            return node;
        }

        /// <inheritdoc />
        protected override bool IsCommentMathchesSignature(MethodDeclarationSyntax syntax, string comment)
        {
            return false;
        }

        #region Private Methods

        /// <summary>
        /// The ReplaceStatementNode
        /// </summary>
        /// <param name="input">The <see cref="StatementSyntax"/></param>
        /// <returns>The <see cref="StatementSyntax"/></returns>
        private StatementSyntax ReplaceStatementNode(StatementSyntax input)
        {
            var allFixer = resolver.ResolveAll<IBaseStatementSyntax>();

            IBaseStatementSyntax fixer = allFixer.FirstOrDefault(x => x.Type == input.Kind());

            if (fixer != null)
            {
                input = fixer.FixStatement(input, this.Level + 1);
            }

            return input;
        }

        #endregion

        #endregion
    }
}
