﻿// <copyright file="ConstructorSyntax.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>02-08-2017</date>

namespace CodeFormatter.Core.Syntaxs.TypeMembers
{
    using System;
    using System.Text;
    using System.Text.RegularExpressions;
    using CodeFormatter.Common.Contracts;
    using Microsoft.CodeAnalysis;
    using Microsoft.CodeAnalysis.CSharp;
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    /// <summary>
    /// Defines the <see cref = "ConstructorSyntax"/>
    /// </summary>
    public class ConstructorSyntax : BaseClassMemberSyntax<ConstructorDeclarationSyntax>
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "ConstructorSyntax"/> class.
        /// </summary>
        /// <param name = "setting">The setting file</param>
        public ConstructorSyntax(IDefaultSettings setting) : base(setting)
        {
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <inheritdoc/>
        public override bool CanSyntaxHeaderBeModified(ConstructorDeclarationSyntax syntax)
        {
            return this.Setting.AddConstructorHeader;
        }

        /// <inheritdoc/>
        public override SyntaxTrivia GetNewLeadingTrivia(ConstructorDeclarationSyntax syntax)
        {
            var constructorCommentFormat = @"{2}/// <summary>
{2}/// Initializes a new instance of the <see cref=""{0}""/> class.
{2}/// </summary>
{1}{2}";
            var constructorStaticCommentFormat = @"{2}/// <summary>
{2}/// Initializes static members of the <see cref=""{0}""/> class.
{2}/// </summary>
{1}{2}";
            var constructorPrivateCommentFormat = @"{2}/// <summary>
{2}/// Prevents a default instance of the <see cref=""{0}""/> class from being created.
{2}/// </summary>
{1}{2}";
            StringBuilder sb = new StringBuilder();
            //var paramFormat = @"{3}/// <param name=""{0}"">The {2}<see cref=""{1}""/></param>";
            //foreach (var param in syntax.ParameterList.Parameters)
            //{
            //    sb.AppendLine(string.Format(paramFormat, param.Identifier.Text, param.Type.ToString().Replace("<", "{").Replace(">", "}"), param.Identifier.ValueText ,AppGlobal.GetIndendation(this.Level)));
            //}
            var comment = syntax?.GetLeadingTrivia().ToFullString()?.Trim();
            foreach (var param in syntax.ParameterList.Parameters)
            {
                string paramRegex = @"\/\/\/.\<param name\=""" + param.Identifier.ValueText + @"""\>(.*)\<\/param\>";
                var match = Regex.Match(comment, paramRegex);
                if (match.Success && match.Length > 0 && match.Groups.Count > 1)
                {
                    var paramFormat = @"{3}/// <param name=""{0}"">{2}</param>"; ;
                    sb.AppendLine(string.Format(paramFormat, param.Identifier.Text, param.Type.ToString().Replace("<", "{").Replace(">", "}"), match.Groups[1].Value, AppGlobal.GetIndendation(this.Level)));
                }
                else
                {
                    var paramFormat = @"{3}/// <param name=""{0}"">The {2}<see cref=""{1}""/></param>";
                    sb.AppendLine(string.Format(paramFormat, param.Identifier.Text, param.Type.ToString().Replace("<", "{").Replace(">", "}"), param.Identifier.ValueText, AppGlobal.GetIndendation(this.Level)));
                }
            }

            var format = string.Empty;
            if (syntax.Modifiers.ToString().Contains("static"))
            {
                format = constructorStaticCommentFormat;
            }
            else if (syntax.Modifiers.ToString().Contains("private"))
            {
                format = constructorPrivateCommentFormat;
            }
            else
            {
                format = constructorCommentFormat;
            }

            /// Fetch parant class since in the constructor commment we need to show class name
            var classSytax = syntax.FirstAncestorOrSelf<ClassDeclarationSyntax>();
            var finalComment = string.Format(format, this.GetTypeNameForComment(classSytax), sb.ToString(), AppGlobal.GetIndendation(this.Level));
            return SyntaxFactory.Whitespace(finalComment);
        }

        /// <inheritdoc/>
        public override SyntaxTrivia GetTrailingTrivia(ConstructorDeclarationSyntax syntax)
        {
            return SyntaxFactory.Whitespace(syntax.GetTrailingTrivia().ToFullString().Trim() + Environment.NewLine + Environment.NewLine);
        }

        #endregion

        /// <inheritdoc/>
        protected override ConstructorDeclarationSyntax ChangeNodeSyntax(ConstructorDeclarationSyntax input)
        {
            var node = base.ChangeNodeSyntax(input);
            if (node.Body != null && node.Body.OpenBraceToken != null && node.Body.CloseBraceToken != null)
            {
                var body = input.Body;
                body = body.ReplaceToken(body.OpenBraceToken, body.OpenBraceToken.WithLeadingTrivia(SyntaxFactory.ParseLeadingTrivia(AppGlobal.GetIndendation(this.Level))).WithTrailingTrivia(SyntaxFactory.ParseLeadingTrivia(Environment.NewLine)));
                body = body.ReplaceToken(body.CloseBraceToken, body.CloseBraceToken.WithLeadingTrivia(SyntaxFactory.ParseLeadingTrivia(AppGlobal.GetIndendation(this.Level))).WithTrailingTrivia(SyntaxFactory.ParseLeadingTrivia(Environment.NewLine + Environment.NewLine)));
                node = node.WithBody(body);
            }

            return node;
        }

        /// <inheritdoc />
        protected override bool IsCommentMathchesSignature(ConstructorDeclarationSyntax input, string comment)
        {
            return false;
        }

        #endregion
    }
}
