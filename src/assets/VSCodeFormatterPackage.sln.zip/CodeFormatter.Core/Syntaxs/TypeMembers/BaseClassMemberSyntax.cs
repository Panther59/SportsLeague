﻿// <copyright file="BaseClassMemberSyntax.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>31-07-2017</date>

namespace CodeFormatter.Core.Syntaxs.TypeMembers
{
    using System;
    using CodeFormatter.Common.Contracts;
    using Microsoft.CodeAnalysis;
    using Microsoft.CodeAnalysis.CSharp;
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    /// <summary>
    /// Defines the <see cref = "BaseClassMemberSyntax{T}"/>
    /// </summary>
    /// <typeparam name = "T">The Member Declaration type</typeparam>
    public abstract class BaseClassMemberSyntax<T> : IBaseMemberSyntax where T : MemberDeclarationSyntax
    {
        #region Fields

        /// <summary>
        /// Defines the setting
        /// </summary>
        private readonly IDefaultSettings setting;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "BaseRootSyntax{T}"/> class.
        /// </summary>
        /// <param name = "setting">The setting file</param>
        public BaseClassMemberSyntax(IDefaultSettings setting)
        {
            this.setting = setting;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets a value indicating whether ClearCommentFlag
        /// </summary>
        public bool ClearCommentFlag { get; private set; }

        /// <summary>
        /// Gets or sets the Level
        /// </summary>
        public int Level { get; set; }

        /// <summary>
        /// Gets the Settings
        /// </summary>
        public IDefaultSettings Setting
        {
            get
            {
                return setting;
            }
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// The ApplyLineSeparation
        /// </summary>
        /// <param name="syntax">The <see cref="MemberDeclarationSyntax"/></param>
        /// <param name="memberSeparationLinesCount">The <see cref="int"/></param>
        /// <returns>The <see cref="MemberDeclarationSyntax"/></returns>
        public MemberDeclarationSyntax ApplyLineSeparation(MemberDeclarationSyntax syntax, int memberSeparationLinesCount)
        {
            var newTrivia = SyntaxFactory.Whitespace(syntax.GetTrailingTrivia().ToFullString().Trim() + Environment.NewLine + this.GetSeparationLineText(memberSeparationLinesCount));
            syntax = syntax.WithTrailingTrivia(newTrivia);
            return syntax;
        }

        /// <summary>
        /// The CanSyntaxHeaderBeModified
        /// </summary>
        /// <param name = "syntax">The <see cref = "T"/></param>
        /// <returns>The <see cref = "bool "/></returns>
        public abstract bool CanSyntaxHeaderBeModified(T syntax);

        /// <inheritdoc />
        public MemberDeclarationSyntax ClearComment(MemberDeclarationSyntax input, int level)
        {
            this.ClearCommentFlag = true;
            this.Level = level;
            var obj = input as T;
            if (obj != null)
            {
                return this.ChangeNodeSyntax(obj);
            }

            return null;
        }

        /// <inheritdoc/>
        public MemberDeclarationSyntax FixNode(MemberDeclarationSyntax input, int level)
        {
            this.Level = level;
            var obj = input as T;
            if (obj != null)
            {
                return this.ChangeNodeSyntax(obj);
            }

            return null;
        }

        /// <summary>
        /// The GetExistingLeadingTrivia
        /// </summary>
        /// <param name = "syntax">The <see cref = "T"/></param>
        /// <returns>The <see cref = "SyntaxTrivia"/></returns>
        public virtual SyntaxTrivia GetExistingLeadingTrivia(T syntax)
        {
            var commentFormat = @"{1}{0}
{1}";
            var finalComment = string.Format(commentFormat, syntax.GetLeadingTrivia().ToString().Trim(), AppGlobal.GetIndendation(this.Level));
            return SyntaxFactory.Whitespace(finalComment);
        }

        /// <summary>
        /// The GetNewLeadingTrivia
        /// </summary>
        /// <param name = "syntax">The <see cref = "T"/></param>
        /// <returns>The <see cref = "SyntaxTrivia"/></returns>
        public abstract SyntaxTrivia GetNewLeadingTrivia(T syntax);

        /// <summary>
        /// The GetTrailingTrivia
        /// </summary>
        /// <param name = "syntax">The <see cref = "T"/></param>
        /// <returns>The <see cref = "SyntaxTrivia"/></returns>
        public abstract SyntaxTrivia GetTrailingTrivia(T syntax);

        /// <summary>
        /// The GetTypeNameForComment
        /// </summary>
        /// <param name = "syntax">The <see cref = "TypeDeclarationSyntax"/></param>
        /// <returns>The <see cref = "string "/></returns>
        public string GetTypeNameForComment(TypeDeclarationSyntax syntax)
        {
            if (syntax == null)
            {
                return string.Empty;
            }

            return syntax.Identifier.ValueText + (syntax.TypeParameterList != null ? syntax.TypeParameterList.ToString().Replace("<", "{").Replace(">", "}") : string.Empty);
        }

        #endregion

        /// <summary>
        /// The ChangeNodeSyntax
        /// </summary>
        /// <param name = "input">The <see cref = "T"/></param>
        /// <returns>The <see cref = "T"/></returns>
        protected virtual T ChangeNodeSyntax(T input)
        {
            var newNode = input.WithTrailingTrivia(this.GetTrailingTrivia(input));
            bool existingComment = string.IsNullOrEmpty(input.GetLeadingTrivia().ToString().Trim()) == false;
            bool validCommentPresent = existingComment ? this.IsValidComment(input, input.GetLeadingTrivia().ToString().Trim()) : false;

            SyntaxTrivia leadingSyntax;
            if (validCommentPresent || this.CanSyntaxHeaderBeModified(input) == false)
            {
                if (existingComment && this.ClearCommentFlag == false)
                {
                    leadingSyntax = this.GetExistingLeadingTrivia(input);
                }
                else
                {
                    leadingSyntax = SyntaxFactory.Whitespace(AppGlobal.GetIndendation(this.Level));
                }
            }
            else
            {
                if (this.ClearCommentFlag)
                {
                    leadingSyntax = SyntaxFactory.Whitespace(AppGlobal.GetIndendation(this.Level));
                }
                else
                {
                    if (existingComment)
                    {
                        var newTrivia = this.GetNewLeadingTrivia(input);
                        var oldComment = input.GetLeadingTrivia().ToString().Trim();
                        if (oldComment.Contains("<summary>"))
                        {
                            var commentFormat = @"{0}";
                            var comment = string.Format(commentFormat, newTrivia.ToFullString());
                            leadingSyntax = SyntaxFactory.Whitespace(comment);
                        }
                        else
                        {
                            var commentFormat = @"{2}{0}
{1}";
                            var comment = string.Format(commentFormat, input.GetLeadingTrivia().ToString().Trim(), newTrivia.ToFullString(), AppGlobal.GetIndendation(this.Level));
                            leadingSyntax = SyntaxFactory.Whitespace(comment);
                        }
                    }
                    else
                    {
                        leadingSyntax = this.GetNewLeadingTrivia(input);
                    }
                }
            }

            newNode = newNode.WithLeadingTrivia(leadingSyntax);
            return newNode;
        }

        /// <summary>
        /// The GetSeparationLineText
        /// </summary>
        /// <param name="numberOfSeparationLines">The <see cref="int"/></param>
        /// <returns>The <see cref="string"/></returns>
        protected string GetSeparationLineText(int numberOfSeparationLines)
        {
            string output = string.Empty;
            for (int i = 0; i < numberOfSeparationLines; i++)
            {
                output += Environment.NewLine;
            }

            return output;
        }

        /// <summary>
        /// The IsCommentMathchesSignature
        /// </summary>
        /// <param name="input">The input<see cref="T"/></param>
        /// <param name="comment">The comment<see cref="string"/></param>
        /// <returns>The <see cref="bool"/></returns>
        protected virtual bool IsCommentMathchesSignature(T input, string comment)
        {
            return true;
        }

        #region Private Methods

        /// <summary>
        /// The IsValidComment
        /// </summary>
        /// <param name="input">The input<see cref="T"/></param>
        /// <param name="existingComment">The existingComment<see cref="string"/></param>
        /// <returns>The <see cref="bool"/></returns>
        private bool IsValidComment(T input, string existingComment)
        {
            return existingComment.Contains("inheritdoc") || this.IsCommentMathchesSignature(input, existingComment);
        }

        #endregion

        #endregion
    }
}
