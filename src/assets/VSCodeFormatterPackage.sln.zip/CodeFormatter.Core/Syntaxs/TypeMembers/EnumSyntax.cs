﻿// <copyright file="EnumSyntax.cs" company="Avanade">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>24-04-2018</date>

namespace CodeFormatter.Core.Syntaxs.TypeMembers
{
    using System;
    using System.Linq;
    using System.Text.RegularExpressions;
    using CodeFormatter.Common;
    using CodeFormatter.Common.Contracts;
    using CodeFormatter.Core.Startup;
    using Microsoft.CodeAnalysis;
    using Microsoft.CodeAnalysis.CSharp;
    using Microsoft.CodeAnalysis.CSharp.Syntax;
    using Unity;

    /// <summary>
    /// Defines the <see cref = "EnumSyntax."/>
    /// </summary>
    public class EnumSyntax : BaseClassMemberSyntax<EnumDeclarationSyntax>
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "EnumSyntax"/> class.
        /// </summary>
        /// <param name = "setting">The setting file</param>
        public EnumSyntax(IDefaultSettings setting) : base(setting)
        {
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <inheritdoc/>
        public override bool CanSyntaxHeaderBeModified(EnumDeclarationSyntax syntax)
        {
            return this.Setting.AddEnumHeader;
        }

        /// <inheritdoc/>
        public override SyntaxTrivia GetNewLeadingTrivia(EnumDeclarationSyntax syntax)
        {
//            var fieldComment = @"{1}/// <summary>
//{1}/// Defines the {0}
//{1}/// </summary>
//        ";
//            var finalComment = string.Format(fieldComment, syntax.Identifier.ToString(), AppGlobal.GetIndendation(this.Level));
//            return SyntaxFactory.Whitespace(finalComment);

            bool existingComment = string.IsNullOrEmpty(syntax.GetLeadingTrivia().ToString().Trim()) == false;
            bool summaryTagPresent = existingComment ? syntax.GetLeadingTrivia().ToString().Contains("summary") : false;
            string finalComment = string.Empty;
            var comment = syntax?.GetLeadingTrivia().ToFullString()?.Trim();
            var matchField = Regex.Match(comment, Constants.FieldCommentRegex, RegexOptions.Multiline);
            var matchSummary = Regex.Match(comment, Constants.SummaryCommentRegex, RegexOptions.Multiline);
            string oldSummary = string.Empty;
            if (matchSummary.Success && matchSummary.Length > 0 && matchSummary.Groups.Count > 1 && string.IsNullOrWhiteSpace(matchSummary.Groups[1].Value) == false)
            {
                oldSummary = matchSummary.Groups[1].Value?.Trim();
            }

            if (matchField.Success || string.IsNullOrEmpty(oldSummary))
            {
                var fieldComment = @"{1}{2}/// <summary>
{2}/// Defines the {0}
{2}/// </summary>
{2}";
                finalComment = string.Format(fieldComment, syntax.Identifier.ToString(), string.Empty, AppGlobal.GetIndendation(this.Level));
            }
            else
            {
                var fieldComment = @"{1}{2}/// <summary>
{2}/// {0}
{2}/// </summary>
{2}";

                finalComment = string.Format(fieldComment, oldSummary.Trim(), string.Empty, AppGlobal.GetIndendation(this.Level));
            }

            return SyntaxFactory.Whitespace(finalComment);
        }

        /// <inheritdoc/>
        public override SyntaxTrivia GetTrailingTrivia(EnumDeclarationSyntax syntax)
        {
            return SyntaxFactory.Whitespace(syntax.GetTrailingTrivia().ToFullString().Trim() + Environment.NewLine + Environment.NewLine);
        }

        #endregion

        /// <summary>
        /// The ChangeNodeSyntax
        /// </summary>
        /// <param name="input">The <see cref="EnumDeclarationSyntax"/></param>
        /// <returns>The <see cref="EnumDeclarationSyntax"/></returns>
        protected override EnumDeclarationSyntax ChangeNodeSyntax(EnumDeclarationSyntax input)
        {
            input = base.ChangeNodeSyntax(input);
            if (input.Members != null && input.Members.Count > 0)
            {
                var enumMemberFixer = UnityConfig.Container.Resolve<IBaseMemberSyntax>(SyntaxKind.EnumMemberDeclaration.ToString());
                input = input.ReplaceNodes(input.DescendantNodes().OfType<EnumMemberDeclarationSyntax>(), (_, node) => enumMemberFixer.FixNode(node, this.Level + 1));
                var firstMember = input.DescendantNodes().OfType<EnumMemberDeclarationSyntax>().First();
                var newLeaditnTrivia = firstMember.GetLeadingTrivia().ToString().TrimStart();
                input = input.ReplaceNode(firstMember, firstMember.WithoutLeadingTrivia().WithLeadingTrivia(SyntaxFactory.Whitespace(newLeaditnTrivia)));
            }
            return input;
        }

        #endregion
    }
}
