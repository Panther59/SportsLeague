﻿namespace CodeFormatter.Core.Syntaxs.TypeMembers
{
    using System;
    using System.Linq;
    using System.Text.RegularExpressions;
    using CodeFormatter.Common;
    using CodeFormatter.Common.Contracts;
    using Microsoft.CodeAnalysis;
    using Microsoft.CodeAnalysis.CSharp;
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    /// <summary>
    /// Defines the <see cref = "FieldSyntax"/>
    /// </summary>
    public class FieldSyntax : BaseClassMemberSyntax<FieldDeclarationSyntax>
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "FieldSyntax"/> class.
        /// </summary>
        /// <param name = "setting">The setting file</param>
        public FieldSyntax(IDefaultSettings setting) : base(setting)
        {
        }

        #endregion

        #region Methods

        /// <inheritdoc/>
        public override bool CanSyntaxHeaderBeModified(FieldDeclarationSyntax syntax)
        {
            return this.Setting.AddFieldHeader;
        }

        /// <inheritdoc/>
        public override SyntaxTrivia GetNewLeadingTrivia(FieldDeclarationSyntax syntax)
        {
            bool existingComment = string.IsNullOrEmpty(syntax.GetLeadingTrivia().ToString().Trim()) == false;
            bool summaryTagPresent = existingComment ? syntax.GetLeadingTrivia().ToString().Contains("summary") : false;
            string finalComment = string.Empty;
            var comment = syntax?.GetLeadingTrivia().ToFullString()?.Trim();
            var matchField = Regex.Match(comment, Constants.FieldCommentRegex, RegexOptions.Multiline);
            var matchSummary = Regex.Match(comment, Constants.SummaryCommentRegex, RegexOptions.Multiline);
            string oldSummary = string.Empty;
            if (matchSummary.Success && matchSummary.Length > 0 && matchSummary.Groups.Count > 1 && string.IsNullOrWhiteSpace(matchSummary.Groups[1].Value) == false)
            {
                oldSummary = matchSummary.Groups[1].Value?.Trim();
            }

            if (matchField.Success || string.IsNullOrEmpty(oldSummary))
            {
                var fieldComment = @"{1}{2}/// <summary>
{2}/// Defines the {0}
{2}/// </summary>
{2}";
                var varNames = string.Empty;
                syntax.Declaration?.Variables.Select(x => x.Identifier.Text.Trim()).ToList().ForEach((y) =>
                {
                    if (string.IsNullOrEmpty(varNames))
                    {
                        varNames += y;
                    }
                    else
                    {
                        varNames += (", " + y);
                    }
                });

                finalComment = string.Format(fieldComment, varNames, string.Empty, AppGlobal.GetIndendation(this.Level));
            }
            else
            {
                var fieldComment = @"{1}{2}/// <summary>
{2}/// {0}
{2}/// </summary>
{2}";

                finalComment = string.Format(fieldComment, oldSummary.Trim(), string.Empty, AppGlobal.GetIndendation(this.Level));
            }

            return SyntaxFactory.Whitespace(finalComment);
        }

        /// <inheritdoc/>
        public override SyntaxTrivia GetTrailingTrivia(FieldDeclarationSyntax syntax)
        {
            return SyntaxFactory.Whitespace(syntax.GetTrailingTrivia().ToFullString().Trim() + Environment.NewLine + Environment.NewLine);
        }

        /// <inheritdoc/>
        protected override bool IsCommentMathchesSignature(FieldDeclarationSyntax input, string comment)
        {
            return false;
        }

        #endregion
    }
}
