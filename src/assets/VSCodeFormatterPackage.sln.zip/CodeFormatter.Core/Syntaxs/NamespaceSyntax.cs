﻿// <copyright file="NamespaceSyntax.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>31-07-2017</date>

namespace CodeFormatter.Core.Syntaxs
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using CodeFormatter.Common.Contracts;
    using CodeFormatter.Core.Syntaxs.MemberGroups;
    using CodeFormatter.Core.Syntaxs.TypeMembers;
    using Microsoft.CodeAnalysis;
    using Microsoft.CodeAnalysis.CSharp;
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    /// <summary>
    /// Defines the <see cref = "NamespaceSyntax"/>
    /// </summary>
    public class NamespaceSyntax : BaseClassMemberSyntax<NamespaceDeclarationSyntax>
    {
        #region Fields

        /// <summary>
        /// Defines the resolver
        /// </summary>
        private readonly IResolver resolver;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "NamespaceSyntax"/> class.
        /// </summary>
        /// <param name = "setting">The setting file</param>
        public NamespaceSyntax(IDefaultSettings setting, IResolver resolver) : base(setting)
        {
            this.resolver = resolver;
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <inheritdoc/>
        public override bool CanSyntaxHeaderBeModified(NamespaceDeclarationSyntax syntax)
        {
            return true;
        }

        /// <inheritdoc/>
        public override SyntaxTrivia GetNewLeadingTrivia(NamespaceDeclarationSyntax syntax)
        {
            var leadingTrivia = syntax.GetLeadingTrivia().ToFullString().Trim();
            if (string.IsNullOrEmpty(leadingTrivia) == false)
            {
                leadingTrivia = leadingTrivia + Environment.NewLine + Environment.NewLine;
            }

            return SyntaxFactory.Whitespace(leadingTrivia + AppGlobal.GetIndendation(this.Level));
        }

        /// <inheritdoc/>
        public override SyntaxTrivia GetTrailingTrivia(NamespaceDeclarationSyntax syntax)
        {
            return SyntaxFactory.Whitespace(Environment.NewLine + Environment.NewLine);
        }

        #endregion

        /// <summary>
        /// The ChangeNodeSyntax
        /// </summary>
        /// <param name="input">The <see cref="NamespaceDeclarationSyntax"/></param>
        /// <returns>The <see cref="NamespaceDeclarationSyntax"/></returns>
        protected override NamespaceDeclarationSyntax ChangeNodeSyntax(NamespaceDeclarationSyntax input)
        {
            input = this.FixNamespaceObject(input);
            var node = base.ChangeNodeSyntax(input);
            //node = this.FixNamespaceObject(node);
            return node;
        }

        #region Private Methods

        /// <summary>
        /// The FixNamespaceObject
        /// </summary>
        /// <param name = "namespaceObj">The <see cref = "NamespaceDeclarationSyntax"/></param>
        /// <returns>The <see cref = "NamespaceDeclarationSyntax"/></returns>
        private NamespaceDeclarationSyntax FixNamespaceObject(NamespaceDeclarationSyntax namespaceObj)
        {
            if (namespaceObj.OpenBraceToken != null && namespaceObj.CloseBraceToken != null)
            {
                namespaceObj = namespaceObj.ReplaceToken(namespaceObj.OpenBraceToken, namespaceObj.OpenBraceToken.WithLeadingTrivia(SyntaxFactory.ParseLeadingTrivia(AppGlobal.GetIndendation(this.Level))).WithTrailingTrivia(SyntaxFactory.ParseLeadingTrivia(Environment.NewLine)));
                namespaceObj = namespaceObj.ReplaceToken(namespaceObj.CloseBraceToken, namespaceObj.CloseBraceToken.WithLeadingTrivia(SyntaxFactory.ParseLeadingTrivia(AppGlobal.GetIndendation(this.Level))).WithTrailingTrivia(SyntaxFactory.ParseLeadingTrivia(Environment.NewLine)));
            }
            SyntaxList<MemberDeclarationSyntax> classMembers = this.GroupAndSortMembers(namespaceObj);
            namespaceObj = namespaceObj.WithMembers(classMembers);
            var newUsings = this.FixUsings(namespaceObj.Usings, this.Level + 1);
            namespaceObj = namespaceObj.WithUsings(newUsings);

            return namespaceObj;
        }

        /// <summary>
        /// The FixUsings
        /// </summary>
        /// <param name="outsideUsing">The <see cref="SyntaxList{UsingDirectiveSyntax}"/></param>
        /// <param name="level">The <see cref="int"/></param>
        /// <returns>The <see cref="SyntaxList{UsingDirectiveSyntax}"/></returns>
        private SyntaxList<UsingDirectiveSyntax> FixUsings(SyntaxList<UsingDirectiveSyntax> outsideUsing, int level)
        {
            outsideUsing = SortNamespaces(outsideUsing);
            SyntaxList<UsingDirectiveSyntax> output;
            foreach (UsingDirectiveSyntax item in outsideUsing)
            {
                var usingToken = item.WithoutLeadingTrivia().WithLeadingTrivia(SyntaxFactory.Whitespace(AppGlobal.GetIndendation(level)));
                if (output.Count == outsideUsing.Count - 1)
                {
                    usingToken = usingToken.WithTrailingTrivia(SyntaxFactory.Whitespace(usingToken.GetTrailingTrivia().ToString() + Environment.NewLine));
                }

                output = output.Add(usingToken);
            }

            return output;
        }

        /// <summary>
        /// The GroupAndSortMembers
        /// </summary>
        /// <param name = "type">The <see cref = "TypeDeclarationSyntax"/></param>
        /// <returns>The <see cref = "SyntaxList{MemberDeclarationSyntax}"/></returns>
        private SyntaxList<MemberDeclarationSyntax> GroupAndSortMembers(NamespaceDeclarationSyntax type)
        {
            List<ClassMemberType> finalList = new List<ClassMemberType>();
            foreach (var item in type.Members)
            {
                ClassMemberType internalMember = this.resolver.Resolve<ClassMemberType>();
                internalMember.Load(item, this.Level + 1, item is InterfaceDeclarationSyntax, this.ClearCommentFlag);
                finalList.Add(internalMember);
            }

            var typeLayout = this.resolver.Resolve<TypeLayout>();
            finalList = typeLayout.ApplyLayout(finalList);
            SyntaxList<MemberDeclarationSyntax> classMembers;
            foreach (var item in finalList)
            {
                classMembers = classMembers.Add(item.Member);
            }

            classMembers = this.TriviaChangesForBorderMembers(classMembers);
            return classMembers;
        }

        /// <summary>
        /// The SortNamespaces
        /// </summary>
        /// <param name = "usingDirectives">The <see cref = "SyntaxList{UsingDirectiveSyntax}"/></param>
        /// <param name = "placeSystemNamespaceFirst">The <see cref = "bool "/></param>
        /// <returns>The <see cref = "SyntaxList{UsingDirectiveSyntax}"/></returns>
        private SyntaxList<UsingDirectiveSyntax> SortNamespaces(SyntaxList<UsingDirectiveSyntax> usingDirectives, bool placeSystemNamespaceFirst = false)
        {
            var output = SyntaxFactory.List(usingDirectives.OrderBy(x => x.StaticKeyword.IsKind(SyntaxKind.StaticKeyword) ? 1 : x.Alias == null ? 0 : 2).ThenBy(x => x.Alias?.ToString()).ThenByDescending(x => placeSystemNamespaceFirst && (x.Name.ToString().StartsWith(nameof(System) + ".") || (x.Name.ToString() == "System"))).ThenBy(x => x.Name.ToString()));
            return output;
        }

        /// <summary>
        /// The TriviaChangesForBorderMembers
        /// </summary>
        /// <param name = "classMembers">The <see cref = "SyntaxList{MemberDeclarationSyntax}"/></param>
        /// <returns>The <see cref = "SyntaxList{MemberDeclarationSyntax}"/></returns>
        private SyntaxList<MemberDeclarationSyntax> TriviaChangesForBorderMembers(SyntaxList<MemberDeclarationSyntax> classMembers)
        {
            if (classMembers.Count > 0)
            {
                var last = classMembers[classMembers.Count - 1];
                var lastTrailing = last.GetTrailingTrivia().ToFullString().TrimEnd() + System.Environment.NewLine;
                last = last.WithoutTrailingTrivia().WithTrailingTrivia(SyntaxFactory.Whitespace(lastTrailing));
                classMembers = classMembers.RemoveAt(classMembers.Count - 1);
                classMembers = classMembers.Insert(classMembers.Count, last);
            }

            return classMembers;
        }

        #endregion

        #endregion
    }
}