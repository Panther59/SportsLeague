﻿// <copyright file="IBaseNamespaceMemberSyntax.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>31-07-2017</date>

namespace CodeFormatter.Core.Syntaxs
{
    /// <summary>
    /// Defines the <see cref = IBaseNamespaceMemberSyntax / >
    /// </summary>
    public interface IBaseNamespaceMemberSyntax : IBaseMemberSyntax
    {
    }
}