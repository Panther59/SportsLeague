﻿// <copyright file="BaseTypeMemberSyntax.cs" company="Avanade">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>29-05-2018</date>

namespace CodeFormatter.Core.Syntaxs
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using System.Text.RegularExpressions;
    using CodeFormatter.Common;
    using CodeFormatter.Common.Contracts;
    using CodeFormatter.Core.Syntaxs.MemberGroups;
    using CodeFormatter.Core.Syntaxs.TypeMembers;
    using Microsoft.CodeAnalysis;
    using Microsoft.CodeAnalysis.CSharp;
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    /// <summary>
    /// Defines the <see cref = "BaseTypeMemberSyntax{T}"/>
    /// </summary>
    /// <typeparam name = "T"></typeparam>
    public abstract class BaseTypeMemberSyntax<T> : BaseClassMemberSyntax<T> where T : TypeDeclarationSyntax
    {
        #region Fields

        /// <summary>
        /// Defines the resolver
        /// </summary>
        private readonly IResolver resolver;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "BaseSyntax{T}"/> class.
        /// </summary>
        /// <param name = "setting">The setting file</param>
        public BaseTypeMemberSyntax(IDefaultSettings setting, IResolver resolver) : base(setting)
        {
            this.resolver = resolver;
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <inheritdoc/>
        public override bool CanSyntaxHeaderBeModified(T syntax)
        {
            return this.Setting.AddClassHeader;
        }

        /// <inheritdoc/>
        public override SyntaxTrivia GetNewLeadingTrivia(T syntax)
        {
            if (this.ClearCommentFlag)
            {
                return SyntaxFactory.Whitespace(AppGlobal.GetIndendation(this.Level));
            }
            else
            {
                var comment = syntax?.GetLeadingTrivia().ToFullString()?.Trim();
                var classSummary = string.Empty;
                
                var matchMethod = Regex.Match(comment, Constants.SummaryCommentRegex, RegexOptions.Multiline);
                if (matchMethod.Success && matchMethod.Length > 0 && matchMethod.Groups.Count > 1 && string.IsNullOrWhiteSpace(matchMethod.Groups[1].Value) == false)
                {
                    classSummary = matchMethod.Groups[1].Value?.Trim();
                }
                else
                {
                    classSummary = @"Defines the <see cref=""" + this.GetTypeNameForComment(syntax) + @""" />";
                }

                var classComment = @"{3}/// <summary>
{3}/// {4}
{3}/// </summary>
{2}{3}";
                StringBuilder sb = new StringBuilder();
                if (syntax.TypeParameterList != null)
                {
                    foreach (var param in syntax.TypeParameterList.Parameters)
                    {
                        string typeParamRegex = @"\/\/\/.\<typeparam name\=""" + param.Identifier.Text.Replace("<", "{").Replace(">", "}") + @"""\>(.*)\<\/typeparam\>";
                        var match = Regex.Match(comment, typeParamRegex);
                        if (match.Success && match.Length > 0 && match.Groups.Count > 1)
                        {
                            var typeParamFormat = @"{1}/// <typeparam name=""{0}"">{2}</typeparam>";
                            sb.AppendLine(string.Format(typeParamFormat, param.Identifier.Text.Replace("<", "{").Replace(">", "}"), AppGlobal.GetIndendation(this.Level), match.Groups[1].Value));
                        }
                        else
                        {
                            var typeParamFormat = @"{1}/// <typeparam name=""{0}""></typeparam>";
                            sb.AppendLine(string.Format(typeParamFormat, param.Identifier.Text.Replace("<", "{").Replace(">", "}"), AppGlobal.GetIndendation(this.Level)));
                        }

                    }
                }

                var finalComment = string.Format(classComment, syntax.GetLeadingTrivia().ToString().Trim(), this.GetTypeNameForComment(syntax), sb.ToString(), AppGlobal.GetIndendation(this.Level), classSummary);

                return SyntaxFactory.Whitespace(finalComment);
            }
        }

        /// <inheritdoc/>
        public override SyntaxTrivia GetTrailingTrivia(T syntax)
        {
            return SyntaxFactory.Whitespace(syntax.GetTrailingTrivia().ToFullString().Trim() + Environment.NewLine + Environment.NewLine);
        }

        #endregion

        /// <summary>
        /// Add members to to type
        /// </summary>
        /// <param name = "type">The type</param>
        /// <param name = "classMembers">The class members</param>
        /// <returns>The type</returns>
        protected abstract T AddMembersToType(T type, SyntaxList<MemberDeclarationSyntax> classMembers);

        /// <summary>
        /// The ChangeNodeSyntax
        /// </summary>
        /// <param name = "input">The <see cref = "T"/></param>
        /// <returns>The <see cref = "T"/></returns>
        protected override T ChangeNodeSyntax(T input)
        {
            var node = base.ChangeNodeSyntax(input);
            node = this.FixClassDeclaration(node);
            return node;
        }

        /// <inheritdoc />
        protected override bool IsCommentMathchesSignature(T input, string comment)
        {
            return false;
        }

        #region Private Methods

        /// <summary>
        /// The FixClassDeclaration
        /// </summary>
        /// <param name = "classDecl">The <see cref = "T"/></param>
        /// <returns>The <see cref = "T"/></returns>
        private T FixClassDeclaration(T classDecl)
        {
            SyntaxList<MemberDeclarationSyntax> classMembers = this.GroupAndSortMembers(classDecl);
            classDecl = this.AddMembersToType(classDecl, classMembers);
            if (classDecl.OpenBraceToken != null && classDecl.CloseBraceToken != null)
            {
                classDecl = classDecl.ReplaceToken(classDecl.OpenBraceToken, classDecl.OpenBraceToken.WithLeadingTrivia(SyntaxFactory.ParseLeadingTrivia(AppGlobal.GetIndendation(this.Level))).WithTrailingTrivia(SyntaxFactory.ParseLeadingTrivia(Environment.NewLine)));
                classDecl = classDecl.ReplaceToken(classDecl.CloseBraceToken, classDecl.CloseBraceToken.WithLeadingTrivia(SyntaxFactory.ParseLeadingTrivia(AppGlobal.GetIndendation(this.Level))).WithTrailingTrivia(SyntaxFactory.ParseLeadingTrivia(Environment.NewLine + Environment.NewLine)));
            }

            return classDecl;
        }

        /// <summary>
        /// The GroupAndSortMembers
        /// </summary>
        /// <param name = "type">The <see cref = "TypeDeclarationSyntax"/></param>
        /// <returns>The <see cref = "SyntaxList{MemberDeclarationSyntax}"/></returns>
        private SyntaxList<MemberDeclarationSyntax> GroupAndSortMembers(TypeDeclarationSyntax type)
        {
            List<ClassMemberType> finalList = new List<ClassMemberType>();
            foreach (var item in type.Members)
            {
                ClassMemberType internalMember = this.resolver.Resolve<ClassMemberType>();
                internalMember.Load(item, this.Level + 1, type is InterfaceDeclarationSyntax, this.ClearCommentFlag);
                finalList.Add(internalMember);
            }

            var typeLayout = this.resolver.Resolve<TypeLayout>();
            finalList = typeLayout.ApplyLayout(finalList);
            SyntaxList<MemberDeclarationSyntax> classMembers;
            foreach (var item in finalList)
            {
                classMembers = classMembers.Add(item.Member);
            }

            classMembers = this.TriviaChangesForBorderMembers(classMembers);
            return classMembers;
        }

        /// <summary>
        /// The TriviaChangesForBorderMembers
        /// </summary>
        /// <param name = "classMembers">The <see cref = "SyntaxList{MemberDeclarationSyntax}"/></param>
        /// <returns>The <see cref = "SyntaxList{MemberDeclarationSyntax}"/></returns>
        private SyntaxList<MemberDeclarationSyntax> TriviaChangesForBorderMembers(SyntaxList<MemberDeclarationSyntax> classMembers)
        {
            if (classMembers.Count > 0)
            {
                //var leading = classMembers[0].GetLeadingTrivia().ToFullString().TrimStart();
                //classMembers.Replace(classMembers[0], classMembers[0].WithoutLeadingTrivia().WithLeadingTrivia(SyntaxFactory.Whitespace(leading)));
                var last = classMembers[classMembers.Count - 1];
                var lastTrailing = last.GetTrailingTrivia().ToFullString().TrimEnd() + System.Environment.NewLine;
                last = last.WithoutTrailingTrivia().WithTrailingTrivia(SyntaxFactory.Whitespace(lastTrailing));
                classMembers = classMembers.RemoveAt(classMembers.Count - 1);
                classMembers = classMembers.Insert(classMembers.Count, last);
            }

            return classMembers;
        }

        #endregion

        #endregion
    }
}
