// <copyright file="CodeFileFormatter.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>31-07-2017</date>

namespace CodeFormatter.Core
{
    using System.IO;
    using System.Text.RegularExpressions;
    using System.Threading.Tasks;
    using CodeFormatter.Common.Contracts;
    using CodeFormatter.Core.Syntaxs;
    using Microsoft.CodeAnalysis;
    using Microsoft.CodeAnalysis.CSharp;
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    /// <summary>
    /// Defines the <see cref = "CodeFileFormatter"/>
    /// </summary>
    public class CodeFileFormatter
    {
        #region Fields

        /// <summary>
        /// Defines the resolver
        /// </summary>
        private readonly IResolver resolver;

        /// <summary>
        /// Defines the setting
        /// </summary>
        private readonly IDefaultSettings setting;

        /// <summary>
        /// The 
        /// </summary>
        internal SyntaxList<UsingDirectiveSyntax> outsideUsing;

        /// <summary>
        /// Defines the rootSyntax
        /// </summary>
        private RootSyntax rootSyntax;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "CodeFileFormatter"/> class.
        /// </summary>
        /// <param name = "setting">The <see cref = "IDefaultSettings"/></param>
        /// <param name = "resolver">The <see cref = "IResolver"/></param>
        /// <param name = "rootSyntax">The <see cref = "RootSyntax"/></param>
        public CodeFileFormatter(IDefaultSettings setting, IResolver resolver, RootSyntax rootSyntax)
        {
            this.setting = setting;
            this.resolver = resolver;
            this.rootSyntax = rootSyntax;
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// The FormatFromContent
        /// </summary>
        /// <param name = "content">The <see cref = "string "/></param>
        /// <returns>The <see cref = "Task{string}"/></returns>
        public async Task<string> FormatFromContent(string content, string fileName, string header)
        {
            var tree = CSharpSyntaxTree.ParseText(content);
            CompilationUnitSyntax rootElememt = await tree.GetRootAsync() as CompilationUnitSyntax;
            rootElememt = this.rootSyntax.ChangeNodeSyntax(rootElememt, fileName, header);

            var data = rootElememt.ToFullString();
            data = this.ReplaceKnownProblems(data);
            return data;
        }

        public async Task<string> RemoveCommentsFromContent(string content, string fileName, string header)
        {
            var tree = CSharpSyntaxTree.ParseText(content);
            CompilationUnitSyntax rootElememt = await tree.GetRootAsync() as CompilationUnitSyntax;
            rootElememt = this.rootSyntax.ClearCommentFromNodeSyntax(rootElememt, fileName, header);

            var data = rootElememt.ToFullString();
            data = this.ReplaceKnownProblems(data);
            return data;
        }

        /// <summary>
        /// The FormatFromFilePath
        /// </summary>
        /// <param name = "path">The <see cref = "string "/></param>
        /// <returns>The <see cref = "Task{string}"/></returns>
        public Task<string> FormatFromFilePath(string path, string header)
        {
            string content = File.ReadAllText(path);
            return this.FormatFromContent(content, Path.GetFileName(path), header);
        }

        #endregion

        #region Private Methods

        //#region Private Methods
        ///// <summary>
        ///// The FixClassDeclaration
        ///// </summary>
        ///// <param name = "classDecl">The <see cref = "ClassDeclarationSyntax"/></param>
        ///// <returns>The <see cref = "ClassDeclarationSyntax"/></returns>
        //private ClassDeclarationSyntax FixClassDeclaration(ClassDeclarationSyntax classDecl)
        //{
        //    SyntaxList<MemberDeclarationSyntax> classMembers = this.SortTypeMembers(classDecl);
        //    classDecl = classDecl.WithMembers(classMembers);
        //    return classDecl;
        //}
        ///// <summary>
        ///// The FixClassDeclaration
        ///// </summary>
        ///// <param name = "classes">The <see cref = "SyntaxList{ClassDeclarationSyntax}"/></param>
        ///// <returns>The <see cref = "SyntaxList{ClassDeclarationSyntax}"/></returns>
        //private SyntaxList<ClassDeclarationSyntax> FixClassDeclaration(SyntaxList<ClassDeclarationSyntax> classes)
        //{
        //    SyntaxList<ClassDeclarationSyntax> newClasses;
        //    foreach (var item in classes)
        //    {
        //        newClasses = newClasses.Add(this.FixClassDeclaration(item));
        //    }
        //    return newClasses;
        //}
        ///// <summary>
        ///// The FixInterfaceDeclaration
        ///// </summary>
        ///// <param name = "interfaceDecl">The <see cref = "InterfaceDeclarationSyntax"/></param>
        ///// <returns>The <see cref = "InterfaceDeclarationSyntax"/></returns>
        //private InterfaceDeclarationSyntax FixInterfaceDeclaration(InterfaceDeclarationSyntax interfaceDecl)
        //{
        //    SyntaxList<MemberDeclarationSyntax> classMembers = this.SortTypeMembers(interfaceDecl);
        //    interfaceDecl = interfaceDecl.WithMembers(classMembers);
        //    return interfaceDecl;
        //}
        ///// <summary>
        ///// The FixNamespaceObject
        ///// </summary>
        ///// <param name = "napespaceObj">The <see cref = "NamespaceDeclarationSyntax"/></param>
        ///// <returns>The <see cref = "NamespaceDeclarationSyntax"/></returns>
        //private NamespaceDeclarationSyntax FixNamespaceObject(NamespaceDeclarationSyntax napespaceObj)
        //{
        //    SyntaxList<UsingDirectiveSyntax> finalUsing;
        //    if (this.setting.MoveUsingInsideNamespace)
        //    {
        //        foreach (var item in outsideUsing)
        //        {
        //            var planitem = item.WithoutTrivia();
        //            finalUsing = finalUsing.Add(planitem);
        //        }
        //    }
        //    foreach (var item in napespaceObj.Usings)
        //    {
        //        finalUsing = finalUsing.Add(item);
        //    }
        //    var newNamespace = napespaceObj.WithUsings(SortNamespaces(finalUsing, true));
        //    SyntaxList<MemberDeclarationSyntax> finalClassMembers;
        //    //var otherMem = newNamespace.Members.Where(x => x.Kind() != SyntaxKind.ClassDeclaration && x.Kind() != SyntaxKind.InterfaceDeclaration);
        //    //foreach (var item in otherMem)
        //    //{
        //    //    finalClassMembers = finalClassMembers.Add(item);
        //    //}
        //    foreach (var item in newNamespace.Members)
        //    {
        //        NamespaceMemberType classMem = this.resolver.Resolve<NamespaceMemberType>();
        //        classMem.Load(item);
        //        finalClassMembers = finalClassMembers.Add(classMem.Member);
        //    }
        //    //foreach (InterfaceDeclarationSyntax item in newNamespace.Members.Where(x => x.Kind() == SyntaxKind.InterfaceDeclaration))
        //    //{
        //    //    ClassMemberType classMem = this.resolver.Resolve<ClassMemberType>();
        //    //    classMem.Load(item);
        //    //    var newClassDecl = this.FixInterfaceDeclaration(classMem.Member as InterfaceDeclarationSyntax);
        //    //    finalClassMembers = finalClassMembers.Add(newClassDecl);
        //    //}
        //    //newNamespace = newNamespace.NormalizeWhitespace();
        //    finalClassMembers = this.TriviaChangesForBorderMembers(finalClassMembers);
        //    newNamespace = newNamespace.WithMembers(finalClassMembers);
        //    return newNamespace;
        //}
        ///// <summary>
        ///// The GetHeaderContentFromTemplate
        ///// </summary>
        ///// <param name="header">The <see cref="string"/></param>
        ///// <param name="fileName">The <see cref="string"/></param>
        ///// <returns>The <see cref="string"/></returns>
        //private string GetHeaderContentFromTemplate(string header, string fileName)
        //{
        //    //{ "Select", "File Name", "Current Year", "Current Month", "Current Day", "Current Date", "Current Date Time", "User Name"};
        //    header = header.Replace("$File Name$", fileName);
        //    header = header.Replace("$Current Year$", DateTime.Now.ToString("yyyy"));
        //    header = header.Replace("$Current Month$", DateTime.Now.ToString("MM"));
        //    header = header.Replace("$Current Day$", DateTime.Now.ToString("dd"));
        //    header = header.Replace("$Current Date$", DateTime.Now.ToShortDateString());
        //    header = header.Replace("$Current Date Time$", DateTime.Now.ToString());
        //    header = header.Replace("$User Name$", System.Security.Principal.WindowsIdentity.GetCurrent().Name);
        //    return header;
        //}
        ///// <summary>
        ///// Removes the Region and endregion lines from the code
        ///// </summary>
        ///// <param name = "input">The root object</param>
        ///// <returns>The root object after removing region code</returns>
        //private CompilationUnitSyntax RemoveRegionLines(CompilationUnitSyntax input)
        //{
        //    var trivia = input.DescendantTrivia().Where(t => t.HasStructure && (t.GetStructure().Kind() == SyntaxKind.RegionDirectiveTrivia || t.GetStructure().Kind() == SyntaxKind.EndRegionDirectiveTrivia));
        //    input = input.ReplaceTrivia(trivia, (t, t2) => SyntaxFactory.Whitespace(string.Empty));
        //    return input;
        //}
        /// <summary>
        /// The ReplaceKnownProblems
        /// </summary>
        /// <param name = "data">The <see cref = "string "/></param>
        /// <returns>The <see cref = "string "/></returns>
        private string ReplaceKnownProblems(string data)
        {
            Regex regex = new Regex(@"\}\r\n\r\n *\)");
            data = regex.Replace(data, "})");
            return data;
        }

        #endregion

        #endregion
        ///// <summary>
        ///// The SortNamespaces
        ///// </summary>
        ///// <param name = "usingDirectives">The <see cref = "SyntaxList{UsingDirectiveSyntax}"/></param>
        ///// <param name = "placeSystemNamespaceFirst">The <see cref = "bool "/></param>
        ///// <returns>The <see cref = "SyntaxList{UsingDirectiveSyntax}"/></returns>
        //private SyntaxList<UsingDirectiveSyntax> SortNamespaces(SyntaxList<UsingDirectiveSyntax> usingDirectives, bool placeSystemNamespaceFirst = false)
        //{
        //    var output = SyntaxFactory.List(usingDirectives.OrderBy(x => x.StaticKeyword.IsKind(SyntaxKind.StaticKeyword) ? 1 : x.Alias == null ? 0 : 2).ThenBy(x => x.Alias?.ToString()).ThenByDescending(x => placeSystemNamespaceFirst && (x.Name.ToString().StartsWith(nameof(System) + ".") || (x.Name.ToString() == "System"))).ThenBy(x => x.Name.ToString()));
        //    return output;
        //}
        ///// <summary>
        ///// The SortTypeMembers
        ///// </summary>
        ///// <param name = "type">The <see cref = "TypeDeclarationSyntax"/></param>
        ///// <returns>The <see cref = "SyntaxList{MemberDeclarationSyntax}"/></returns>
        //private SyntaxList<MemberDeclarationSyntax> SortTypeMembers(TypeDeclarationSyntax type)
        //{
        //    List<ClassMemberType> finalList = new List<ClassMemberType>();
        //    foreach (var item in type.Members)
        //    {
        //        ClassMemberType internalMember = this.resolver.Resolve<ClassMemberType>();
        //        internalMember.Load(item, type is InterfaceDeclarationSyntax);
        //        finalList.Add(internalMember);
        //    }
        //    var typeLayout = this.resolver.Resolve<TypeLayout>();
        //    finalList = typeLayout.ApplyLayout(finalList);
        //    //finalList = finalList.OrderBy(x => x.MemberRank).ThenBy(y => y.ModifierRank).ThenBy(y => y.GroupRank).ThenBy(z => this.setting.SortByName ? z.Identifier : string.Empty).ThenBy(z => this.setting.SortByName ? z.ParameterText : string.Empty).ToList();
        //    SyntaxList<MemberDeclarationSyntax> classMembers;
        //    foreach (var item in finalList)
        //    {
        //        classMembers = classMembers.Add(item.Member);
        //    }
        //    classMembers = this.TriviaChangesForBorderMembers(classMembers);
        //    return classMembers;
        //}
        ///// <summary>
        ///// The TriviaChangesForBorderMembers
        ///// </summary>
        ///// <param name = "classMembers">The <see cref = "SyntaxList{MemberDeclarationSyntax}"/></param>
        ///// <returns>The <see cref = "SyntaxList{MemberDeclarationSyntax}"/></returns>
        //private SyntaxList<MemberDeclarationSyntax> TriviaChangesForBorderMembers(SyntaxList<MemberDeclarationSyntax> classMembers)
        //{
        //    if (classMembers.Count > 0)
        //    {
        //        var last = classMembers[classMembers.Count - 1];
        //        var lastTrailing = last.GetTrailingTrivia().ToFullString().TrimEnd() + System.Environment.NewLine;
        //        last = last.WithoutTrailingTrivia().WithTrailingTrivia(SyntaxFactory.Whitespace(lastTrailing));
        //        classMembers = classMembers.RemoveAt(classMembers.Count - 1);
        //        classMembers = classMembers.Insert(classMembers.Count, last);
        //    }
        //    return classMembers;
        //}
        //#endregion
    }
}