// <copyright file="ClassMemberType.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>18-08-2017</date>

namespace CodeFormatter.Core
{
    using System;
    using CodeFormatter.Common;
    using CodeFormatter.Common.Contracts;
    using CodeFormatter.Core.Syntaxs;
    using Microsoft.CodeAnalysis.CSharp.Syntax;
    using Ayvan.ErrorLogger;

    /// <summary>
    /// Defines the <see cref = "ClassMemberType"/>
    /// </summary>
    public class ClassMemberType : BaseMemberType
    {
        #region Fields

        /// <summary>
        /// Defines the resolver
        /// </summary>
        private readonly IResolver resolver;

        /// <summary>
        /// Defines the setting
        /// </summary>
        private readonly IDefaultSettings setting;

        /// <summary>
        /// Defines the baseSyntax
        /// </summary>
        private IBaseMemberSyntax baseSyntax;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "ClassMemberType"/> class.
        /// </summary>
        /// <param name = "setting">The <see cref = "IDefaultSettings"/></param>
        /// <param name = "resolver">The <see cref = "IResolver"/></param>
        public ClassMemberType(IDefaultSettings setting, IResolver resolver) : base(setting, resolver)
        {
            this.setting = setting;
            this.resolver = resolver;
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// The ApplyLineSeparation
        /// </summary>
        /// <param name="memberSeparationLinesCount">The <see cref="int"/></param>
        public void ApplyLineSeparation(int memberSeparationLinesCount)
        {
            this.Member = this.baseSyntax.ApplyLineSeparation(this.Member, memberSeparationLinesCount);
        }

        /// <summary>
        /// The Load
        /// </summary>
        /// <param name = "source">The <see cref = "MemberDeclarationSyntax"/></param>
        /// <param name = "isParentInterface">The <see cref = "bool "/></param>
        public void Load(MemberDeclarationSyntax source, int level, bool isParentInterface = false, bool clearComment = false)
        {
            this.Level = level;
            try
            {
                baseSyntax = this.resolver.Resolve<IBaseMemberSyntax>(source.Kind().ToString());
                if (clearComment)
                {
                    source = baseSyntax.ClearComment(source, level);
                }
                else
                {
                    source = baseSyntax.FixNode(source, level);
                }
            }
            catch (Exception ex)
            {
                ErrorLog.LogException(ex);
            }

            this.SwitchKind(source, isParentInterface);
        }

        /// <summary>
        /// The ClearComment
        /// </summary>
        /// <param name = "source">The <see cref = "MemberDeclarationSyntax"/></param>
        /// <param name = "isParentInterface">The <see cref = "bool "/></param>
        public void ClearComment(MemberDeclarationSyntax source, int level, bool isParentInterface = false)
        {
            this.Level = level;
            try
            {
                baseSyntax = this.resolver.Resolve<IBaseMemberSyntax>(source.Kind().ToString());
                source = baseSyntax.ClearComment(source, level);
            }
            catch (Exception ex)
            {
                ErrorLog.LogException(ex);
            }

            this.SwitchKind(source, isParentInterface);
        }


        #endregion

        #endregion
    }
}
