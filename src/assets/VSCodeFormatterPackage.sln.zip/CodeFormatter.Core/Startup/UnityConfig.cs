// <copyright file="UnityConfig.cs" company="Avanade">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>24-04-2018</date>

namespace CodeFormatter.Core.Startup
{
    using CodeFormatter.Common;
    using CodeFormatter.Common.Contracts;
    using CodeFormatter.Core;
    using CodeFormatter.Core.Syntaxs;
    using CodeFormatter.Core.Syntaxs.MemberGroups;
    using CodeFormatter.Core.Syntaxs.Statements;
    using CodeFormatter.Core.Syntaxs.TypeMembers;
    using CodeFormatter.Core.ViewModels.MemberGroups;
    using CodeFormatter.Core.ViewModels.Settings;
    using Microsoft.CodeAnalysis.CSharp;
    using Unity;

    /// <summary>
    /// Defines the <see cref = "UnityConfig"/>
    /// </summary>
    public static class UnityConfig
    {
        #region Properties

        /// <summary>
        /// Gets or sets the Container
        /// </summary>
        public static IUnityContainer Container { get; set; }

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// The RegisterTypes
        /// </summary>
        /// <param name = "container">The <see cref = "IUnityContainer"/></param>
        public static void RegisterTypes(IUnityContainer container)
        {
            Container = container;

            container.RegisterType<ClassMemberType>();
            //container.RegisterType<NamespaceMemberType>();
            container.RegisterType<CodeFileFormatter>();

            RegisterStatementSyntax(container);
            RegisterHeaderModifier(container);
            RegisterModels(container);
            RegisterViewModels(container);

            var settings = AppGlobal.GetDefaultSettings() ?? container.Resolve<DefaultSettingsViewModel>();
            container.RegisterInstance<IDefaultSettings>(settings);

            AppGlobal.FileHeaderSettings = AppGlobal.GetFileHeaderSettings() ?? Container.Resolve<FileHeaderViewModel>();
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// The RegisterHeaderModifier
        /// </summary>
        /// <param name = "container">The <see cref = "IUnityContainer"/></param>
        private static void RegisterHeaderModifier(IUnityContainer container)
        {
            //IEnumerable<Type> autoRootHeaderTypes = AllClasses.FromAssemblies(AppDomain.CurrentDomain.GetAssemblies()).Where(type => type != typeof(IBaseRootSyntax) && typeof(IBaseRootSyntax).IsAssignableFrom(type));
            //foreach (var autoHeaderType in autoRootHeaderTypes)
            //{
            //    container.RegisterType(typeof(IBaseRootSyntax), autoHeaderType, autoHeaderType.FullName, new ContainerControlledLifetimeManager(), new InjectionMember[0]);
            //}
            container.RegisterType<RootSyntax>();

            container.RegisterType<IBaseMemberSyntax, ClassTypeSyntax>(SyntaxKind.ClassDeclaration.ToString());
            container.RegisterType<IBaseMemberSyntax, InterfaceTypeSyntax>(SyntaxKind.InterfaceDeclaration.ToString());
            container.RegisterType<IBaseMemberSyntax, StructTypeSyntax>(SyntaxKind.StructDeclaration.ToString());
            container.RegisterType<IBaseMemberSyntax, EventSyntax>(SyntaxKind.EventFieldDeclaration.ToString());
            container.RegisterType<IBaseMemberSyntax, EnumSyntax>(SyntaxKind.EnumDeclaration.ToString());
            container.RegisterType<IBaseMemberSyntax, NamespaceSyntax>(SyntaxKind.NamespaceDeclaration.ToString());
            container.RegisterType<IBaseMemberSyntax, DelegateSyntax>(SyntaxKind.DelegateDeclaration.ToString());
            container.RegisterType<IBaseMemberSyntax, EventSyntax>(SyntaxKind.EventDeclaration.ToString());

            container.RegisterType<IBaseMemberSyntax, ConstructorSyntax>(SyntaxKind.ConstructorDeclaration.ToString());
            container.RegisterType<IBaseMemberSyntax, EnumSyntax>(SyntaxKind.EnumDeclaration.ToString());
            container.RegisterType<IBaseMemberSyntax, EnumMemberSyntax>(SyntaxKind.EnumMemberDeclaration.ToString());
            container.RegisterType<IBaseMemberSyntax, DelegateSyntax>(SyntaxKind.DelegateDeclaration.ToString());
            container.RegisterType<IBaseMemberSyntax, EventSyntax>(SyntaxKind.EventDeclaration.ToString());
            container.RegisterType<IBaseMemberSyntax, FieldSyntax>(SyntaxKind.FieldDeclaration.ToString());
            container.RegisterType<IBaseMemberSyntax, MethodSyntax>(SyntaxKind.MethodDeclaration.ToString());
            container.RegisterType<IBaseMemberSyntax, PropertySyntax>(SyntaxKind.PropertyDeclaration.ToString());
        }

        /// <summary>
        /// The RegisterModels
        /// </summary>
        /// <param name = "container">The <see cref = "IUnityContainer"/></param>
        private static void RegisterModels(IUnityContainer container)
        {
            container.RegisterType<TypeLayout>();
            //// IMemberGroup
            container.RegisterType<IMemberGroup, AndMemberGroupCollection>(Constants.And + Constants.Model);
            container.RegisterType<IMemberGroup, OrMemberGroupCollection>(Constants.Or + Constants.Model);
            container.RegisterType<IMemberGroup, MemberLayout>(Constants.Member + Constants.Model);
            //// ICondition
            container.RegisterType<ICondition, FindByKind>(Constants.Kind + Constants.Model);
            container.RegisterType<ICondition, FindByStatic>(Constants.IsStatic + Constants.Model);
            container.RegisterType<ICondition, FindByType>(Constants.Type + Constants.Model);
            container.RegisterType<ICondition, FindByAccessModifier>(Constants.AccessModifier + Constants.Model);
            //// ISort
            container.RegisterType<ISort, SortByModifier>(Constants.AccessModifier + Constants.Model);
            container.RegisterType<ISort, SortByName>(Constants.Name + Constants.Model);
            container.RegisterType<ISort, SortByReadOnly>(Constants.ReadOnly + Constants.Model);
            container.RegisterType<ISort, SortByStatic>(Constants.IsStatic + Constants.Model);
        }

        /// <summary>
        /// The RegisterStatementSyntax
        /// </summary>
        /// <param name="container">The <see cref="IUnityContainer"/></param>
        private static void RegisterStatementSyntax(IUnityContainer container)
        {
            container.RegisterType<IBaseStatementSyntax, LocalObjectStatement>(SyntaxKind.LocalDeclarationStatement.ToString());
            container.RegisterType<IBaseStatementSyntax, ReturnStatementFixer>(SyntaxKind.ReturnStatement.ToString());
            container.RegisterType<IBaseStatementSyntax, ExpressionStatementFixer>(SyntaxKind.ExpressionStatement.ToString());
        }

        /// <summary>
        /// The RegisterViewModels
        /// </summary>
        /// <param name = "container">The <see cref = "IUnityContainer"/></param>
        private static void RegisterViewModels(IUnityContainer container)
        {
            container.RegisterType<DefaultSettingsViewModel>();
            container.RegisterType<FileHeaderViewModel>();
            container.RegisterType<SettingsViewModel>();
            container.RegisterType<TypeLayoutViewModel>();
            //// IMemberGroupCollection
            container.RegisterType<IMemberGroupCollection, AndMemberGroupCollectionViewModel>(Constants.And + Constants.VM);
            container.RegisterType<IMemberGroupCollection, OrMemberGroupCollectionViewModel>(Constants.Or + Constants.VM);
            //// IMemberGroup
            container.RegisterType<IMemberGroup, AndMemberGroupCollectionViewModel>(Constants.And + Constants.VM);
            container.RegisterType<IMemberGroup, OrMemberGroupCollectionViewModel>(Constants.Or + Constants.VM);
            container.RegisterType<IMemberGroup, MemberLayoutViewModel>(Constants.Member + Constants.VM);
            //// ICondition
            container.RegisterType<ICondition, FindByKindViewModel>(Constants.Kind + Constants.VM);
            container.RegisterType<ICondition, FindByStaticViewModel>(Constants.IsStatic + Constants.VM);
            container.RegisterType<ICondition, FindByTypeViewModel>(Constants.Type + Constants.VM);
            container.RegisterType<ICondition, FindByAccessModifierViewModel>(Constants.AccessModifier + Constants.VM);
            //// ISort
            container.RegisterType<ISort, SortByModifierViewModel>(Constants.AccessModifier + Constants.VM);
            container.RegisterType<ISort, SortByNameViewModel>(Constants.Name + Constants.VM);
            container.RegisterType<ISort, SortByReadOnlyViewModel>(Constants.ReadOnly + Constants.VM);
            container.RegisterType<ISort, SortByStaticViewModel>(Constants.IsStatic + Constants.VM);
        }

        #endregion

        #endregion
    }
}
