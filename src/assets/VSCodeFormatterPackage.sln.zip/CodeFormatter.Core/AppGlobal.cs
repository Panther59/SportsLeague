// <copyright file="AppGlobal.cs" company="Accenture">
// Copyright (c) 2017 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>31-07-2017</date>

namespace CodeFormatter.Core
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Reflection;
    using CodeFormatter.Common.Contracts;
    using CodeFormatter.Core.Binders;
    using CodeFormatter.Core.Syntaxs.MemberGroups;
    using CodeFormatter.Core.ViewModels.MemberGroups;
    using CodeFormatter.Core.ViewModels.Settings;
    using Newtonsoft.Json;

    /// <summary>
    /// Defines the <see cref = "AppGlobal"/>
    /// </summary>
    public static class AppGlobal
    {
        #region Properties

        /// <summary>
        /// Gets the Indendation
        /// </summary>
        private static string Indendation
        {
            get
            {
                return "    ";
            }
        }

        public static string GetIndendation(int level)
        {
            string output = string.Empty;
            for (int i = 0; i < level; i++)
            {
                output += Indendation;
            }

            return output;
        }

        /// <summary>
        /// Gets or sets FileHeaderSettings
        /// </summary>
        public static IFileHeaderSettings FileHeaderSettings
        {
            get;
            set;
        }

        /// <summary>
        /// Gets the MemberRank
        /// </summary>
        public static List<KeyValuePair<string, int>> MemberRank
        {
            get
            {
                return new List<KeyValuePair<string, int>>()
                {new KeyValuePair<string, int>("Field", 0), new KeyValuePair<string, int>("Constructor", 2), new KeyValuePair<string, int>("Delegate", 4), new KeyValuePair<string, int>("Event", 6), new KeyValuePair<string, int>("Property", 8), new KeyValuePair<string, int>("Method", 10), new KeyValuePair<string, int>("Class", 12), new KeyValuePair<string, int>("Interface", 14), new KeyValuePair<string, int>("Unknown", 999), };
            }
        }

        /// <summary>
        /// Gets the ModifierRank
        /// </summary>
        public static List<KeyValuePair<string, int>> ModifierRank
        {
            get
            {
                return new List<KeyValuePair<string, int>>()
                {new KeyValuePair<string, int>("public", 0), new KeyValuePair<string, int>("internal", 2), new KeyValuePair<string, int>("protected internal", 4), new KeyValuePair<string, int>("protected", 6), new KeyValuePair<string, int>("private", 8), new KeyValuePair<string, int>("Unknown", 999), };
            }
        }

        /// <summary>
        /// Gets the FileHeaderFile
        /// </summary>
        public static string FileHeaderFile
        {
            get
            {
                return GetAppFolder() + "File Header.txt";
            }
        }

        /// <summary>
        /// Gets the TypeLayoutFile
        /// </summary>
        public static string TypeLayoutFile
        {
            get
            {
                return GetAppFolder() + "Type Layout.txt";
            }
        }

        /// <summary>
        /// Gets the DefaultSettingFile
        /// </summary>
        public static string DefaultSettingFile
        {
            get
            {
                return GetAppFolder() + "Default Settings.txt";
            }
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// The GetSavedLayoutFilePath
        /// </summary>
        /// <returns>The <see cref = "string "/></returns>
        public static string GetAppFolder()
        {
            var file = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\Ayvan\\Code Formatter\\";
            return file;
        }

        /// <summary>
        /// The GetDefaultLayoutFolderPath
        /// </summary>
        /// <returns>The <see cref = "string "/></returns>
        public static string GetDefaultLayoutFolderPath()
        {
            var dllPath = Assembly.GetExecutingAssembly().Location;
            var folderPath = Path.GetDirectoryName(dllPath);
            var folder = folderPath + "\\Layouts\\";
            return folder;
        }

        /// <summary>
        /// The GetDefaultSettings
        /// </summary>
        /// <returns>The <see cref = "DefaultSettingsViewModel"/></returns>
        public static DefaultSettingsViewModel GetDefaultSettings()
        {
            return GetSettings<DefaultSettingsViewModel>(DefaultSettingFile);
        }

        /// <summary>
        /// The GetFileHeaderSettings
        /// </summary>
        /// <returns>The <see cref = "FileHeaderViewModel"/></returns>
        public static FileHeaderViewModel GetFileHeaderSettings()
        {
            return GetSettings<FileHeaderViewModel>(FileHeaderFile);
        }

        /// <summary>
        /// The GetSettings
        /// </summary>
        /// <param name = "fileName">The <see cref = "string "/></param>
        /// <returns>The <see cref = "T"/></returns>
        public static T GetSettings<T>(string fileName)
        {
            if (File.Exists(fileName))
            {
                string json = File.ReadAllText(fileName);
                var obj = JsonConvert.DeserializeObject<T>(json);
                return obj;
            }
            else
            {
                return default(T);
            }
        }

        /// <summary>
        /// The GetTypeLayout
        /// </summary>
        /// <returns>The <see cref = "IMemberGroup"/></returns>
        public static IMemberGroup GetTypeLayout()
        {
            try
            {
                var file = TypeLayoutFile;
                FileInfo info = new FileInfo(file);
                if (info.Exists)
                {
                    string json = File.ReadAllText(file);
                    return GetTypeLayout(json);
                }
                else
                {
                    var defaultFilePath = GetDefaultLayoutFolderPath() + "\\DefaultWithRegion.txt";
                    FileInfo defInfo = new FileInfo(defaultFilePath);
                    if (defInfo.Exists)
                    {
                        string json = File.ReadAllText(file);
                        SaveTypeLayout(json);
                        return GetTypeLayout();
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// The GetTypeLayout
        /// </summary>
        /// <param name = "json">The <see cref = "string "/></param>
        /// <returns>The <see cref = "IMemberGroup"/></returns>
        public static IMemberGroup GetTypeLayout(string json)
        {
            var binder = new TypeNameSerializationBinder("CodeFormatter.Core.ViewModels.MemberGroups.{0}, CodeFormatter.Core");
            var obj = JsonConvert.DeserializeObject<AndMemberGroupCollectionViewModel>(json, new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.Auto, NullValueHandling = NullValueHandling.Ignore, SerializationBinder = binder });
            return obj;
        }

        /// <summary>
        /// The SaveDefaultSettings
        /// </summary>
        /// <param name = "input">The <see cref = "DefaultSettingsViewModel"/></param>
        public static void SaveDefaultSettings(DefaultSettingsViewModel input)
        {
            SaveSetting(DefaultSettingFile, input);
        }

        /// <summary>
        /// The SaveFileHeaderSettings
        /// </summary>
        /// <param name = "input">The <see cref = "FileHeaderViewModel"/></param>
        public static void SaveFileHeaderSettings(FileHeaderViewModel input)
        {
            SaveSetting(FileHeaderFile, input);
        }

        /// <summary>
        /// The SaveSetting
        /// </summary>
        /// <param name = "fileName">The <see cref = "string "/></param>
        /// <param name = "obj">The <see cref = "object "/></param>
        public static void SaveSetting(string fileName, object obj)
        {
            var json = JsonConvert.SerializeObject(obj);
            FileInfo info = new FileInfo(fileName);
            if (info.Directory.Exists == false)
            {
                Directory.CreateDirectory(info.Directory.FullName);
            }

            File.WriteAllText(fileName, json);
        }

        /// <summary>
        /// The SaveTypeLayout
        /// </summary>
        /// <param name = "input">The <see cref = "object "/></param>
        public static void SaveTypeLayout(object input)
        {
            var binder = new TypeNameSerializationBinder("CodeFormatter.Core.ViewModels.MemberGroups.{0}, CodeFormatter.Core");
            string json = JsonConvert.SerializeObject(input, Formatting.Indented, new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.Auto, NullValueHandling = NullValueHandling.Ignore, SerializationBinder = binder });
            SaveTypeLayout(json);
        }

        /// <summary>
        /// The SaveTypeLayout
        /// </summary>
        /// <param name = "content">The <see cref = "string "/></param>
        public static void SaveTypeLayout(string content)
        {
            FileInfo info = new FileInfo(TypeLayoutFile);
            if (info.Directory.Exists == false)
            {
                Directory.CreateDirectory(info.Directory.FullName);
            }

            File.WriteAllText(TypeLayoutFile, content);
        }

        #endregion

        #endregion
    }
}