namespace CodeFormatter.Core.Views.Settings
{
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for FileHeaderView.xaml
    /// </summary>
    public partial class FileHeaderView : UserControl
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="FileHeaderView"/> class.
        /// </summary>
        public FileHeaderView()
        {
            InitializeComponent();
        }

        #endregion
    }
}