namespace CodeFormatter.Core.Views.Settings
{
    using System;
    using System.Windows;
    using CodeFormatter.Common.Entities;
    using CodeFormatter.Core.ViewModels.Settings;

    /// <summary>
    /// Interaction logic for SettingsWindow.xaml
    /// </summary>
    public partial class SettingsWindow : Window
    {
        #region Fields

        #region Commands

        /// <summary>
        /// The closeCommand field
        /// </summary>
        private RelayCommand closeCommand;

        /// <summary>
        /// The saveCommand field
        /// </summary>
        private RelayCommand saveCommand;

        #endregion

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "SettingsWindow"/> class.
        /// </summary>
        public SettingsWindow()
        {
            InitializeComponent();
            this.Loaded += this.TypeLayoutWindow_Loaded;
        }

        #endregion

        #region Properties

        #region Commands

        /// <summary>
        /// Gets the CloseCommand
        /// </summary>
        public RelayCommand CloseCommand
        {
            get
            {
                if (this.closeCommand == null)
                {
                    this.closeCommand = new RelayCommand(command => this.ExecuteClose());
                }

                return this.closeCommand;
            }
        }

        /// <summary>
        /// Gets the SaveCommand
        /// </summary>
        public RelayCommand SaveCommand
        {
            get
            {
                if (this.saveCommand == null)
                {
                    this.saveCommand = new RelayCommand(command => this.ExecuteSave());
                }

                return this.saveCommand;
            }
        }

        #endregion

        #endregion

        #region Methods

        #region Private Methods

        /// <summary>
        /// Executes Close
        /// </summary>
        private void ExecuteClose()
        {
            this.Close();
        }

        /// <summary>
        /// Executes Save
        /// </summary>
        private void ExecuteSave()
        {
            var vm = this.Settings.DataContext as SettingsViewModel;
            if (vm != null)
            {
                try
                {
                    vm.SaveSettings();
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        /// <summary>
        /// The TypeLayoutWindow_Loaded
        /// </summary>
        /// <param name="sender">The <see cref="object"/></param>
        /// <param name="e">The <see cref="RoutedEventArgs"/></param>
        private void TypeLayoutWindow_Loaded(object sender, RoutedEventArgs e)
        {
            this.DataContext = this;
        }

        #endregion

        #endregion
    }
}