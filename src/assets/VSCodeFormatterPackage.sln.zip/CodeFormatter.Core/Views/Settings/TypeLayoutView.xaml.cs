namespace CodeFormatter.Core.Views.Settings
{
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for TypeLayoutView.xaml
    /// </summary>
    public partial class TypeLayoutView : UserControl
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "TypeLayoutView"/> class.
        /// </summary>
        public TypeLayoutView()
        {
            InitializeComponent();
        }

        #endregion
    }
}