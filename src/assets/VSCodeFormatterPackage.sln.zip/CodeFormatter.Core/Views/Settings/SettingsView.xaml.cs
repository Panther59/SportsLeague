﻿// <copyright file="SettingsView.xaml.cs" company="Avanade">
// Copyright (c) 2018 All Rights Reserved
// </copyright>
// <author>DIR\utkarsh.chauhan</author>
// <date>24-04-2018</date>

namespace CodeFormatter.Core.Views.Settings
{
    using System.Windows.Controls;
    using CodeFormatter.Core.Startup;
    using CodeFormatter.Core.ViewModels.Settings;
    using Unity;

    /// <summary>
    /// Interaction logic for SettingsView.xaml
    /// </summary>
    public partial class SettingsView : UserControl
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "SettingsView"/> class.
        /// </summary>
        public SettingsView()
        {
            InitializeComponent();
            this.Loaded += this.SettingsView_Loaded;
        }

        #endregion

        #region Methods

        #region Private Methods

        /// <summary>
        /// The SettingsView_Loaded
        /// </summary>
        /// <param name="sender">The <see cref="object"/></param>
        /// <param name="e">The <see cref="System.Windows.RoutedEventArgs"/></param>
        private void SettingsView_Loaded(object sender, System.Windows.RoutedEventArgs e)
        {
            if (UnityConfig.Container != null)
            {
                this.DataContext = UnityConfig.Container.Resolve<SettingsViewModel>();
            }
        }

        #endregion

        #endregion
    }
}
