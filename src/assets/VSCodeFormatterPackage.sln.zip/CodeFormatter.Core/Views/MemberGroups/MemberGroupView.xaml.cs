namespace CodeFormatter.Core.Views.MemberGroups
{
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for MemberGroupView.xaml
    /// </summary>
    public partial class MemberGroupView : UserControl
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref = "MemberGroupView"/> class.
        /// </summary>
        public MemberGroupView()
        {
            InitializeComponent();
        }

        #endregion
    }
}
