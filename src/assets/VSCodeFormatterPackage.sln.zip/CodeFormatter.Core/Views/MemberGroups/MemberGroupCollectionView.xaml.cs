namespace CodeFormatter.Core.Views.MemberGroups
{
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for MemberGroupCollectionView.xaml
    /// </summary>
    public partial class MemberGroupCollectionView : UserControl
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="MemberGroupCollectionView"/> class.
        /// </summary>
        public MemberGroupCollectionView()
        {
            InitializeComponent();
        }

        #endregion
    }
}
