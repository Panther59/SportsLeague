﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Accenture.ZephyrExtentions.IMapperUnitTestAutomation info = new Accenture.ZephyrExtentions.IMapperUnitTestAutomation();
            //info.FindClassDetail(@"C:\Breeze\bDEV\Features\16.1\AppTier\BestBuy.Zephyr\BestBuy.Zephyr.Mappings\CACustomerServices\FromZephyr\PhoneToPhoneTypeMapper.cs");
        }
    }
}
