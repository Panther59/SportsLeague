﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZephyrExtentions
{
    public static class AppGlobal
    {
        public static List<UnitTestAutomationCategory> SampleFileSets
        {
            get
            {
                return new List<UnitTestAutomationCategory>()
                {
                    new UnitTestAutomationCategory() { Category = Category.DtoAndEntityIMapper,
                         SampleFiles = new List<SampleFile>
                         {
                            new SampleFile() { FilePath = AppGlobal.ExtensionOutputFolder + @"\SampleFiles\DtoAndEntityIMapper\BaseAtoBMapperTest.txt", FileName = "@baseTestName@.cs" },
                            new SampleFile() { FilePath = AppGlobal.ExtensionOutputFolder + @"\SampleFiles\DtoAndEntityIMapper\ConstructorNullArgumentTest.txt", FileName = "ConstructorNullArgumentTest.cs" },
                            new SampleFile() { FilePath = AppGlobal.ExtensionOutputFolder + @"\SampleFiles\DtoAndEntityIMapper\MapNullDestinationArgumentTest.txt", FileName = "MapNullDestinationArgumentTest.cs" },
                            new SampleFile() { FilePath = AppGlobal.ExtensionOutputFolder + @"\SampleFiles\DtoAndEntityIMapper\MapNullSourceArgumentTest.txt", FileName = "MapNullSourceArgumentTest.cs" },
                            new SampleFile() { FilePath = AppGlobal.ExtensionOutputFolder + @"\SampleFiles\DtoAndEntityIMapper\MapSuccessTest.txt", FileName = "MapSuccessTest.cs" }
                         }},
                        
                         new UnitTestAutomationCategory() { Category = Category.ModelAndEntityIMapper,
                         SampleFiles = new List<SampleFile>
                         {
                            new SampleFile() { FilePath = AppGlobal.ExtensionOutputFolder + @"\SampleFiles\ModelAndEntityIMapper\BaseAtoBMapperTest.txt", FileName = "@baseTestName@.cs" },
                            new SampleFile() { FilePath = AppGlobal.ExtensionOutputFolder + @"\SampleFiles\ModelAndEntityIMapper\MapNullDestinationArgumentTest.txt", FileName = "MapNullDestinationArgumentTest.cs" },
                            new SampleFile() { FilePath = AppGlobal.ExtensionOutputFolder + @"\SampleFiles\ModelAndEntityIMapper\MapNullSourceArgumentTest.txt", FileName = "MapNullSourceArgumentTest.cs" },
                            new SampleFile() { FilePath = AppGlobal.ExtensionOutputFolder + @"\SampleFiles\ModelAndEntityIMapper\MapSuccessTest.txt", FileName = "MapSuccessTest.cs" }
                         }}
                };
            }
        }

        public static List<SampleFile> GetSampleFiles(Category category)
        {
            return SampleFileSets.Where(x => x.Category == category).First().SampleFiles;
        }

        public static string ExtensionOutputFolder { get; set; }

        public static string ZephyrRootPath { get; set; }
    }
    public class UnitTestAutomationCategory
    {
        public Category Category { get; set; }
        public List<SampleFile> SampleFiles { get; set; }
    }

    public class SampleFile
    {
        public string FilePath { get; set; }
        public string FileName { get; set; }
    }

    public class OutputFile
    {
        public string FilePath { get; set; }
        public string FileName { get; set; }
        public bool Existing { get; set; }
    }

    public enum Category
    {
        DtoAndEntityIMapper,
        ModelAndEntityIMapper
    }
}
