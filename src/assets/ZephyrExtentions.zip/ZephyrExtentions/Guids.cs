﻿// Guids.cs
// MUST match guids.h
using System;

namespace ZephyrExtentions
{
    static class GuidList
    {
        public const string guidZephyrExtentionsPkgString = "a3988712-41ad-42c6-8226-58df00d86ed1";
        public const string guidZephyrExtentionsCmdSetString = "01a7efe4-564d-4e9b-b863-16da113a6aec";

        public static readonly Guid guidZephyrExtentionsCmdSet = new Guid(guidZephyrExtentionsCmdSetString);
    };
}