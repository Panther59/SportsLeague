﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Accenture.ZephyrExtentions
{
    /// <summary>
    /// Interaction logic for AddIMapperUnitTestsWindow.xaml
    /// </summary>
    public partial class AddIMapperUnitTestsWindow : Window
    {
        private string outputFolderPath;
        public AddIMapperUnitTestsWindow()
        {
            InitializeComponent();
        }

        public AddIMapperUnitTestsWindow(string outputFolderPath)
            : this()
        {
            this.outputFolderPath = outputFolderPath;
        }

        private void btnBrowse_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.InitialDirectory = outputFolderPath;
            fileDialog.Multiselect = false;
            fileDialog.Filter = "Class files (*.cs)|*.cs";
            bool? res = fileDialog.ShowDialog();
            if (res.HasValue && res.Value)
            {
                txtPath.Text = fileDialog.FileName;
            }

        }

        private void btnGenerate_Click(object sender, RoutedEventArgs e)
        {
            string classText = ReadClassFile(txtPath.Text);
            //IMapperUnitTestAutomation info = new IMapperUnitTestAutomation();
            //info.FindClassDetail(txtPath.Text);
        }

        private string ReadClassFile(string filePath)
        {
            return System.IO.File.ReadAllText(filePath);
        }
    }
}
