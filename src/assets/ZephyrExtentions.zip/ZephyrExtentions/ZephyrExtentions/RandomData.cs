﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Accenture.ZephyrExtentions
{
    /// <summary>
    /// Generates Random data
    /// </summary>
    public static class RandomData
    {
        private static Random random = new Random((int)DateTime.Now.Ticks);

        /// <summary>
        /// Generates Random string
        /// </summary>
        /// <param name="size">Lenght of the string expected</param>
        /// <returns>random string</returns>
        public static string RandomString(int size)
        {
            StringBuilder builder = new StringBuilder();
            char ch;
            for (int i = 0; i < size; i++)
            {
                ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));
                builder.Append(ch);
            }

            return builder.ToString();
        }

        /// <summary>
        /// Generates Random integer string
        /// </summary>
        /// <param name="size">Lenght of the integer expected</param>
        /// <returns>Random Integer string</returns>
        public static string RandomInteger(int size)
        {
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < size; i++)
            {
                builder.Append(random.Next(0, 9));
            }

            return builder.ToString();
        }

        /// <summary>
        /// Generates Random Decimal string
        /// </summary>
        /// <param name="size">Lenght of the string expected</param>
        /// <returns>Random decimal number string</returns>
        public static string RandomDecimal(int size)
        {
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < size; i++)
            {
                builder.Append(random.Next(0, 9));
            }

            builder.Append(".");
            builder.Append(random.Next(0, 9));
            builder.Append(random.Next(0, 9));

            return builder.ToString();
        }

        /// <summary>
        /// Generates Random Date and time string
        /// </summary>
        /// <returns>Random DateTie string</returns>
        public static string RandomDateTime()
        {
            int day = random.Next(1, 28);
            int month = random.Next(1, 12);
            int year = random.Next(1990, 2020);

            string date = string.Format("{0}/{1}/{2}", month, day, year);
            return date;
        }


        /// <summary>
        /// Ganarates Random Boolean string
        /// </summary>
        /// <returns>Boolean string</returns>
        public static string RandomBoolean()
        {
            int randNum = random.Next(0, 1);
            if (randNum == 0)
            {
                return "true";
            }
            else
            {
                return "false";
            }
        }
    }
}
