﻿//-----------------------------------------------------------------------
// <copyright file="MapSuccessTest.cs" company="Best Buy">
//     Copyright (c) Best Buy. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace @nameSpace@
{
    using BestBuy.Zephyr.Domain.Entities;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Defines the MapSuccessTest type
    /// </summary>
    [TestClass]
    public class MapSuccessTest : @baseTestName@
    {
        /// <summary>
        /// Then result is not null
        /// </summary>
        [TestCategory(TestCategory), TestMethod]
        public void ThenResultIsNotNull()
        {
            this.ThenResultIsNotNull(this.Result);
        }

        /// <summary>
        /// Then BaseMapper Map called once
        /// </summary>
        [TestCategory(TestCategory), TestMethod]
        public void ThenBaseMapperMapCalledOnce()
        {
            this.ThenBaseMapperMapCalled(1);
        }@destinationMapTestText@
                
        /// <inheritdoc />
        protected override void When()
        {
            base.When();

            var input = new @sourceNameSpace@.@sourceType@()
            {
                @sourceTypeInitializeText@
            };

            this.Result = new @destinationNameSpace@.@destinationType@();

            this.Subject.Map(input, this.Result);
        }
    }
}