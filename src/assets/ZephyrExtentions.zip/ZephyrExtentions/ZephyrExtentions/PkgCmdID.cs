﻿// PkgCmdID.cs
// MUST match PkgCmdID.h
using System;

namespace Accenture.ZephyrExtentions
{
    static class PkgCmdIDList
    {
        public const uint cmdidCreateIMapperUnitTests =        0x100;


    };
}