﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using Roslyn.Compilers.CSharp;
using System.Linq;
using System;
using System.Text;

namespace Accenture.ZephyrExtentions
{
    public class IMapperUnitTestAutomation
    {
        private string zephyrRootPath;
        private List<PropertyInfo> sourcePropertyList;
        private List<PropertyInfo> destinationPropertyList;
        private Category category;

        #region Replacement Properties

        public string BaseTestName { get; set; }
        public string NameSpace { get; set; }
        public string InputName { get; set; }
        public string InputNameSpace { get; set; }
        public string TestCategory { get; set; }
        public string BaseSourceType { get; set; }
        public string BaseDestinationType { get; set; }
        public string SourceType { get; set; }
        public string DestinationType { get; set; }
        public string TestDataText { get; set; }
        public string SourceTypeInitializeText { get; set; }
        public string DestinationMapTestText { get; set; }
        public string SourceNameSpace { get; set; }
        public string DestinationNameSpace { get; set; }

        #endregion

        public List<OutputFile> OutputFilesPath { get; set; }

        public void FindClassDetail(string path, List<string> refFiles)
        {
            /// Get syntax tree of the file using file path.
            var output = SyntaxTree.ParseFile(path);

            /// Start with root to go down in the syntax tree
            var root = output.GetRoot();

            /// Identify namepsaces in the files
            var namespaceList = root.DescendantNodes();
            var namespaces = namespaceList.Where(x => x.Kind == SyntaxKind.NamespaceDeclaration).First();
            string namesspaceOfFile = ((Roslyn.Compilers.CSharp.NamespaceDeclarationSyntax)(namespaces)).Name.ToFullString().Trim();

            //Type type = assm.GetType(
            var namespacestring = namespaces.GetText();
            Roslyn.Compilers.CSharp.NamespaceDeclarationSyntax nameSpaceOut = namespaces as Roslyn.Compilers.CSharp.NamespaceDeclarationSyntax;
            foreach (Roslyn.Compilers.CSharp.ClassDeclarationSyntax classtype in nameSpaceOut.Members)
            {
                this.InputNameSpace = namesspaceOfFile;
                this.InputName = classtype.Identifier.ValueText;
                this.BaseTestName = string.Format("Base{0}Test", this.InputName);
                this.TestCategory = (namesspaceOfFile + "." + this.InputName).Replace("BestBuy.Zephyr.", "");
                this.NameSpace = "BestBuy.Zephyr.Tests.UnitTests." + this.TestCategory;
                var deriverInterface = classtype.BaseList.Types.First().DescendantNodes().Where(x => x.Kind == SyntaxKind.IdentifierName);
                if (deriverInterface.Count() == 2)
                {
                    zephyrRootPath = GetParentDirUsinfFile(path, "BestBuy.Zephyr");

                    this.SourceType = ((Roslyn.Compilers.CSharp.IdentifierNameSyntax)(deriverInterface.First())).Identifier.ValueText;
                    ClassInfo sourInfo = FindClassInfo(this.SourceType);
                    if (sourInfo.Exists)
                    {
                        this.sourcePropertyList = sourInfo.Properties;
                        this.SourceNameSpace = sourInfo.NameSpace;
                        this.BaseSourceType = sourInfo.BaseDestination;
                    }
                    else
                    {
                        sourInfo = FindClassInReferenceClasses(this.SourceType, refFiles);
                        if (sourInfo.Exists)
                        {
                            this.sourcePropertyList = sourInfo.Properties;
                            this.SourceNameSpace = sourInfo.NameSpace;
                            this.BaseSourceType = sourInfo.BaseDestination;
                        }
                    }

                    this.DestinationType = ((Roslyn.Compilers.CSharp.IdentifierNameSyntax)(deriverInterface.Last())).Identifier.ValueText;
                    ClassInfo destInfo = FindClassInfo(this.DestinationType);
                    if (destInfo.Exists)
                    {
                        this.destinationPropertyList = destInfo.Properties;
                        this.DestinationNameSpace = destInfo.NameSpace;
                        this.BaseDestinationType = destInfo.BaseDestination;
                    }
                    else
                    {
                        destInfo = FindClassInReferenceClasses(this.DestinationType, refFiles);
                        if (destInfo.Exists)
                        {
                            this.destinationPropertyList = destInfo.Properties;
                            this.DestinationNameSpace = destInfo.NameSpace;
                            this.BaseDestinationType = destInfo.BaseDestination;
                        }
                    }

                    if (sourInfo.Exists && destInfo.Exists)
                    {
                        GenerateTestDataText();
                        GenerateSourceTypeInitializeText();
                        GenerateDestinationMapTestText();

                        GenerateOutputFiles();
                    }
                    else
                    {
                        throw new Exception("Unable to find class information");
                    }
                }
            }
        }

        private ClassInfo FindClassInReferenceClasses(string type, List<string> refFiles)
        {
            foreach (string file in refFiles)
            {
                ClassInfo info = FindClassInfo(type, file, true);
                if (info.Exists)
                {
                    return info;
                }
            }
            return null;
        }

        private void SearchReferenceFiles()
        {
            //"BestBuy.Zephyr.Services.ServiceLibrary"
        }

        /// <summary>
        /// Identifies which type of Sample to use and creates files
        /// </summary>
        private void GenerateOutputFiles()
        {
            if (this.BaseDestinationType != null && this.BaseSourceType != null)
            {
                this.category = Category.DtoAndEntityIMapper;
            }
            else
            {
                this.category = Category.ModelAndEntityIMapper;
            }

            List<SampleFile> smapleFiles = AppGlobal.GetSampleFiles(this.category);

            DirectoryInfo baseDirInfo = new DirectoryInfo(zephyrRootPath);
            var testProjectDirInfo = baseDirInfo.GetDirectories().Where(x => this.NameSpace.StartsWith(x.Name)).FirstOrDefault();
            string outputFolderPath = testProjectDirInfo.FullName + this.NameSpace.Replace(testProjectDirInfo.Name, "").Replace(".", "\\");

            DirectoryInfo dirInfo = new DirectoryInfo(outputFolderPath);
            if (dirInfo.Exists == false)
            {
                dirInfo.Create();
            }

            OutputFilesPath = new List<OutputFile>();
            foreach (SampleFile file in smapleFiles)
            {
                var outFile = new OutputFile();

                string outFileData = System.IO.File.ReadAllText(file.FilePath);
                outFileData = PerformReplace(outFileData);
                string outfileName = PerformReplace(file.FileName);
                string outputTestFilePath = outputFolderPath + "\\" + outfileName;
                if (File.Exists(outputTestFilePath) == false)
                {
                    File.WriteAllText(outputTestFilePath, outFileData);
                }
                else
                {
                    outFile.Existing = true;
                }
                outFile.FileName = outfileName;
                outFile.FilePath = outputTestFilePath;

                OutputFilesPath.Add(outFile);
            }
        }

        private void GenerateTestDataText()
        {
            StringBuilder sb = new StringBuilder();

            if (sourcePropertyList != null)
            {
                List<PropertyInfo> props = new List<PropertyInfo>();
                foreach (var prop in sourcePropertyList.Where(x => x.DataType != PropertyDataType.ComplexType))
                {
                    props.AddRange(GetProps(prop));
                }

                //remove duplicate
                props = props.Distinct().ToList();

                foreach (var prop in props.Where(x => x.DataType != PropertyDataType.DateTime))
                {
                    sb.Append(TestDataBasedOnProperty(prop));
                }

                foreach (var prop in props.Where(x => x.DataType == PropertyDataType.DateTime))
                {
                    sb.Append(TestDataBasedOnProperty(prop));
                }
            }
            this.TestDataText = sb.ToString().Trim();
        }

        private List<PropertyInfo> GetProps(PropertyInfo inpprop)
        {
            List<PropertyInfo> props = new List<PropertyInfo>();
            if (inpprop.DataType == PropertyDataType.ComplexType &&
                inpprop.DataTypeInfo != null &&
                inpprop.DataTypeInfo.Properties != null &&
                inpprop.DataTypeInfo.Properties.Count > 0)
            {
                foreach (var prop in inpprop.DataTypeInfo.Properties)
                {
                    props.AddRange(GetProps(prop));
                }
            }
            else
            {
                props.Add(inpprop);
            }
            return props;
        }

        private void GenerateSourceTypeInitializeText()
        {
            StringBuilder sbInit = new StringBuilder();

            if (sourcePropertyList != null)
            {
                List<PropertyInfo> props = new List<PropertyInfo>();
                foreach (var prop in sourcePropertyList.Where(x => x.DataType != PropertyDataType.ComplexType))
                {
                    props.AddRange(GetProps(prop));
                }

                //remove duplicate
                props = props.Distinct().ToList();

                foreach (var prop in props)
                {
                    if (sbInit.ToString() != string.Empty)
                    {
                        sbInit.AppendLine(",");
                    }
                    sbInit.Append(string.Format("{0} = TestData.{0}", prop.Name));
                }
            }

            this.SourceTypeInitializeText = sbInit.ToString();
        }

        private void GenerateDestinationMapTestText()
        {
            StringBuilder sb = new StringBuilder();
            if (destinationPropertyList != null)
            {
                foreach (var prop in destinationPropertyList.Where(d => sourcePropertyList.Any(s => s.Name == d.Name)))
                {
                    sb.Append(MapPropertyTestMethodText(prop.Name));
                }
            }
            this.DestinationMapTestText = sb.ToString();
        }

        private string PerformReplace(string input)
        {
            string output = input
                .Replace("@baseTestName@", this.BaseTestName)
                .Replace("@nameSpace@", this.NameSpace)
                .Replace("@inputName@", this.InputName)
                .Replace("@inputNameSpace@", this.InputNameSpace)
                .Replace("@testCategory@", this.TestCategory)
                .Replace("@baseSourceType@", this.BaseSourceType)
                .Replace("@baseDestinationType@", this.BaseDestinationType)
                .Replace("@sourceType@", this.SourceType)
                .Replace("@sourceTypeInitializeText@", this.SourceTypeInitializeText)
                .Replace("@destinationType@", this.DestinationType)
                .Replace("@testDataText@", this.TestDataText)
                .Replace("@destinationMapTestText@", this.DestinationMapTestText)
                .Replace("@sourceNameSpace@", this.SourceNameSpace)
                .Replace("@destinationNameSpace@", this.DestinationNameSpace);

            return output;
        }

        private void FindSourceData(string sourceTypeFilePath)
        {
            var output = SyntaxTree.ParseFile(sourceTypeFilePath);

            var root = output.GetRoot();

            var classlist = root.DescendantNodes();
            var namespaces = classlist.Where(x => x.Kind == SyntaxKind.NamespaceDeclaration).First();
            this.SourceNameSpace = ((Roslyn.Compilers.CSharp.NamespaceDeclarationSyntax)(namespaces)).Name.ToFullString().Trim();
            var namespacestring = namespaces.GetText();
            Roslyn.Compilers.CSharp.NamespaceDeclarationSyntax nameSpaceOut = namespaces as Roslyn.Compilers.CSharp.NamespaceDeclarationSyntax;

            foreach (Roslyn.Compilers.CSharp.ClassDeclarationSyntax classtype in nameSpaceOut.Members.Where(x => ((x is Roslyn.Compilers.CSharp.ClassDeclarationSyntax) && ((Roslyn.Compilers.CSharp.ClassDeclarationSyntax)x).Identifier.ValueText == this.SourceType)))
            {
                string className = classtype.Identifier.ValueText;
                if (classtype.BaseList != null)
                {
                    var deriverInterface = classtype.BaseList.DescendantNodes().Where(x => x.Kind == SyntaxKind.IdentifierName);
                    if (deriverInterface.Count() == 1)
                    {
                        this.BaseSourceType = ((Roslyn.Compilers.CSharp.IdentifierNameSyntax)(deriverInterface.First())).Identifier.ValueText;
                    }
                }
                sourcePropertyList = new List<PropertyInfo>();
                foreach (Roslyn.Compilers.CSharp.PropertyDeclarationSyntax item in classtype.Members.Where(x => x is Roslyn.Compilers.CSharp.PropertyDeclarationSyntax))
                {
                    PropertyInfo info = new PropertyInfo();
                    info.Name = item.Identifier.ValueText;
                    info.DataTypeText = item.Type.ToString();
                    info.DataType = GetDataType(item.Type.ToString());

                    sourcePropertyList.Add(info);
                }
            }
        }

        private string MapPropertyTestMethodText(string propName)
        {
            string input = @"
        
        /// <summary>
        /// Then @propName@ is mapped
        /// </summary>
        [TestCategory(TestCategory), TestMethod]
        public void Then@propName@IsMapped()
        {
            Assert.AreEqual(TestData.@propName@, this.Result.@propName@);
        }";

            return input.Replace("@propName@", propName);
        }

        private string TestDataBasedOnProperty(PropertyInfo propInfo)
        {
            string type = null;
            string name = propInfo.Name;
            string dummyValue = GetRandomValue(propInfo.DataType);

            switch (propInfo.DataType)
            {
                case PropertyDataType.Integer:
                    type = "int";
                    return TestDataReplacement(name, dummyValue, type);
                case PropertyDataType.String:
                    type = "string";
                    return TestDataReplacement(name, dummyValue, type);
                case PropertyDataType.DateTime:
                    type = "DateTime";
                    return TestDataReplacementForDateTime(name, dummyValue, type);
                case PropertyDataType.Decimal:
                    type = "decimal";
                    return TestDataReplacement(name, dummyValue, type);
                case PropertyDataType.Float:
                    type = "float";
                    return TestDataReplacement(name, dummyValue, type);
                case PropertyDataType.Enum:
                    type = propInfo.DataTypeText;
                    return TestDataReplacement(name, dummyValue, type);
                case PropertyDataType.ComplexType:
                    type = propInfo.DataTypeText;
                    return TestDataReplacement(name, dummyValue, type);
                default:
                    type = propInfo.DataTypeText;
                    return TestDataReplacement(name, dummyValue, type);
            }


        }

        private string GetRandomValue(PropertyDataType propertyDataType)
        {
            switch (propertyDataType)
            {
                case PropertyDataType.Bool:
                    return RandomData.RandomBoolean();
                case PropertyDataType.Integer:
                    return RandomData.RandomInteger(3);
                case PropertyDataType.String:
                    return @"""" + RandomData.RandomString(4) + @"""";
                case PropertyDataType.DateTime:
                    return @"""" + RandomData.RandomDateTime() + @"""";
                case PropertyDataType.Decimal:
                    return RandomData.RandomDecimal(3);
                case PropertyDataType.Float:
                    return RandomData.RandomDecimal(3);
                case PropertyDataType.Enum:
                    return "TODO";
                case PropertyDataType.ComplexType:
                default:
                    return "null";
            }
        }

        private string TestDataReplacement(string propName, string propValue, string propType)
        {
            string input = @"

            /// <summary>
            /// The @propName@
            /// </summary>
            public const @propType@ @propName@ = @propValue@;";

            return input
                .Replace("@propName@", propName)
                .Replace("@propValue@", propValue)
                .Replace("@propType@", propType);
        }

        private string TestDataReplacementForDateTime(string propName, string propValue, string propType)
        {
            string input = @"

            /// <summary>
            /// Gets @propName@
            /// </summary>
            public static @propType@ @propName@
            {
                get
                {
                    return DateTime.Parse(""@propValue@"");
                }
            }";

            return input
                .Replace("@propName@", propName)
                .Replace("@propValue@", propValue)
                .Replace("@propType@", propType);
        }

        private PropertyDataType GetDataType(string inputtype)
        {
            switch (inputtype.ToString().ToLower())
            {
                case "bool":
                    return PropertyDataType.Bool;
                case "string":
                    return PropertyDataType.String;
                case "datetime":
                    return PropertyDataType.DateTime;
                case "int":
                    return PropertyDataType.Integer;
                case "float":
                    return PropertyDataType.Float;
                default:
                    return PropertyDataType.ComplexType;
            }
        }

        public class ClassInfo
        {
            public string Name { get; set; }
            public string FilePath { get; set; }
            public string NameSpace { get; set; }
            public List<PropertyInfo> Properties { get; set; }
            public bool Exists { get; set; }
            public string BaseDestination { get; set; }
        }

        private ClassInfo FindClassInfo(string className, string filePath, bool mergerBaseProp = false)
        {
            ClassInfo classInfo = new ClassInfo();
            classInfo.Name = className;

            var destinationFilePath = filePath;
            classInfo.FilePath = destinationFilePath;

            if (File.Exists(destinationFilePath))
            {
                var output = SyntaxTree.ParseFile(destinationFilePath);

                var root = output.GetRoot();

                var classlist = root.DescendantNodes();
                var namespaces = classlist.Where(x => x.Kind == SyntaxKind.NamespaceDeclaration).First();
                //this.DestinationNameSpace = ((Roslyn.Compilers.CSharp.NamespaceDeclarationSyntax)(namespaces)).Name.ToFullString().Trim();
                classInfo.NameSpace = ((Roslyn.Compilers.CSharp.NamespaceDeclarationSyntax)(namespaces)).Name.ToFullString().Trim();
                var namespacestring = namespaces.GetText();
                Roslyn.Compilers.CSharp.NamespaceDeclarationSyntax nameSpaceOut = namespaces as Roslyn.Compilers.CSharp.NamespaceDeclarationSyntax;

                foreach (Roslyn.Compilers.CSharp.ClassDeclarationSyntax classtype in
                    nameSpaceOut.Members
                    .Where(x => ((x is Roslyn.Compilers.CSharp.ClassDeclarationSyntax)
                        && ((Roslyn.Compilers.CSharp.ClassDeclarationSyntax)x).Identifier.ValueText == className)))
                {
                    classInfo.Exists = true;
                    
                    classInfo.Properties = new List<PropertyInfo>();
                    foreach (Roslyn.Compilers.CSharp.PropertyDeclarationSyntax item in classtype.Members.Where(x => x is Roslyn.Compilers.CSharp.PropertyDeclarationSyntax))
                    {
                        PropertyInfo info = new PropertyInfo();
                        info.Name = item.Identifier.ValueText;
                        info.DataTypeText = item.Type.ToString();
                        if (item.Type.Kind == SyntaxKind.IdentifierName)
                        {
                            info.DataType = GetDataType(item.Type.ToString());
                        }
                        else if (item.Type.Kind == SyntaxKind.QualifiedName)
                        {
                            info.DataType = GetDataType((item.Type as QualifiedNameSyntax).Right.ToString());
                        }
                        else
                        {
                            info.DataType = PropertyDataType.ComplexType;
                        }

                        info.DataType = GetDataType(item.Type.ToString());
                        ClassInfo propInfo = null;
                        if (info.DataType == PropertyDataType.ComplexType && mergerBaseProp)
                        {
                            propInfo = FindClassInfo(info.DataTypeText, filePath, mergerBaseProp);
                        }
                        else
                        {
                            propInfo = FindClassInfo(info.DataTypeText);
                        }

                        if(propInfo != null && propInfo.Exists)
                        {
                            info.DataTypeInfo = propInfo;
                        }

                        classInfo.Properties.Add(info);
                    }

                    if (classtype.BaseList != null)
                    {
                        var deriverInterface = classtype.BaseList.DescendantNodes().Where(x => x.Kind == SyntaxKind.IdentifierName);
                        if (deriverInterface.Count() == 1)
                        {
                            string baseName = ((Roslyn.Compilers.CSharp.IdentifierNameSyntax)(deriverInterface.First())).Identifier.ValueText;
                            if (mergerBaseProp)
                            {
                                ClassInfo baseClassInfo = FindClassInfo(baseName, destinationFilePath, true);
                                classInfo.Properties.AddRange(baseClassInfo.Properties);
                                classInfo.BaseDestination = null; //Marking it null since we dont want map base classes
                            }
                            else
                            {
                                classInfo.BaseDestination = baseName;
                            }
                        }
                    }

                    
                }
            }
            return classInfo;
        }

        private ClassInfo FindClassInfo(string className)
        {
            var destinationFilePath = FindFileForClass(zephyrRootPath, className);
            return FindClassInfo(className, destinationFilePath);
        }

        private string FindFileForClass(string dir, string className)
        {
            return DirSearch(dir, className, "*.cs");
        }

        private string DirSearch(string dir, string className, string pattern)
        {
            string path = null;
            try
            {
                foreach (string d in Directory.GetDirectories(dir))
                {
                    foreach (string f in Directory.GetFiles(d, pattern))
                    {
                        FileInfo fileinfo = new FileInfo(f);
                        if (fileinfo.Name.ToLower() == className.ToLower() + ".cs")
                        {
                            path = f;
                        }
                    }
                    if (path != null)
                    {
                        return path;
                    }
                    path = DirSearch(d, className, pattern);
                    if (path != null)
                    {
                        return path;
                    }
                }
                return null;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Something unexpected happened: {0}", ex);
                return null;
            }
        }

        private string GetParentDirUsinfFile(string currPath, string searchPath)
        {
            FileInfo info = new FileInfo(currPath);
            if (info.Exists && info.Directory != null)
            {
                return GetParentDir(info.Directory.ToString(), searchPath);
            }
            else
            {
                return null;
            }
        }

        private string GetParentDir(string currPath, string searchPath)
        {
            DirectoryInfo info = new DirectoryInfo(currPath);
            if (info.Exists && info.Parent != null)
            {
                if (info.Parent.ToString() == searchPath)
                {
                    return info.Parent.FullName;
                }
                else
                {
                    return GetParentDir(info.Parent.FullName, searchPath);
                }
            }
            else
            {
                return null;
            }
        }

    }

    public class PropertyInfo
    {
        public PropertyDataType DataType { get; set; }
        public string Name { get; set; }
        public string DataTypeText { get; set; }

        public IMapperUnitTestAutomation.ClassInfo DataTypeInfo { get; set; }
    }

    public enum PropertyDataType
    {
        Bool,
        Integer,
        String,
        DateTime,
        Decimal,
        Float,
        Enum,
        ComplexType
    }
}