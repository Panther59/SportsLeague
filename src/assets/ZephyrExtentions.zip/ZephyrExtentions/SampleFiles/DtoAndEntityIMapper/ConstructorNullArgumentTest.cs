﻿//-----------------------------------------------------------------------
// <copyright file="ConstructorNullArgumentTest.cs" company="Best Buy">
//     Copyright (c) Best Buy. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace @nameSpace@
{
    using System;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Defines the ConstructorNullArgumentTest type
    /// </summary>
    [TestClass]
    public class ConstructorNullArgumentTest : @baseTestName@
    {
        /// <summary>
        /// The <see cref="ArgumentNullException"/> result
        /// </summary>
        private ArgumentNullException result;

        /// <summary>
        /// Then result is not null
        /// </summary>
        [TestCategory(TestCategory), TestMethod]
        public void ThenResultIsNotNull()
        {
            this.ThenResultIsNotNull(this.result);
        }

        /// <inheritdoc />>
        protected override void Given()
        {
            this.result = this.ExpectException<ArgumentNullException>(() => this.Subject = new @inputNameSpace@.@inputName@(null));
        }
    }
}