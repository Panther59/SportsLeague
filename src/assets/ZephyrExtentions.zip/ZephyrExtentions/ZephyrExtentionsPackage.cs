﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.Runtime.InteropServices;
using System.ComponentModel.Design;
using Microsoft.VisualStudio;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio.Shell;
using EnvDTE80;
using EnvDTE;
using System.Collections.Generic;
using System.Linq;
using System.IO;

namespace ZephyrExtentions
{
    /// <summary>
    /// This is the class that implements the package exposed by this assembly.
    ///
    /// The minimum requirement for a class to be considered a valid package for Visual Studio
    /// is to implement the IVsPackage interface and register itself with the shell.
    /// This package uses the helper classes defined inside the Managed Package Framework (MPF)
    /// to do it: it derives from the Package class that provides the implementation of the 
    /// IVsPackage interface and uses the registration attributes defined in the framework to 
    /// register itself and its components with the shell.
    /// </summary>
    // This attribute tells the PkgDef creation utility (CreatePkgDef.exe) that this class is
    // a package.
    [PackageRegistration(UseManagedResourcesOnly = true)]
    // This attribute is used to register the information needed to show this package
    // in the Help/About dialog of Visual Studio.
    [InstalledProductRegistration("#110", "#112", "1.0", IconResourceID = 400)]
    // This attribute is needed to let the shell know that this package exposes some menus.
    [ProvideMenuResource("Menus.ctmenu", 1)]
    [Guid(GuidList.guidZephyrExtentionsPkgString)]
    [ProvideAutoLoad("f1536ef8-92ec-443c-9ed7-fdadf150da82")]
    public sealed class ZephyrExtentionsPackage : Package
    {
        DTE2 _applicationObject = null;

        /// <summary>
        /// Default constructor of the package.
        /// Inside this method you can place any initialization code that does not require 
        /// any Visual Studio service because at this point the package object is created but 
        /// not sited yet inside Visual Studio environment. The place to do all the other 
        /// initialization is the Initialize method.
        /// </summary>
        public ZephyrExtentionsPackage()
        {
            Debug.WriteLine(string.Format(CultureInfo.CurrentCulture, "Entering constructor for: {0}", this.ToString()));
        }

        /////////////////////////////////////////////////////////////////////////////
        // Overridden Package Implementation
        #region Package Members

        /// <summary>
        /// Initialization of the package; this method is called right after the package is sited, so this is the place
        /// where you can put all the initialization code that rely on services provided by VisualStudio.
        /// </summary>
        protected override void Initialize()
        {
            Debug.WriteLine(string.Format(CultureInfo.CurrentCulture, "Entering Initialize() of: {0}", this.ToString()));
            base.Initialize();

            _applicationObject = GetService(typeof(EnvDTE.DTE)) as DTE2;
            GetZephyrData();
            AppGlobal.ExtensionOutputFolder = this.GetExtensionFolderPath();

            // Add our command handlers for menu (commands must exist in the .vsct file)
            OleMenuCommandService mcs = GetService(typeof(IMenuCommandService)) as OleMenuCommandService;
            if (null != mcs)
            {
                // Create the command for the menu item.
                CommandID menuCommandID = new CommandID(GuidList.guidZephyrExtentionsCmdSet, (int)PkgCmdIDList.cmdidCreateIMapperUnitTests);
                OleMenuCommand menuItem = new OleMenuCommand(MenuItemCallback, menuCommandID);
                menuItem.BeforeQueryStatus += menuItem_BeforeQueryStatus;
                mcs.AddCommand(menuItem);
            }
        }

        private void GetZephyrData()
        {
            var solution = GetService(typeof(IVsSolution)) as IVsSolution;
            System.IO.FileInfo solInfo = new System.IO.FileInfo(_applicationObject.Solution.FullName);
            if (solInfo.Exists)
            {
                AppGlobal.ZephyrRootPath = solInfo.Directory.FullName;
            }
        }

        private string GetExtensionFolderPath()
        {
            try
            {
                var assembly = System.Reflection.Assembly.GetExecutingAssembly();
                var assemblyLocation = new System.IO.FileInfo(assembly.Location);
                if (assemblyLocation.Exists && assemblyLocation.Directory != null)
                {
                    return assemblyLocation.Directory.FullName;
                }
            }
            catch (Exception)
            {
            }
            return null;
        }

        private List<string> GetReferenceFiles()
        {
            var solution = GetService(typeof(IVsSolution)) as IVsSolution;
            var proj = GetDTEProject(solution, "BestBuy.Zephyr.Services.ServiceLibrary");
            string folderPath = (new FileInfo(proj.FullName)).Directory.FullName;

            List<string> refFiles = SearchFiles(folderPath, "Reference.cs");
            return refFiles;
        }

        private List<string> SearchFiles(string folderPath, string filename)
        {
            DirectoryInfo dir = new DirectoryInfo(folderPath);
            return dir.GetFiles(filename, SearchOption.AllDirectories).Select(x => x.FullName).ToList();
        }

        void menuItem_BeforeQueryStatus(object sender, EventArgs e)
        {
            bool isVisible = false;
            OleMenuCommand menuCommand = sender as OleMenuCommand;
            if (menuCommand != null)
            {
                if (_applicationObject != null && _applicationObject.ToolWindows.SolutionExplorer.SelectedItems != null && _applicationObject.Solution.FullName.ToLower().EndsWith("bestbuy.zephyr.sln"))
                {
                    object[] items = _applicationObject.ToolWindows.SolutionExplorer.SelectedItems as object[];
                    foreach (var file in items)
                    {
                        EnvDTE.UIHierarchyItem item = file as EnvDTE.UIHierarchyItem;
                        if (item != null)
                        {
                            ProjectItem pItem = item.Object as ProjectItem;
                            string name = pItem.Name.ToLower();
                            if (name.Contains("mapper") && name.Contains("input") == false && name.Contains("result") == false)
                            {
                                isVisible = true;
                            }
                            else
                            {
                                break;
                            }
                        }

                    }
                }
            }
            menuCommand.Visible = isVisible;
        }
        #endregion

        /// <summary>
        /// This function is the callback used to execute a command when the a menu item is clicked.
        /// See the Initialize method to see how the menu item is associated to this function using
        /// the OleMenuCommandService service and the MenuCommand class.
        /// </summary>
        private void MenuItemCallback(object sender, EventArgs e)
        {
            List<string> files = this.GetReferenceFiles();
            var solution = GetService(typeof(IVsSolution)) as IVsSolution;
            if (_applicationObject.ToolWindows.SolutionExplorer.SelectedItems != null)
            {
                object[] items = _applicationObject.ToolWindows.SolutionExplorer.SelectedItems as object[];

                foreach (var inputfile in items)
                {
                    EnvDTE.UIHierarchyItem item = inputfile as EnvDTE.UIHierarchyItem;
                    if (item != null)
                    {
                        ProjectItem pItem = item.Object as ProjectItem;
                        var fullPath = pItem.get_FileNames(1);
                        System.IO.FileInfo info = new System.IO.FileInfo(fullPath);
                        if (info.Exists)
                        {
                            IMapperUnitTestAutomation mapperAutomation = new IMapperUnitTestAutomation();
                            mapperAutomation.FindClassDetail(info.FullName, files);

                            //var solution = GetService(typeof(IVsSolution)) as IVsSolution;
                            var projects = GetProjects(solution);
                            var targetProj = projects.Where(x => mapperAutomation.NameSpace.StartsWith(x.Name));

                            if (mapperAutomation.OutputFilesPath != null && mapperAutomation.OutputFilesPath.Count > 0 &&
                                targetProj.Any() && targetProj.First().ProjectItems != null)
                            {
                                foreach (var file in mapperAutomation.OutputFilesPath)
                                {
                                    ProjectItem newItem = targetProj.First().ProjectItems.AddFromFile(file.FilePath);
                                    newItem.Open("{7651A701-06E5-11D1-8EBD-00A0C90F26EA}");
                                }

                                ShowMessage("IMapper Unit Test Automation", "Unit Test Cases created successfully.");
                                
                            }
                            else
                            {
                                ShowMessage("IMapper Unit Test Automation", "No Unit Test Cases created.");
                            }
                        }
                    }
                }
            }
        }

        private void ShowMessage(string message1, string message2)
        {
            IVsUIShell uiShell = (IVsUIShell)GetService(typeof(SVsUIShell));
            Guid clsid = Guid.Empty;
            int result;
            Microsoft.VisualStudio.ErrorHandler.ThrowOnFailure(uiShell.ShowMessageBox(
                       0,
                       ref clsid,
                       message1,
                       message2,
                       string.Empty,
                       0,
                       OLEMSGBUTTON.OLEMSGBUTTON_OK,
                       OLEMSGDEFBUTTON.OLEMSGDEFBUTTON_FIRST,
                       OLEMSGICON.OLEMSGICON_INFO,
                       0,        // false
                       out result));
        }

        private IEnumerable<EnvDTE.Project> GetProjects(IVsSolution solution)
        {
            foreach (IVsHierarchy hier in GetProjectsInSolution(solution))
            {
                EnvDTE.Project project = GetDTEProject(hier);
                if (project != null)
                    yield return project;
            }
        }

        private IEnumerable<IVsHierarchy> GetProjectsInSolution(IVsSolution solution)
        {
            return GetProjectsInSolution(solution, __VSENUMPROJFLAGS.EPF_LOADEDINSOLUTION);
        }

        private IEnumerable<IVsHierarchy> GetProjectsInSolution(IVsSolution solution, __VSENUMPROJFLAGS flags)
        {
            if (solution == null)
                yield break;

            IEnumHierarchies enumHierarchies;
            Guid guid = Guid.Empty;
            solution.GetProjectEnum((uint)flags, ref guid, out enumHierarchies);
            if (enumHierarchies == null)
                yield break;

            IVsHierarchy[] hierarchy = new IVsHierarchy[1];
            uint fetched;
            while (enumHierarchies.Next(1, hierarchy, out fetched) == VSConstants.S_OK && fetched == 1)
            {
                if (hierarchy.Length > 0 && hierarchy[0] != null)
                    yield return hierarchy[0];
            }
        }

        private EnvDTE.Project GetDTEProject(IVsHierarchy hierarchy)
        {
            if (hierarchy == null)
                throw new ArgumentNullException("hierarchy");

            object obj;
            hierarchy.GetProperty(VSConstants.VSITEMID_ROOT, (int)__VSHPROPID.VSHPROPID_ExtObject, out obj);
            return obj as EnvDTE.Project;
        }

        private EnvDTE.Project GetDTEProject(IVsSolution solution, string projectName)
        {
            IEnumerable<EnvDTE.Project> projs = GetProjects(solution);

            return projs.FirstOrDefault(x => x.Name == projectName);
        }
    }
}
