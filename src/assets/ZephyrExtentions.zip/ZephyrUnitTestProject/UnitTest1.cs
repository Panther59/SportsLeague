﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ZephyrUnitTestProject
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            ZephyrExtentions.IMapperUnitTestAutomation info = new ZephyrExtentions.IMapperUnitTestAutomation();
            //info.FindClassDetail(@"C:\Breeze\bDEV\Features\16.1\AppTier\BestBuy.Zephyr\BestBuy.Zephyr.Mappings\CACustomerServices\FromZephyr\PhoneToPhoneTypeMapper.cs");
        }
    }
}
