﻿import { Component, OnInit, Input } from '@angular/core';
import { TimeRecord, Timesheet, Task, DayHour, TaskLevelReport, TimesheetTaskDetail, TaskLevelReportRecord } from "../_models/index";
import * as AppGlobal from "../global";
import * as XLSX from 'xlsx';
import { ReportService, StorageService, ExcelService } from '../_services/index';
import { NgBlockUI, BlockUI } from 'ng-block-ui';
import { DatePipe } from '@angular/common';


@Component({
    moduleId: module.id,
    selector: "timesheet",
    styleUrls: ['timesheet.component.css'],
    templateUrl: 'timesheet.component.html'
})

export class TimesheetComponent implements OnInit {
    [x: string]: any;

    canExport: boolean = false;
    @Input() tasks: Task[];
    @Input() readOnly: boolean;
    _MS_PER_DAY: number = 1000 * 60 * 60 * 24;
    @BlockUI() blockUI: NgBlockUI;
    titleDateFormat: string = 'yyyyMMdd';
    dateFormat: string = 'yyyy-MM-dd HH:mm';

    get model(): Timesheet {
        return this._model;
    }

    @Input()
    set model(input: Timesheet) {
        this._model = input;
        this.updatedTimesheet();
    }

    _showExport: boolean = true;
    get showExport(): boolean {
        return this._showExport;
    }
    @Input()
    set showExport(input: boolean) {
        this._showExport = input;
    }

    days: string[] = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    headerRecord: TimeRecord;
    private _model: Timesheet;

    constructor(private reportService: ReportService,
        private storageService: StorageService,
        private excelService: ExcelService,
        private datePipe: DatePipe) {

    }

    ngOnInit() {

    }

    private updatedTimesheet() {
        this.logMessageData("Timesheet Model" + JSON.stringify(this.model));

        if (this.model) {
            this.headerRecord = new TimeRecord();
            this.addDaysToRecord(this.headerRecord, this.model.timesheetPeriod.startDate, this.model.timesheetPeriod.endDate);

            this.model.timesheetDetails.forEach((item, index) => {
                this.addDaysToRecord(item, this.model.timesheetPeriod.startDate, this.model.timesheetPeriod.endDate);
            });

            this.validateExportButton();
        }

    }

    addNewTaskRecord() {
        if (this.model && this.model.timesheetDetails) {
            var blankRec = new TimeRecord()
            blankRec.task = new Task();
            blankRec.task.id = -1;
            this.addDaysToRecord(blankRec, this.model.timesheetPeriod.startDate, this.model.timesheetPeriod.endDate);
            this.model.timesheetDetails.push(blankRec);
        }
    }

    public addDaysToRecord(record: TimeRecord, startDate: Date, endDate: Date) {
        var firstWeekDate = new Date(startDate);
        var endWeekDate = new Date(endDate);
        let days = this.dateDiffInDays(firstWeekDate, endWeekDate);
        const firstWeekDateNumber = firstWeekDate.getDate();

        let newDays: DayHour[] = [];
        for (let i = 0; i <= days; i++) {
            var day = this.getDayData(record, i, firstWeekDate, firstWeekDateNumber);
            newDays.push(day);
        }

        record.timesheetDayHours = [];
        record.timesheetDayHours = record.timesheetDayHours.concat(newDays);
        record.total = 0;

    }

    public validateExportButton() {
        AppGlobal.logMessageData("validateExportButton");
        if (this._model.status && (this._model.status.toLowerCase() == "submitted" || this._model.status.toLowerCase() == "processed" || this._model.status.toLowerCase() == "closed")) {
            this.canExport = true;
        }
        else {
            this.canExport = false;
        }
    }

    dateDiffInDays(a: Date, b: Date) {
        // Discard the time and time-zone information.
        var utc1 = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
        var utc2 = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());

        return Math.floor((utc2 - utc1) / this._MS_PER_DAY);
    }


    getDayData(record: TimeRecord, dayOfWeek: number, firstWeekDate: Date, firstWeekDateNumber: number): DayHour {
        var day = new DayHour();
        var firstDate = new Date(firstWeekDate);
        day.date = new Date(firstDate.setDate(firstWeekDateNumber + dayOfWeek));
        if (record.timesheetDayHours) {
            let dayEx = record.timesheetDayHours.find((x) => this.isDateSame(x.date, day.date));
            if (dayEx) {
                day.hours = dayEx.hours;
                day.isHoliday = dayEx.isHoliday;
                day.isLeave = dayEx.isLeave;
            }
        }
        day.isHoliday = this.isWeekEnd(this.getDay(day.date));

        return day;
    }


    private isDateSame(source: Date, target: Date): boolean {
        if (source && target) {
            let sourceDate = new Date(source);
            let targetDate = new Date(target);
            if (sourceDate.toDateString() === targetDate.toDateString()) {
                return true;
            }
        }

        return false;
    }

    getDate(date: Date) {
        let input = new Date(date);
        return input.getDate();
    }

    getDay(date: Date) {
        var days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

        let input = new Date(date);
        return this.days[input.getDay()];
    }

    isWeekEnd(day: string) {
        if (day && (day === 'Sat' || day === 'Sun')) {
            return true;
        }
        else {
            return false;
        }
    }


    getDayTotal(day: DayHour) {
        let sum = 0;
        if (this.model && this.model.timesheetDetails) {
            this.model.timesheetDetails.forEach((item, index) => {
                if (item.timesheetDayHours) {
                    var reqDay = item.timesheetDayHours.find((x) => this.isDateSame(x.date, day.date));
                    if (reqDay && reqDay.hours) {
                        sum = sum + reqDay.hours;
                    }
                }
            });
        }

        return sum;
    }

    getWeekTotal() {
        let sum = 0;
        if (this.model && this.model.timesheetDetails) {
            this.model.timesheetDetails.forEach((item, index) => {
                let daysum = 0;
                if (item.timesheetDayHours) {
                    daysum = item.timesheetDayHours.reduce((par, itm) => {
                        if (itm && itm.hours) {
                            sum = sum + itm.hours;
                        }

                        return daysum;
                    }, 0);
                }
                sum = sum + daysum;
            });
        }

        return sum;
    }

    logMessageData(message: string) {
        AppGlobal.logMessageData(message);
    }

    async exportTimeSheet() {

        try {
            this.blockUI.start("Generating Report...");
            let timesheetDetail = await this.reportService.getAllMyTasks(this._model.timesheetPeriod).toPromise();
            let tasks = this.mapTaskReportExcel(timesheetDetail);

            const taskWorksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(tasks, {
                header: ['srNo', 'user', 'id', 'title', 'type', 'weekHrs', 'totalHrs', 'category', 'module', 'createdDate', 'modifiedDate', 'priority', 'status']
            });

            taskWorksheet['A1'].v = "Sr.No";
            taskWorksheet['B1'].v = "Resource Name";
            taskWorksheet['C1'].v = "TOTT";
            taskWorksheet['D1'].v = "TOTT Title";
            taskWorksheet['E1'].v = "TOTT Type";
            taskWorksheet['F1'].v = "Weekly Hours";
            taskWorksheet['G1'].v = "Total Hours";
            taskWorksheet['H1'].v = "New Ticket/Old Ticket";
            taskWorksheet['I1'].v = "Module";
            taskWorksheet['J1'].v = "Created Datetime";
            taskWorksheet['K1'].v = "Modified Datetime";
            taskWorksheet['L1'].v = "Priority";
            taskWorksheet['M1'].v = "Status";

            const workbook: XLSX.WorkBook = { Sheets: { 'Tasks': taskWorksheet }, SheetNames: ['Tasks'] };
            let excelTitle = 'WeeklyReport_' + this.storageService.currentUser.userName + '_' + this.formatDate(timesheetDetail.period.endDate, this.titleDateFormat);
            this.excelService.exportWorkbookAsExcelFile(workbook, excelTitle);

            this.blockUI.stop();
        } catch (e) {
            AppGlobal.logErrorData(e);
        }
        finally { this.blockUI.stop(); }
    }

    mapTaskReportExcel(timesheet: TaskLevelReport): TimesheetTaskDetail[] {
        let tasks: TimesheetTaskDetail[] = [];

        for (var r = 0, rlen = timesheet.records.length; r < rlen; r++) {
            let output = new TimesheetTaskDetail();
            output.srNo = r + 1;
            output.id = timesheet.records[r].task.id;
            output.title = timesheet.records[r].task.name;
            output.type = timesheet.records[r].task.taskType.type;
            output.module = timesheet.records[r].task.module.name;
            output.createdDate = this.formatDate(timesheet.records[r].task.createdOn, this.dateFormat);
            output.modifiedDate = this.formatDate(timesheet.records[r].task.updatedOn, this.dateFormat);
            output.priority = timesheet.records[r].task.priority;
            output.status = timesheet.records[r].task.status;
            output.weekHrs = timesheet.records[r].thisPeriod;
            output.totalHrs = timesheet.records[r].tillNow;
            output.user = timesheet.records[r].users[0].user.firstName + " " + timesheet.records[r].users[0].user.lastName;
            output.category = timesheet.records[r].task.createdOn > timesheet.period.startDate ? 'New Ticket' : 'Old Ticket';

            tasks.push(output);
        }
        return tasks;
    }

    formatDate(date: Date, format: string): string {
        return this.datePipe.transform(date, format);
    }
}