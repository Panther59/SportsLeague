import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgProgressModule, NgProgressInterceptor } from 'ngx-progressbar';
import { BaseRequestOptions } from '@angular/http';
import { BlockUIModule } from 'ng-block-ui';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive'; // this includes the core NgIdleModule but includes keepalive providers for easy wireup

import { A11yModule } from '@angular/cdk/a11y';
import { BidiModule } from '@angular/cdk/bidi';
import { ObserversModule } from '@angular/cdk/observers';
import { OverlayModule } from '@angular/cdk/overlay';
import { PlatformModule } from '@angular/cdk/platform';
import { PortalModule } from '@angular/cdk/portal';
import { ScrollDispatchModule } from '@angular/cdk/scrolling';
import { CdkStepperModule } from '@angular/cdk/stepper';
import { CdkTableModule } from '@angular/cdk/table';
import {
    MatAutocompleteModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatStepperModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,

    MatNativeDateModule,
    MatSortModule,
    MatPaginatorModule,

    MAT_DIALOG_DEFAULT_OPTIONS,

    DateAdapter
} from '@angular/material';
//import { NgxDatatableModule } from '@swimlane/ngx-datatable';

// Internal App Import
import { AppComponent } from './app.component';
import { routing } from './app.routing';
import { AlertComponent } from './_directives/index';
import { AuthGuard, AdminGuard } from './_guards/index';
import { fakeBackendProvider } from './_helpers/index';
import { StorageService, AlertService, AuthenticationService, UserService, MessageService, TaskService, TimesheetService, TimesheetPeriodService, ReportService, ModuleService, ExcelService, TeamService, LeaveService } from './_services/index';
import { AddtaskDialog, MessageDialog, ConfirmDialog, AdduserDialog, ImportTasksDialog, SearchTasksDialog } from './dialogs/index';
import { HomeComponent } from './home/index';
import { LoginComponent } from './login/index';
import { ReportsComponent, TaskLevelUserReportComponent, TaskLevelReportComponent, ModuleLevelReportComponent, ModuleLevelTaskReportComponent } from './reports/index'
import { TasksComponent } from './tasks/index'
import { TeamsComponent } from './teams/index'
import { UsersComponent } from "./users/index";
import { TimesheetsComponent } from "./timesheets/index";
import { TimerecordComponent } from "./timerecord/index";
import { TimesheetComponent } from "./timesheet/index";
import { WaitingComponent, BlockwaitingComponent } from "./waiting/index";
import { ProfileComponent } from "./profile/index";
import { TokenInterceptor, JWTInterceptor } from "./_interceptors/index";
import { CommonModule, DatePipe } from "@angular/common";
import { ImportTasksGridComponent, TaskGridComponent, SearchTaskGridComponent, TimesheetsGridComponent} from "./grids/index";
import { Observable } from "rxjs/Rx";
import { MyDateAdapter } from "./_declarations/dateAdapter";
import { TimeperiodSelectorComponent } from "./timeperiodSelector/index";
import { LeavesComponent } from "./leaves/index";

@NgModule({
    exports: [
        // CDK
        A11yModule,
        BidiModule,
        ObserversModule,
        OverlayModule,
        PlatformModule,
        PortalModule,
        ScrollDispatchModule,
        CdkStepperModule,
        CdkTableModule,

        // Material
        MatAutocompleteModule,
        MatButtonModule,
        MatButtonToggleModule,
        MatCardModule,
        MatCheckboxModule,
        MatChipsModule,
        MatDatepickerModule,
        MatDialogModule,
        MatExpansionModule,
        MatGridListModule,
        MatIconModule,
        MatInputModule,
        MatListModule,
        MatMenuModule,
        MatPaginatorModule,
        MatProgressBarModule,
        MatProgressSpinnerModule,
        MatRadioModule,
        MatRippleModule,
        MatSelectModule,
        MatSidenavModule,
        MatSlideToggleModule,
        MatSliderModule,
        MatSortModule,
        MatSnackBarModule,
        MatStepperModule,
        MatTableModule,
        MatTabsModule,
        MatToolbarModule,
        MatTooltipModule,
        MatNativeDateModule
    ]
})
export class MaterialModule { }

@NgModule({
    imports:
    [
        BrowserModule,
        BlockUIModule,
        FormsModule,
        HttpClientModule,
        routing,
        NgIdleKeepaliveModule.forRoot(),
        NgProgressModule,
        MaterialModule,
        CommonModule,
        ReactiveFormsModule,
        BrowserAnimationsModule
    ],
    declarations: [
        AppComponent,
        WaitingComponent,
        BlockwaitingComponent,
        AlertComponent,
        HomeComponent,
        LoginComponent,
        UsersComponent,
        TasksComponent,
        ProfileComponent,
        TeamsComponent,
        ReportsComponent,
        TimesheetsComponent,
        TimesheetComponent,
        TimerecordComponent,
        ModuleLevelReportComponent,
        ModuleLevelTaskReportComponent,
        TaskLevelReportComponent,
        TaskLevelUserReportComponent,
        LeavesComponent,
        MessageDialog,
        ConfirmDialog,
        AddtaskDialog,
        ImportTasksDialog,
        AdduserDialog,
        SearchTasksDialog,
        ImportTasksGridComponent,
        TaskGridComponent,
        SearchTaskGridComponent,
        TimesheetsGridComponent,
        TimeperiodSelectorComponent
    ],
    entryComponents: [
        WaitingComponent,
        BlockwaitingComponent,
        MessageDialog,
        ConfirmDialog,
        AddtaskDialog,
        ImportTasksDialog,
        AdduserDialog,
        SearchTasksDialog
    ],
    providers: [
        DatePipe,
        StorageService,
        AuthGuard,
        AdminGuard,
        AlertService,
        UserService,
        TaskService,
        ReportService,
        ModuleService,
        TeamService,
        TimesheetService,
        TimesheetPeriodService,
        AuthenticationService,
        MessageService,
        ExcelService,
        LeaveService,
        { provide: HTTP_INTERCEPTORS, useClass: NgProgressInterceptor, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: TokenInterceptor, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: JWTInterceptor, multi: true },
        { provide: DateAdapter, useClass: MyDateAdapter },
        { provide: MAT_DIALOG_DEFAULT_OPTIONS, useValue: { hasBackdrop: false } }
    ],
    bootstrap: [
        AppComponent
    ]
})
export class AppModule { }
