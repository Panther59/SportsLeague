import { Component, OnInit } from '@angular/core';

@Component({
    moduleId: module.id,
    styleUrls: ['blockwaiting.component.css'],
    templateUrl: 'blockwaiting.component.html'
})

export class BlockwaitingComponent {
    message: string;
}
