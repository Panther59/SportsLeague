﻿export * from './waiting.component';
export * from './blockwaiting.component';