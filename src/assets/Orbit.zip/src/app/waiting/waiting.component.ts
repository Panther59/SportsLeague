﻿import { Component, OnInit, Input } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'waiting',
    styleUrls: ['waiting.component.css'],
    templateUrl: 'waiting.component.html'
})

export class WaitingComponent {

    @Input() backgroundDark: boolean = false;
    @Input() message: string;
}