﻿import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { StorageService } from '../_services/index';

@Injectable()
export class AdminGuard implements CanActivate {

    constructor(
        private storageService: StorageService,
        private router: Router) {
    }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        if (this.storageService.token != null && this.isAdminUser()) {
            // logged in so return true
            return true;
        }

        if (state.url === "/home") {
            // not logged in so redirect to login page with the return url
            this.router.navigate(['/login']);
            return false;
        }
        else {
            // not logged in so redirect to login page with the return url
            this.router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
            return false;
        }
    }

    isAdminUser(): boolean {
        if (this.storageService.currentUser != null &&
            (this.storageService.currentUser.type == 'Super User' ||
                this.storageService.currentUser.type == 'Administrator')) {
            return true;
        }
        else {
            return false;
        }
    }
}