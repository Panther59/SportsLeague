﻿import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { StorageService } from '../_services/index';

@Injectable()
export class AuthGuard implements CanActivate {

    constructor(
        private storageService: StorageService,
        private router: Router) {
    }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        if (this.storageService.token != null) {
            // logged in so return true
            return true;
        }

        if(state.url === "/home") {
            // not logged in so redirect to login page with the return url
            this.router.navigate(['/login']);
            return false;
        }
        else {
            // not logged in so redirect to login page with the return url
            let returnUrl = state.url;
            if (returnUrl == "/") {
                this.router.navigate(['/login']);
            }
            else {
                this.router.navigate(['/login'], { queryParams: { returnUrl: returnUrl } });
            }
            return false;
        }
    }
}