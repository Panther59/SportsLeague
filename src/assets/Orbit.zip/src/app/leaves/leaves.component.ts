﻿import { Title } from '@angular/platform-browser';
import { Component, OnInit, Input } from '@angular/core';
import { Week, Day } from "../_models/index";
import * as AppGlobal from "../global";
import { TaskService, LeaveService, StorageService, UserService, MessageService } from "../_services/index";
import { Task, Leave, TimesheetPeriod, User } from "../_models/index";
import { BlockUI, NgBlockUI } from 'ng-block-ui';

@Component({
    moduleId: module.id,
    styleUrls: ['leaves.component.scss'],
    templateUrl: 'leaves.component.html'
})

export class LeavesComponent implements OnInit {

    @Input()
    firstWeekDay: number = 1;

    currentMonth: number;
    currentYear: number;
    currentDate: Date;
    selectedDate: Date;
    numberOfWeeks: number;
    weeks: Week[];
    days: Day[];
    dayText: string[];
    dayMasterText: string[] = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    tasks: Task[];
    leaves: Leave[];
    users: User[];
    selectedUser: number;
    selectedTask: number = -1;
    @BlockUI() blockUI: NgBlockUI;

    constructor(
        private titleService: Title,
        private storageService: StorageService,
        private messageService: MessageService,
        private userService: UserService,
        private leaveService: LeaveService,
        private taskService: TaskService) {
        this.titleService.setTitle("Leaves | Orbit");

    }

    ngOnInit() {
        this.initialize();
    }

    async initialize() {
        await this.getUsers();
        await Promise.all([
            this.loadCalendar(),
            this.getAllLeaveTasks()
        ]);
    }

    isLeaveUser(): boolean {
        if (this.storageService.currentUser != null && this.storageService.currentUser.id == this.selectedUser) {
            return true;
        }
        else {
            return false;
        }
    }

    isAdminUser(): boolean {
        if (this.storageService.currentUser != null && this.storageService.currentUser.type == 'Administrator') {
            return true;
        }
        else {
            return false;
        }
    }

    isSuperUser(): boolean {
        if (this.storageService.currentUser != null && this.storageService.currentUser.type == 'Super User') {
            return true;
        }
        else {
            return false;
        }
    }

    async getAllLeaveTasks() {
        this.tasks = await this.taskService.getAllLeaveTasks().toPromise();
    }

    async getUsers() {
        this.users = await this.userService.getAll().toPromise();
        this.selectedUser = this.storageService.currentUser.id;
    }

    async loadCalendar() {
        this.dayText = this.dayMasterText.slice(this.firstWeekDay, 7);
        this.dayText.push(...this.dayMasterText.slice(0, this.firstWeekDay));

        let todayDate = new Date(Date.now());

        this.setMonthData(todayDate);
    }

    userChanged() {
        AppGlobal.logMessageData("userCHanged");
        this.setMonthData(this.currentDate);
    }

    dayClicked(day: Day) {
        AppGlobal.logMessageData("day clicked");
        AppGlobal.logMessageData(day);
        if (day.isCurrentMonth && day.isWeekEnd == false) {
            day.checked = !day.checked;
        }
    }

    loadPreviousMonth() {
        if (this.currentMonth == 1) {
            this.currentMonth = 12;
            this.currentYear = this.currentYear - 1;
        }
        else {
            this.currentMonth = this.currentMonth - 1;
        }

        let monthStartDate = new Date(this.currentYear, this.currentMonth - 1, 1);
        this.setMonthData(monthStartDate);
    }

    loadNextMonth() {
        if (this.currentMonth == 12) {
            this.currentMonth = 1;
            this.currentYear = this.currentYear + 1;
        }
        else {
            this.currentMonth = this.currentMonth + 1;
        }

        let monthStartDate = new Date(this.currentYear, this.currentMonth - 1, 1);
        this.setMonthData(monthStartDate);
    }

    removeLeave(day: Day) {

        day.leave.status = 3;//// Deleted
        let leaves = [];
        leaves.push(day.leave);
        this.leaveService.saveTask(this.selectedUser, leaves).toPromise().then(() => {
            this.setMonthData(this.currentDate);
        });
    }

    saveLeaves() {
        this.saveLeavesData();
    }

    async saveLeavesData() {
        if (this.selectedTask > 0) {
            this.blockUI.start("Saving leaves...please wait...")
            try {
                let leaves = this.days.filter((d, i) => d.checked == true).map((d) => {
                    let leave = new Leave();
                    leave.date = d.date;
                    leave.hour = 9;
                    leave.status = 1;
                    leave.task = this.tasks.find((item, index) => item.id == this.selectedTask);

                    return leave;
                });

                await this.leaveService.saveTask(this.selectedUser, leaves).toPromise();
                this.setMonthData(this.currentDate);
            } catch (e) {
                AppGlobal.logErrorData(e);
            }

            this.blockUI.stop();
        }
        else {
            await this.messageService.showMessage("Leaves", "Please select leave type.");
        }
    }

    async approveLeaves() {
        this.blockUI.start("Approving leaves...please wait...")
        try {
            let leaves = this.days.filter((d, i) => d.checked == true && d.leave && d.leave.status == 1).map((d) => {
                let leave = JSON.parse(JSON.stringify(d.leave)) as Leave;
                leave.status = 2;
                return leave;
            });

            await this.leaveService.saveTask(this.selectedUser, leaves).toPromise();
            this.setMonthData(this.currentDate);
        } catch (e) {
            AppGlobal.logErrorData(e);
        }

        this.blockUI.stop();
    }

    async setMonthData(date: Date) {
        this.currentDate = new Date(date);
        this.currentMonth = date.getMonth() + 1;
        this.currentYear = date.getFullYear();
        let monthStartDate = new Date(this.currentYear, this.currentMonth - 1, 1);
        let monthEndDate = new Date(this.currentYear, this.currentMonth, 0);
        let day = monthStartDate.getDay();

        let period = new TimesheetPeriod();
        period.startDate = monthStartDate;
        period.endDate = monthEndDate;
        this.leaves = await this.leaveService.getTaskTypes(this.selectedUser, period).toPromise();

        AppGlobal.logMessageData("currentMonth- " + this.currentMonth);
        AppGlobal.logMessageData("currentYear- " + this.currentYear);
        AppGlobal.logMessageData("Day- " + day);

        this.weeks = [];
        let dateDiff = this.firstWeekDay - day;
        if (this.firstWeekDay > day) {
            dateDiff = dateDiff - 7;
        }

        let firstWeekDate = monthStartDate.addDays(dateDiff);

        AppGlobal.logMessageData("firstWeekDate- " + firstWeekDate.toLocaleDateString());
        let numberOfDays = monthStartDate.monthDays();
        AppGlobal.logMessageData("numberOfDays- " + numberOfDays);
        let numberOfDaysInFirstWeek = 7 + this.firstWeekDay - day;
        AppGlobal.logMessageData("numberOfDaysInFirstWeek- " + numberOfDaysInFirstWeek);

        let totalWeeks = Math.ceil((numberOfDays - numberOfDaysInFirstWeek) / 7) + 1;
        AppGlobal.logMessageData("totalWeeks- " + totalWeeks);


        this.days = [];
        for (var i = 0; i < totalWeeks; i++) {
            let startWeekDate = firstWeekDate.addDays((i * 7));
            let week = this.generateWeekData(startWeekDate, monthStartDate, monthEndDate);
            this.weeks.push(week);
        }

        AppGlobal.logMessageData(this.weeks);
    }

    generateWeekData(startDate: Date, monthStartDate: Date, monthEndDate: Date): Week {
        let week = new Week();
        week.days = [];
        week.startDate = startDate;
        for (var i = 0; i < 7; i++) {
            let day = new Day();
            day.date = startDate.addDays(i);
            day.isCurrentMonth = day.date >= monthStartDate && day.date <= monthEndDate;
            day.color = day.isCurrentMonth ? 'lightblue' : 'Gray';
            day.isWeekEnd = day.date.getDay() == 6 || day.date.getDay() == 0 /// 0 - Sunday, 6 - saturday;
            day.leave = this.leaves.find((item, index) => new Date(item.date).toDateString() == new Date(day.date).toDateString());
            day.canRemoveLeave =
                day.leave && /// Leave data present
                (this.isSuperUser() || /// If super user then they can remove
                    (day.leave.leaveUser.id != this.storageService.currentUser.id && /// User is not same, means user can not remove their own leaves
                        (day.leave.status == 1 || day.leave.status == 2 && this.isAdminUser()))); /// Leave is draft state(1) OR is approved(2) but current user is admin

            if (day.leave && day.leave.task) {
                day.isPersonalLeaveTaken = day.leave.task.id == 1;
                day.isSickLeaveTaken = day.leave.task.id == 2;
            }
            else {
                day.isPersonalLeaveTaken = false;
                day.isSickLeaveTaken = false;
            }

            week.days.push(day);
            this.days.push(day);
        }

        return week;
    }
}