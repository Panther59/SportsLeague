﻿import { Component, OnInit, Input, Injectable, ViewChild } from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { DataSource } from "@angular/cdk/collections";
import { MatSort } from "@angular/material";
import { BehaviorSubject } from "rxjs/Rx";
import { Observable } from 'rxjs/Observable';
import { merge } from 'rxjs/observable/merge';
import { map } from 'rxjs/operators/map';
import { UpdateTask, ImportTask } from "../_models/index";

@Component({
    moduleId: module.id,
    selector: 'importTasksGrid',
    styleUrls: ['importTasksGrid.component.css'],
    templateUrl: 'importTasksGrid.component.html',
    animations: [
        trigger('detailExpand', [
            state('collapsed', style({ height: '0px', minHeight: '0', visibility: 'hidden' })),
            state('expanded', style({ height: '*', visibility: 'visible' })),
            transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
        ]),
    ]
})

export class ImportTasksGridComponent implements OnInit {

    @ViewChild(MatSort) sort: MatSort;
    displayedColumns = ['select', 'id', 'name', 'type', 'module', 'status', 'priority', 'isImported'];
    dataSource: UpdateTaskDataSource;
    database: UpdateTaskDatabase;

    private _model: UpdateTask[];
    get model(): UpdateTask[] {
        return this._model;
    }

    @Input()
    set model(input: UpdateTask[]) {
        this._model = input;
        this.updateData();
    }

    updateData() {
        if (this.database) {
            this.database.data = this._model;
        }
    }

    /** Whether the number of selected elements matches the total number of rows. */
    isAllSelected() {
        const numSelected = this.database.data.filter((x, i) => x.isSelected == true).length;
        const numRows = this.database.data.length;
        return numSelected == numRows;
    }

    isSomeSelected() {
        const numSelected = this.database.data.filter((x, i) => x.isSelected == true).length;
        const numRows = this.database.data.length;
        return numSelected > 0 && numSelected < numRows;
    }

    selectionChanged(task: UpdateTask) {
        task.isSelected = !task.isSelected;
    }

    /** Selects all rows if they are not all selected; otherwise clear selection. */
    masterToggle() {
        this.isAllSelected() ?
            this.database.data.forEach(row => row.isSelected = false) :
            this.database.data.forEach(row => row.isSelected = true);
    }

    ngOnInit() {
        this.database = new UpdateTaskDatabase(this.model);
        this.dataSource = new UpdateTaskDataSource(this.database, this.sort);
    }
}

export class UpdateTaskDatabase {
    dataChange: BehaviorSubject<UpdateTask[]> = new BehaviorSubject<UpdateTask[]>([]);

    get data(): UpdateTask[] { return this.dataChange.value; }
    set data(data: UpdateTask[]) {
        this.sourceData = data;
        this.dataChange.next(this.sourceData);
    }

    constructor(private sourceData: UpdateTask[]) {
        this.initialize();
    }

    initialize() {
        this.dataChange.next(this.sourceData);
    }
}

export class UpdateTaskDataSource extends DataSource<any> {
    constructor(private database: UpdateTaskDatabase,
        private sort: MatSort) {
        super();
    }


    connect(): Observable<(UpdateTask)[]> {
        const displayDataChanges = [
            this.sort.sortChange,
            this.database.dataChange
        ];
        return merge(...displayDataChanges).pipe(map(() => {
            const data = this.getSortedData();
            return data;
        }));
    }

    disconnect() {
        // No-op
    }

    /** Returns a sorted copy of the database data. */
    getSortedData(): UpdateTask[] {
        const data = this.database.data;
        if (!this.sort.active || this.sort.direction == '') { return data; }

        return data.sort((a, b) => {
            let propertyA: number | string = '';
            let propertyB: number | string = '';

            switch (this.sort.active) {
                case 'id': [propertyA, propertyB] = [a.id, b.id]; break;
                case 'name': [propertyA, propertyB] = [a.name, b.name]; break;
                case 'type': [propertyA, propertyB] = [a.taskType.type, b.taskType.type]; break;
                case 'module': [propertyA, propertyB] = [a.module.name, b.module.name]; break;
                case 'status': [propertyA, propertyB] = [a.status, b.status]; break;
                case 'priority': [propertyA, propertyB] = [a.priority, b.priority]; break;
            }

            let valueA = isNaN(+propertyA) ? propertyA : +propertyA;
            let valueB = isNaN(+propertyB) ? propertyB : +propertyB;

            return (valueA < valueB ? -1 : 1) * (this.sort.direction == 'asc' ? 1 : -1);
        });
    }
}