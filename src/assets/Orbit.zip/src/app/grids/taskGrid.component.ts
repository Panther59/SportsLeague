﻿import { Component, OnInit, Input, Injectable, ViewChild, EventEmitter, Output, NgZone } from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { Router, NavigationStart, ActivatedRoute } from '@angular/router';
import { DataSource, CollectionViewer } from "@angular/cdk/collections";
import { MatSort, MatPaginator, MatDialogRef, MatDialog } from "@angular/material";
import { BehaviorSubject } from "rxjs/Rx";
import { Observable } from 'rxjs/Observable';
import { merge } from 'rxjs/observable/merge';
import { map } from 'rxjs/operators/map';
import { Task } from "../_models/index";
import { TaskService, StorageService, UserService, MessageService, AlertService, ModuleService } from "../_services/index";
import { tap } from "rxjs/operators";
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { AddtaskDialog } from "../dialogs/index";
import * as AppGlobal from "../global";

@Component({
    moduleId: module.id,
    selector: 'tasksGrid',
    styleUrls: ['taskGrid.component.css'],
    templateUrl: 'taskGrid.component.html'
})

export class TaskGridComponent implements OnInit {


    @ViewChild(MatSort) sort: MatSort;
    @ViewChild(MatPaginator) paginator: MatPaginator;
    displayedColumns = ['id', 'name', 'type', 'module', 'status', 'priority', 'isMyTask'];
    displayedAllColumns = ['id', 'name', 'type', 'module', 'status', 'priority', 'isMyTask'];
    displayedMobileColumns = ['id', 'name', 'type', 'isMyTask'];
    dataSource: TasksDataSource;
    @BlockUI() blockUI: NgBlockUI;

    private _searchTask: Task;
    get searchTask(): Task {
        return this._searchTask;
    }

    @Input()
    set searchTask(input: Task) {
        this._searchTask = input;
        this.loadTasksPage();
    }

    constructor(
        public dialog: MatDialog,
        private router: Router,
        private storageService: StorageService,
        private taskService: TaskService,
        private userService: UserService,
        private messageService: MessageService,
        private alertService: AlertService,
        private moduleService: ModuleService,
        private ngZone: NgZone) {
        window.onresize = (e) => {
            ngZone.run(() => {
                if (window.innerWidth < 767) {
                    this.displayedColumns = this.displayedMobileColumns;
                }
                else {
                    this.displayedColumns = this.displayedAllColumns;
                }
            });
        };
    }

    ngAfterViewInit() {

       // reset the paginator after sorting
        this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);

        merge(this.sort.sortChange, this.paginator.page)
            .pipe(
            tap(() => this.loadTasksPage())
            )
            .subscribe();
    }

    async openTaskDetail(id: number) {
        this.taskService.getTaskById(id).subscribe((data) => {
            if (data) {
                this.taskDetail(data);
            }
        }, (err) => {
            this.messageService.showMessage("Task", err.message);
        });
    }

    public loadTasksPage() {
        if (this.dataSource) {
            this.dataSource.loadTasks(
                this.searchTask,
                this.paginator.pageSize,
                this.paginator.pageIndex + 1,
                this.sort.active,
                this.sort.direction);
        }
    }

    async taskDetail(task: Task) {
        let dialogRef = this.getTaskPopup();
        dialogRef.componentInstance.loadDataForTask(task.id);
    }

    getTaskPopup(): MatDialogRef<AddtaskDialog> {
        let dialogRef = this.dialog.open(AddtaskDialog, {
            data: {
                alertService: this.alertService,
                taskService: this.taskService,
                userService: this.userService,
                moduleService: this.moduleService,
                storageService: this.storageService,
                router: this.router
            },
            disableClose: true,
            hasBackdrop: true
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result) {
                this.taskUpdated.emit(result);
            }
        });

        return dialogRef;
    }
    addTaskToMyTasks(task: Task) {
        task.isMyTask = true;
        this.taskService.saveTask(task).toPromise().catch((e) => {
            AppGlobal.logErrorData(e);
            task.isMyTask = false;
        });
    }

    removeTaskToMyTasks(task: Task) {
        task.isMyTask = false;
        this.taskService.saveTask(task).toPromise().catch((e) => {
            AppGlobal.logErrorData(e);
            task.isMyTask = true;
        });
    }

    @Output()
    taskUpdated: EventEmitter<boolean> = new EventEmitter<boolean>();


    ngOnInit() {
        if (this.sort) {
            this.sort.active = "isMyTask";
            this.sort.direction = "desc";
        }
        this.dataSource = new TasksDataSource(this.taskService, this.sort, this.paginator, this.blockUI);
        this.loadTasksPage();
    }
}


export class TasksDataSource extends DataSource<any> {

    private tasksSubject = new BehaviorSubject<Task[]>([]);

    constructor(private taskService: TaskService,
        private sort: MatSort,
        private paginator: MatPaginator,
        private blockUI: NgBlockUI) {
        super();
    }

    connect(): Observable<Task[]> {
        return this.tasksSubject.asObservable();
    }

    public loadTasks(searchTask: Task, pageSize: number = 10, pageNumber: number = 1, orderBy: string = null, sort: string = null) {
        this.blockUI.start("Loading tasks...please wait...")

        this.taskService.searchTasks(searchTask, pageSize, pageNumber, orderBy, sort)
            .subscribe(page => {
                this.tasksSubject.next(page.records);
                this.paginator.pageIndex = page.pageNumber - 1;
                this.paginator.pageSize = page.pageSize;
                this.paginator.length = page.total;
                this.blockUI.stop();
            }, (e) => {
                AppGlobal.logErrorData(e);
                this.blockUI.stop();
            });
    }

    disconnect() {
        this.tasksSubject.complete();
    }
}