﻿import { Component, OnInit, ViewChild, Injectable, Input, Output, EventEmitter, NgZone } from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { DataSource } from "@angular/cdk/collections";
import { MatSort } from "@angular/material";
import { BehaviorSubject } from "rxjs/Rx";
import { Observable } from 'rxjs/Observable';
import { merge } from 'rxjs/observable/merge';
import { map } from 'rxjs/operators/map';

import { Timesheet, Task } from "../_models/index";
import * as Appglobal from "../global";

@Component({
    moduleId: module.id,
    selector: 'timesheetsGrid',
    styleUrls: ['timesheetsGrid.component.css'],
    templateUrl: 'timesheetsGrid.component.html',
    animations: [
        trigger('detailExpand', [
            state('collapsed', style({ height: '0px', minHeight: '0', visibility: 'hidden' })),
            state('expanded', style({ height: '*', visibility: 'visible' })),
            transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
        ]),
    ]
})

export class TimesheetsGridComponent implements OnInit {

    private _model: Timesheet[];
    get model(): Timesheet[] {
        return this._model;
    }

    @Input()
    set model(input: Timesheet[]) {
        this._model = input;
        this.updateData();
    }

    private _tasks: Task[];
    get tasks(): Task[] {
        return this._tasks;
    }

    @Input()
    set tasks(input: Task[]) {
        this._tasks = input;
    }


    @Output()
    timesheetSelected: EventEmitter<number> = new EventEmitter<number>();

    displayedAllColumns = ['expander', 'week', 'title', 'status', 'modified'];
    displayedMobileColumns = ['expander', 'week', 'title', 'status'];
    displayedColumns = ['expander', 'week', 'title', 'status', 'modified'];
    dataSource: TimesheetDataSource;
    database: TimesheetDatabase;
    isNotExpansionDetailRow = (_index: number, row: Timesheet | TimesheetDetailRow) => !row.hasOwnProperty('detailRow');
    isExpansionDetailRow = (_index: number, row: Timesheet | TimesheetDetailRow) => row.hasOwnProperty('detailRow');
    expandedElement: any;
    headerRowClicked = (row: any) => {
        if (this.expandedElement == row) {
            this.expandedElement = null;
        } else {
            this.expandedElement = row;
        }
    }

    constructor(ngZone: NgZone) {
        window.onresize = (e) => {
            ngZone.run(() => {
                Appglobal.logMessageData("Screen size changed to :" + window.innerWidth);
                if (window.innerWidth < 767) {
                    this.displayedColumns = this.displayedMobileColumns;
                }
                else {
                    this.displayedColumns = this.displayedAllColumns;
                }
            });
        };
    }

    ngOnInit() {
        this.database = new TimesheetDatabase(this._model);
        this.dataSource = new TimesheetDataSource(this.database);

    }

    updateData() {
        if (this.database) {
            this.database.data = this._model;
        }
    }

    async timesheetDetail(timesheetId: number) {
        if (timesheetId) {
            this.timesheetSelected.emit(timesheetId);
        }
    }

}


export interface TimesheetDetailRow {
    detailRow: boolean;
    element: Timesheet;
}

export class TimesheetDatabase {
    dataChange: BehaviorSubject<Timesheet[]> = new BehaviorSubject<Timesheet[]>([]);

    get data(): Timesheet[] { return this.dataChange.value; }
    set data(data: Timesheet[]) {
        this.sourceData = data;
        this.dataChange.next(this.sourceData);
    }

    constructor(private sourceData: Timesheet[]) {
        this.initialize();
    }

    initialize() {
        this.dataChange.next(this.sourceData);
    }
}

export class TimesheetDataSource extends DataSource<any> {
    constructor(private database: TimesheetDatabase) {
        super();
    }

    connect(): Observable<(Timesheet | TimesheetDetailRow)[]> {
        const displayDataChanges = [
            this.database.dataChange
        ];
        return merge(...displayDataChanges).pipe(map(() => {
            const rows: (Timesheet | TimesheetDetailRow)[] = [];
            this.database.data.forEach(element => rows.push(element, { detailRow: true, element: element }));
            return rows;
        }));
    }

    disconnect() {
        // No-op
    }

    
}