﻿import { Component, OnInit, Input, Injectable, ViewChild, Output, EventEmitter } from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { DataSource } from "@angular/cdk/collections";
import { MatSort, MatPaginator } from "@angular/material";
import { BehaviorSubject } from "rxjs/Rx";
import { Observable } from 'rxjs/Observable';
import { merge } from 'rxjs/observable/merge';
import { map } from 'rxjs/operators/map';
import { Task, PagingResult } from "../_models/index";
import { tap } from "rxjs/operators";
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { TaskService } from "../_services/index";
import * as AppGlobal from "../global";

@Component({
    moduleId: module.id,
    selector:'searchTaskGrid',
    styleUrls: ['searchTaskGrid.component.css'],
    templateUrl: 'searchTaskGrid.component.html',
    animations: [
        trigger('detailExpand', [
            state('collapsed', style({ height: '0px', minHeight: '0', visibility: 'hidden' })),
            state('expanded', style({ height: '*', visibility: 'visible' })),
            transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
        ]),
    ]
})

export class SearchTaskGridComponent implements OnInit {

    @ViewChild(MatSort) sort: MatSort;
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @BlockUI() blockUI: NgBlockUI;
    displayedColumns = ['select', 'id', 'name', 'type', 'module', 'status'];

    @Output()
    taskSelected: EventEmitter<Task> = new EventEmitter<Task>();

    dataSource: SearchTaskDataSource;
    constructor(
        private taskService: TaskService) {
    }

    private _model: Task;
    get model(): Task {
        return this._model;
    }
    @Input()
    set model(input: Task) {
        this._model = input;
        this.updateData();
    }


    ngAfterViewInit() {

        this.sort.active = 'id';
        this.sort.direction = 'desc';
        // reset the paginator after sorting
        this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);

        merge(this.sort.sortChange, this.paginator.page)
            .pipe(
            tap(() => this.updateData())
            )
            .subscribe();
    }

    taskSelectedClicked(task: Task) {
        this.taskSelected.emit(task);
    }

    updateData() {
        if (this.dataSource && this._model) {
            this.dataSource.loadTasks(this.model);
        }
    }

    ngOnInit() {
        this.dataSource = new SearchTaskDataSource(this.taskService, this.sort, this.paginator, this.blockUI);
    }
}


export class SearchTaskDataSource extends DataSource<any> {

    private tasksSubject = new BehaviorSubject<Task[]>([]);

    constructor(private taskService: TaskService,
        private sort: MatSort,
        private paginator: MatPaginator,
        private blockUI: NgBlockUI) {
        super();
    }

    connect(): Observable<Task[]> {
        return this.tasksSubject.asObservable();
    }

    public loadTasks(task: Task) {
        this.blockUI.start("Searching tasks...please wait...")

        this.taskService.searchTasks(task, this.paginator.pageSize, this.paginator.pageIndex + 1, this.sort.active, this.sort.direction)
            .subscribe(page => {
                this.tasksSubject.next(page.records);
                this.paginator.pageIndex = page.pageNumber - 1;
                this.paginator.pageSize = page.pageSize;
                this.paginator.length = page.total;
                this.blockUI.stop();
            }, (e) => {
                AppGlobal.logErrorData(e);
                this.blockUI.stop();
            });
    }

    disconnect() {
        this.tasksSubject.complete();
    }
}