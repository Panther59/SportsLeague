﻿import { Router, NavigationStart, ActivatedRoute } from '@angular/router';
import { Component, OnInit, Input } from '@angular/core';
import { MatDialog } from '@angular/material';
import { TimeRecord, Task } from "../_models/index";
import { SearchTasksDialog } from "../dialogs/index";
import { TaskService } from "../_services/index";

@Component({
    selector: 'app-timerecord',
    moduleId: module.id,
    styleUrls: ['timerecord.component.css'],
    templateUrl: 'timerecord.component.html'
})

export class TimerecordComponent implements OnInit {

    @Input() record: TimeRecord;
    @Input() tasks: Task[];
    @Input() readOnly: boolean;
    hasLeave: boolean;

    constructor(public dialog: MatDialog,
        private router: Router,
        private taskService: TaskService) {

    }

    selectedTaskId: number = -1;
    ngOnInit() {
        this.hourChanged();
        this.addTaskIfMissing(this.record.task);
        if (this.record && this.record.timesheetDayHours) {
            this.hasLeave = this.record.timesheetDayHours.some((item, index) => item.isLeave == true);
        }
    }

    searchTask() {
        let dialogRef = this.dialog.open(SearchTasksDialog, {
            data: {
                taskService: this.taskService,
                router: this.router
            },
            disableClose: true,
            hasBackdrop: true
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result && result.task) {
                this.addTaskIfMissing(result.task);
            }
        });
    }

    addTaskIfMissing(task: Task) {
        if (task && task.id != -1) {
            if (!Boolean(this.tasks)) {
                this.tasks = [];
            }
            if (this.tasks.some((t, i) => t.id == task.id) == false) {
                this.tasks.push(task);
            }

            this.taskChanged(task);
        }
    }

    taskChanged(task: Task) {
        if (task && task.id > 0) {
            this.record.task = task;
        }
        else {
            this.record.task = new Task();
            this.record.task.id = -1;
            this.record.task.name = "Please Select";
        }
    }

    getTotal(): number {
        let sum = 0;
        if (this.record && this.record.timesheetDayHours) {
            sum = this.record.timesheetDayHours.reduce((par, itm) => {
                if (itm && itm.hours) {
                    sum = sum + itm.hours;
                }

                return sum;
            }, 0);

            return sum;
        }
    }

    hourChanged() {
        this.record.total = this.getTotal();
    }
}