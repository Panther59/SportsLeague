﻿import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { TimesheetService, StorageService, TimesheetPeriodService } from "../_services/index";
import { TimesheetPeriod } from "../_models/index";

@Component({
    moduleId: module.id,
    selector: 'timeperiodSelector',
    styleUrls: ['timeperiodSelector.component.css'],
    templateUrl: 'timeperiodSelector.component.html'
})

export class TimeperiodSelectorComponent implements OnInit {

    _period: TimesheetPeriod;
    private isLoaded: boolean = false;

    @Output()
    get period(): TimesheetPeriod {
        return this._period;
    }

    constructor(private timesheetPeriodService: TimesheetPeriodService) {
    }

    @Output()
    dateChanged: EventEmitter<Date> = new EventEmitter<Date>();

    @Output()
    periodChanged: EventEmitter<TimesheetPeriod> = new EventEmitter<TimesheetPeriod>();

    _model: Date;
    get model(): Date {
        return this._model;
    }

    @Input()
    set model(input: Date) {
        this._model = input;
    }

    _fetchPeriod: boolean;
    @Input()
    set fetchPeriod(input: boolean) {
        this._fetchPeriod = input;
    }

    onDateSelect() {
        if (this.isLoaded) {
            this.weekDateChangeHandler(this.model);
        }
    }

    private raiseDateEvent() {
        if (this.dateChanged) {
            this.dateChanged.emit(this.model);
        }
    }

    private raisePeriodEvent(period: TimesheetPeriod) {
        if (this.periodChanged) {
            this.periodChanged.emit(period);
        }
    }

    public async getPeriod(date: Date) {
        let period = await this.timesheetPeriodService.getPeriodByDate(date).toPromise();
        this.isLoaded = false;
        if (period) {
            this.model = period.endDate;
            this.raisePeriodEvent(period);
        }
        else {
            this.model = date;
            this.raiseDateEvent();
        }
        this.isLoaded = true;
    }

    loadPreviousWeek() {
        var selectedDate = new Date(this.model);
        selectedDate = new Date(selectedDate.setDate(selectedDate.getDate() - 7));
        this.weekDateChangeHandler(selectedDate);
    }

    loadNextWeek() {
        var selectedDate = new Date(this.model);
        selectedDate = new Date(selectedDate.setDate(selectedDate.getDate() + 7));
        this.weekDateChangeHandler(selectedDate);
    }

    private async weekDateChangeHandler(selectedDate: Date) {
        if (this._fetchPeriod) {
            await this.getPeriod(selectedDate);
        }
        else {
            this.model = selectedDate;
            this.raiseDateEvent();
        }
    }

    async ngOnInit() {
        await this.weekDateChangeHandler(new Date(Date.now()));
        this.isLoaded = true;
    }
}