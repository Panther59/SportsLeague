import { Component, OnInit, ViewChild, Injectable } from '@angular/core';
import { Title } from '@angular/platform-browser'
import { ActivatedRoute } from "@angular/router";
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { DatePipe } from '@angular/common';
import * as XLSX from 'xlsx';

import { TimesheetPeriodService, ExcelService } from "../_services/index";
import { TimesheetPeriod } from "../_models/index";
import { TaskLevelReport, TaskLevelReportRecord, ModuleLevelReport, ModuleLevelReportRecord, TaskUserReportExcel, TimesheetTaskDetail } from "../_models/index";
import { ReportService } from "../_services/report.service";
import * as AppGlobal from "../global";
import { TimeperiodSelectorComponent } from "../timeperiodSelector/index";

@Component({
    moduleId: module.id,
    styleUrls: ['reports.component.css'],
    templateUrl: 'reports.component.html'
})

export class ReportsComponent implements OnInit {

    @ViewChild('myTable') table: any;
    @BlockUI() blockUI: NgBlockUI;
    weekEndingDate: Date;
    //weekEndingDateDisplay: any;
    currentWeekPeriod: TimesheetPeriod;
    dateFormat: string = 'yyyy-MM-dd HH:mm';
    titleDateFormat: string = 'yyyyMMdd';

    taskReport: TaskLevelReport;
    moduleReport: ModuleLevelReport;

    typeOfTheReport: number = 0;
    periodOfTheReport: number = 0;
    isPageLoaded: boolean = false;
    isTaskLevelReportLoaded: boolean = false;
    isModuleLevelReportLoaded: boolean = false;
    month: Date;
    startDate: Date;
    endDate: Date;
    sub: any;
    @ViewChild('timeperiodSelector') timeperiodSelector: TimeperiodSelectorComponent;

    constructor(
        private datePipe: DatePipe,
        private route: ActivatedRoute,
        private timesheetPeriodService: TimesheetPeriodService,
        private reportService: ReportService,
        private excelService: ExcelService,
        private titleService: Title) {

        this.titleService.setTitle("Reports | Orbit");
    }

    private async getTimesheetPeriod(date: Date) {
        let period = await this.timesheetPeriodService.getPeriodByDate(date).toPromise();
        if (period) {
            this.onPeriodChanged(period);
        }
    }

    ngOnInit() {
        AppGlobal.logMessageData("Data:" + JSON.stringify(this.route.routeConfig.data));

        this.route.params.subscribe(params => {
            let type: string = params['type'];
            let period: string = params['period'];

            switch (type && type.toLowerCase()) {
                case 'modules': {
                    this.typeOfTheReport = 1;
                    break;
                }
                case 'tasks':
                default: {
                    this.typeOfTheReport = 0;
                    break;
                }
            }

            switch (period && period.toLowerCase()) {
                case 'monthly': {
                    this.periodOfTheReport = 1;
                    break;
                }
                case 'custom': {
                    this.periodOfTheReport = 2;
                    break;
                }
                case 'weekly':
                default: {
                    this.periodOfTheReport = 0;
                    break;
                }
            }
        });

        this.initialize();
    }

    async initialize() {
        await this.getTimesheetPeriod(new Date(Date.now()));
        this.isPageLoaded = true;
    }

    toggleExpandRow(row: any) {
        this.table.rowDetail.toggleExpandRow(row);
    }

    //private getCustomDate(input: Date) {
    //    var convDate = new Date(input);
    //    return { year: convDate.getFullYear(), month: convDate.getMonth() + 1, day: convDate.getDate() };
    //}

    logMessageData(ex: any) {
        AppGlobal.logMessageData(ex);
    }

    onPeriodChanged(period: TimesheetPeriod) {
        if (period) {
            this.currentWeekPeriod = period;
            this.weekEndingDate = period.endDate;

            if (!Boolean(this.month)) {
                this.month = this.weekEndingDate;
                this.startDate = period.startDate;
                this.endDate = period.endDate;
            }
        }
    }

    async generateReport() {
        try {
            this.isTaskLevelReportLoaded = false;
            this.isModuleLevelReportLoaded = false;
            if (this.typeOfTheReport == 0) {
                this.generateTaskLevelReport();
            }
            else {
                this.generateModuleLevelReport();
            }
        }
        catch (ex) {
            AppGlobal.logErrorData(ex);
        }
        finally {
        }
    }

    async generateTaskLevelReport() {
        let period = new TimesheetPeriod();
        if (this.periodOfTheReport == 0) {
            this.blockUI.start("Generating weekly task report...");
            period = this.currentWeekPeriod;
        }
        else if (this.periodOfTheReport == 1) {
            this.blockUI.start("Generating monthly task report...");
            period.startDate = new Date(this.month)
            period.endDate = new Date(this.month);

            this.logMessageData("SelectedPeriodID=" + JSON.stringify(period));
        }
        else if (this.periodOfTheReport == 2) {
            this.blockUI.start("Generating task report...");
            period.startDate = new Date(this.startDate);
            period.endDate = new Date(this.endDate);

            this.logMessageData("SelectedPeriodID=" + JSON.stringify(period));
        }

        this.taskReport = await this.reportService.getAllTasks(period).toPromise();
        this.isTaskLevelReportLoaded = true;
        this.blockUI.stop();
    }

    async generateModuleLevelReport() {
        let period = new TimesheetPeriod();
        if (this.periodOfTheReport == 0) {
            this.blockUI.start("Generating weekly module report...");
            period = this.currentWeekPeriod;

        }
        else if (this.periodOfTheReport == 1) {
            this.blockUI.start("Generating monthly module report...");
            period.startDate = new Date(this.month);
            period.endDate = new Date(this.month);

            this.logMessageData("SelectedPeriodID=" + JSON.stringify(period));
        }
        else if (this.periodOfTheReport == 2) {
            this.blockUI.start("Generating module report...");
            period.startDate = new Date(this.startDate);
            period.endDate = new Date(this.endDate);

            this.logMessageData("SelectedPeriodID=" + JSON.stringify(period));
        }

        this.moduleReport = await this.reportService.getAllModules(period).toPromise();
        this.isModuleLevelReportLoaded = true;
        this.blockUI.stop();
    }

    public getRowDetailsHeight = (row: any) => {
        let base = 90;
        if (row.users.length) {
            base = base + row.users.length * 50;
        }
        return base;
    }

    async openTaskDetail(taskId: number) {

    }

    async exportToExcelReport() {

        if (this.isTaskLevelReportLoaded) {
            var users = this.mapTaskUserReportExcel(this.taskReport.records);
            var tasks = this.mapTaskReportExcel(this.taskReport.records);

            const userWorksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(users, { header: ['srNo', 'user', 'id', 'title', 'type', 'weekHrs', 'totalHrs', 'category', 'module', 'createdDate', 'modifiedDate', 'priority', 'status'] });
            userWorksheet['A1'].v = "Sr.No";
            userWorksheet['B1'].v = "Resource Name";
            userWorksheet['C1'].v = "TOTT";
            userWorksheet['D1'].v = "TOTT Title";
            userWorksheet['E1'].v = "TOTT Type";
            userWorksheet['F1'].v = "Weekly Hours";
            userWorksheet['G1'].v = "Total Hours";
            userWorksheet['H1'].v = "New Ticket/Old Ticket";
            userWorksheet['I1'].v = "Module";
            userWorksheet['J1'].v = "Created Datetime";
            userWorksheet['K1'].v = "Modified Datetime";
            userWorksheet['L1'].v = "Priority";
            userWorksheet['M1'].v = "Status";

            const taskWorksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(tasks, { header: ['srNo', 'id', 'title', 'type', 'weekHrs', 'totalHrs', 'category', 'module', 'createdDate', 'modifiedDate', 'priority', 'status'] });

            taskWorksheet['A1'].v = "Sr.No";
            taskWorksheet['B1'].v = "TOTT";
            taskWorksheet['C1'].v = "TOTT Title";
            taskWorksheet['D1'].v = "TOTT Type";
            taskWorksheet['E1'].v = "Weekly Hours";
            taskWorksheet['F1'].v = "Total Hours";
            taskWorksheet['G1'].v = "New Ticket/Old Ticket";
            taskWorksheet['H1'].v = "Module";
            taskWorksheet['I1'].v = "Created Datetime";
            taskWorksheet['J1'].v = "Modified Datetime";
            taskWorksheet['K1'].v = "Priority";
            taskWorksheet['L1'].v = "Status";

            const workbook: XLSX.WorkBook = { Sheets: { 'Users': userWorksheet, 'Tasks': taskWorksheet }, SheetNames: ['Users', 'Tasks'] };
            let title = 'Orbit_TaskReport_' + this.formatDate(this.taskReport.period.endDate, this.titleDateFormat);
            this.excelService.exportWorkbookAsExcelFile(workbook, title);
        }
        else {
            var modules = this.mapModuleUserReportExcel(this.moduleReport.records);
            var summary = this.mapModuleReportExcel(this.moduleReport.records);

            const summaryWorksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(summary, { header: ['taskId', 'taskName', 'before', 'thisPeriod', 'tillNow'] });

            summaryWorksheet['A1'].v = "Module ID";
            summaryWorksheet['B1'].v = "Module Name";
            summaryWorksheet['C1'].v = "Previous";
            summaryWorksheet['D1'].v = "Current";
            summaryWorksheet['E1'].v = "Total";

            const workbook: XLSX.WorkBook = {
                Sheets: {
                    'Summary': summaryWorksheet,
                },
                SheetNames: ['Summary']
            };

            for (var m = 0, mlen = modules.length; m < mlen; m++) {
                const moduleWorksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(modules[m][1], { header: ['taskId', 'taskName', 'userName', 'before', 'thisPeriod', 'tillNow'] });
                moduleWorksheet['A1'].v = "Task ID";
                moduleWorksheet['B1'].v = "Task Name";
                moduleWorksheet['C1'].v = "User Name";
                moduleWorksheet['D1'].v = "Previous";
                moduleWorksheet['E1'].v = "Current";
                moduleWorksheet['F1'].v = "Total";

                workbook.SheetNames.push(modules[m][0]);
                workbook.Sheets[modules[m][0]] = moduleWorksheet;
            }

            let title = 'Orbit_ModuleReport_' + this.formatDate(this.moduleReport.period.endDate, this.titleDateFormat);
            this.excelService.exportWorkbookAsExcelFile(workbook, title);
        }
    }

    mapTaskUserReportExcel(records: TaskLevelReportRecord[]): TimesheetTaskDetail[] {
        let users: TimesheetTaskDetail[] = [];
        for (var r = 0, rlen = records.length; r < rlen; r++) {

            for (var i = 0, len = records[r].users.length; i < len; i++) {
                let output = new TimesheetTaskDetail();

                output.srNo = r + 1;
                output.id = records[r].task.id;
                output.title = records[r].task.name;
                output.type = records[r].task.taskType.type;
                output.module = records[r].task.module.name;
                output.createdDate = this.formatDate(records[r].task.createdOn, this.dateFormat);
                output.modifiedDate = this.formatDate(records[r].task.updatedOn, this.dateFormat);
                output.priority = records[r].task.priority;
                output.status = records[r].task.status;
                output.weekHrs = records[r].users[i].thisPeriod;
                output.totalHrs = records[r].users[i].tillNow;
                output.user = records[r].users[0].user.firstName + " " + records[r].users[0].user.lastName;
                output.category = records[r].task.createdOn > this.currentWeekPeriod.startDate ? 'New Ticket' : 'Old Ticket';


                //output.before = records[r].users[i].before;
                //output.thisPeriod = records[r].users[i].thisPeriod;
                //output.tillNow = records[r].users[i].tillNow;
                //output.taskId = records[r].task.id;
                //output.taskName = records[r].task.name;
                //output.userName = records[r].users[i].user.userName;

                users.push(output);
            }
        }

        return users;
    }

    mapTaskReportExcel(records: TaskLevelReportRecord[]): TimesheetTaskDetail[] {
        let users: TimesheetTaskDetail[] = [];
        for (var r = 0, rlen = records.length; r < rlen; r++) {
            let output = new TimesheetTaskDetail();

            output.srNo = r + 1;
            output.id = records[r].task.id;
            output.title = records[r].task.name;
            output.type = records[r].task.taskType.type;
            output.module = records[r].task.module.name;
            output.createdDate = this.formatDate(records[r].task.createdOn, this.dateFormat);
            output.modifiedDate = this.formatDate(records[r].task.updatedOn, this.dateFormat);
            output.priority = records[r].task.priority;
            output.status = records[r].task.status;
            output.weekHrs = records[r].thisPeriod;
            output.totalHrs = records[r].tillNow;
            //output.user = records[r].users[0].user.firstName + " " + records[r].users[0].user.lastName;
            output.category = records[r].task.createdOn > this.currentWeekPeriod.startDate ? 'New Ticket' : 'Old Ticket';


            //let output = new TaskUserReportExcel();
            //output.before = records[r].before;
            //output.thisPeriod = records[r].thisPeriod;
            //output.tillNow = records[r].tillNow;
            //output.taskId = records[r].task.id;
            //output.taskName = records[r].task.name;

            users.push(output);
        }

        return users;
    }

    mapModuleUserReportExcel(records: ModuleLevelReportRecord[]): [string, TaskUserReportExcel[]][] {
        let modules: [string, TaskUserReportExcel[]][] = [];

        for (var r = 0, rlen = records.length; r < rlen; r++) {
            let module: [string, TaskUserReportExcel[]];
            let users: TaskUserReportExcel[] = [];
            for (var t = 0, tlen = records[r].tasks.length; t < tlen; t++) {

                for (var u = 0, ulen = records[r].tasks[t].users.length; u < ulen; u++) {

                    let output = new TaskUserReportExcel();
                    output.before = records[r].tasks[t].users[u].before;
                    output.thisPeriod = records[r].tasks[t].users[u].thisPeriod;
                    output.tillNow = records[r].tasks[t].users[u].tillNow;
                    output.taskId = records[r].tasks[t].task.id;
                    output.taskName = records[r].tasks[t].task.name;
                    output.userName = records[r].tasks[t].users[u].user.userName;

                    users.push(output);
                }
            }

            module = [records[r].module.name, users];
            modules.push(module);
        }

        return modules;
    }

    formatDate(date: Date, format: string): string {
        return this.datePipe.transform(date, format);
    }

    mapModuleReportExcel(records: ModuleLevelReportRecord[]): TaskUserReportExcel[] {
        let users: TaskUserReportExcel[] = [];
        for (var r = 0, rlen = records.length; r < rlen; r++) {
            let output = new TaskUserReportExcel();
            output.before = records[r].before;
            output.thisPeriod = records[r].thisPeriod;
            output.tillNow = records[r].tillNow;
            output.taskId = records[r].module.id;
            output.taskName = records[r].module.name;

            users.push(output);
        }

        return users;
    }

    //reloadReport(params: DataTableParams) {
    //    this.taskRecordsResource.query(params).then(records => this.taskReport.records = records);
    //}

}
