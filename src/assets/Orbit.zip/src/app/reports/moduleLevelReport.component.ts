﻿import { Component, OnInit, ViewChild, Injectable, Input } from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { DataSource } from "@angular/cdk/collections";
import { MatSort } from "@angular/material";
import { BehaviorSubject } from "rxjs/Rx";
import { Observable } from 'rxjs/Observable';
import { merge } from 'rxjs/observable/merge';
import { map } from 'rxjs/operators/map';

import { ModuleLevelReportRecord } from "../_models/index";
import * as AppGlobal from "../global";

@Component({
    moduleId: module.id,
    selector: 'moduleLevelReport',
    styleUrls: ['moduleLevelReport.component.css'],
    templateUrl: 'moduleLevelReport.component.html',
    animations: [
        trigger('detailExpand', [
            state('collapsed', style({ height: '0px', minHeight: '0', visibility: 'hidden' })),
            state('expanded', style({ height: '*', visibility: 'visible' })),
            transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
        ]),
    ]
})

export class ModuleLevelReportComponent implements OnInit {

    private _model: ModuleLevelReportRecord[];
    get model(): ModuleLevelReportRecord[] {
        return this._model;
    }

    @Input()
    set model(input: ModuleLevelReportRecord[]) {
        this._model = input;
        this.updateData();
    }

    @ViewChild(MatSort) sort: MatSort;
    displayedColumns = ['expander', 'module', 'before', 'thisPeriod', 'tillNow'];
    moduleLevelDataSource: ModuleLevelDataSource;
    moduleLevelReportDatabase: ModuleLevelReportDatabase;
    isNotExpansionDetailRow = (_index: number, row: ModuleLevelReportRecord | ModuleReportDetailRow) => !row.hasOwnProperty('detailRow');
    isExpansionDetailRow = (_index: number, row: ModuleLevelReportRecord | ModuleReportDetailRow) => row.hasOwnProperty('detailRow');
    expandedElement: any;
    headerRowClicked = (row: any) => {
        if (this.expandedElement == row) {
            this.expandedElement = null;
        } else {
            this.expandedElement = row;
        }
    }

    ngOnInit() {
        this.moduleLevelReportDatabase = new ModuleLevelReportDatabase(this._model);
        this.moduleLevelDataSource = new ModuleLevelDataSource(this.moduleLevelReportDatabase, this.sort);

    }

    updateData() {
        if (this.moduleLevelReportDatabase) {
            this.moduleLevelReportDatabase.data = this._model;
        }
    }
}


export interface ModuleReportDetailRow {
    detailRow: boolean;
    element: ModuleLevelReportRecord;
}

export class ModuleLevelReportDatabase {
    dataChange: BehaviorSubject<ModuleLevelReportRecord[]> = new BehaviorSubject<ModuleLevelReportRecord[]>([]);

    get data(): ModuleLevelReportRecord[] { return this.dataChange.value; }
    set data(data: ModuleLevelReportRecord[]) {
        this.sourceData = data;
        this.dataChange.next(this.sourceData);
    }

    constructor(private sourceData: ModuleLevelReportRecord[]) {
        this.initialize();
    }

    initialize() {
        this.dataChange.next(this.sourceData);
    }
}

export class ModuleLevelDataSource extends DataSource<any> {
    constructor(private database: ModuleLevelReportDatabase,
        private sort: MatSort) {
        super();
    }


    connect(): Observable<(ModuleLevelReportRecord | ModuleReportDetailRow)[]> {
        const displayDataChanges = [
            this.sort.sortChange,
            this.database.dataChange
        ];
        return merge(...displayDataChanges).pipe(map(() => {
            const rows: (ModuleLevelReportRecord | ModuleReportDetailRow)[] = [];
            const data = this.getSortedData();
            data.forEach(element => rows.push(element, { detailRow: true, element: element }));
            return rows;
        }));
    }

    disconnect() {
        // No-op
    }

    /** Returns a sorted copy of the database data. */
    getSortedData(): ModuleLevelReportRecord[] {
        const data = this.database.data;
        if (!this.sort.active || this.sort.direction == '') { return data; }

        return data.sort((a, b) => {
            let propertyA: number | string = '';
            let propertyB: number | string = '';

            switch (this.sort.active) {
                case 'module': [propertyA, propertyB] = [a.module.name, b.module.name]; break;
                case 'before': [propertyA, propertyB] = [a.before, b.before]; break;
                case 'thisPeriod': [propertyA, propertyB] = [a.thisPeriod, b.thisPeriod]; break;
                case 'tillNow': [propertyA, propertyB] = [a.tillNow, b.tillNow]; break;
            }

            let valueA = isNaN(+propertyA) ? propertyA : +propertyA;
            let valueB = isNaN(+propertyB) ? propertyB : +propertyB;

            return (valueA < valueB ? -1 : 1) * (this.sort.direction == 'asc' ? 1 : -1);
        });
    }
}