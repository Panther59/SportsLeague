﻿import { Component, OnInit, ViewChild, Injectable, Input } from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { DataSource } from "@angular/cdk/collections";
import { MatSort } from "@angular/material";
import { BehaviorSubject } from "rxjs/Rx";
import { Observable } from 'rxjs/Observable';
import { merge } from 'rxjs/observable/merge';
import { map } from 'rxjs/operators/map';
import { TaskLevelReportRecord } from "../_models/index";

@Component({
    moduleId: module.id,
    selector: 'taskLevelReport',
    styleUrls: ['taskLevelReport.component.css'],
    templateUrl: 'taskLevelReport.component.html',
    animations: [
        trigger('detailExpand', [
            state('collapsed', style({ height: '0px', minHeight: '0', visibility: 'hidden' })),
            state('expanded', style({ height: '*', visibility: 'visible' })),
            transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
        ]),
    ]
})

export class TaskLevelReportComponent implements OnInit {

    private _model: TaskLevelReportRecord[];
    get model(): TaskLevelReportRecord[] {
        return this._model;
    }

    @Input()
    set model(input: TaskLevelReportRecord[]) {
        this._model = input;
        this.updateData();
    }

    @ViewChild(MatSort) sort: MatSort;
    displayedColumns = ['expander', 'id', 'task', 'before', 'thisPeriod', 'tillNow'];
    taskLevelDataSource: TaskLevelDataSource;
    taskLevelReportDatabase: TaskLevelReportDatabase;
    isNotExpansionDetailRow = (_index: number, row: TaskLevelReportRecord | TaskReportDetailRow) => !row.hasOwnProperty('detailRow');
    isExpansionDetailRow = (_index: number, row: TaskLevelReportRecord | TaskReportDetailRow) => row.hasOwnProperty('detailRow');
    expandedElement: any;
    headerRowClicked = (row: any) => {
        if (this.expandedElement == row) {
            this.expandedElement = null;
        } else {
            this.expandedElement = row;
        }
    }

    ngOnInit() {
        this.taskLevelReportDatabase = new TaskLevelReportDatabase(this._model);
        this.taskLevelDataSource = new TaskLevelDataSource(this.taskLevelReportDatabase, this.sort);

    }

    updateData() {
        if (this.taskLevelReportDatabase) {
            this.taskLevelReportDatabase.data = this._model;
        }
    }
}


export interface TaskReportDetailRow {
    detailRow: boolean;
    element: TaskLevelReportRecord;
}

export class TaskLevelReportDatabase {
    dataChange: BehaviorSubject<TaskLevelReportRecord[]> = new BehaviorSubject<TaskLevelReportRecord[]>([]);

    get data(): TaskLevelReportRecord[] { return this.dataChange.value; }
    set data(data: TaskLevelReportRecord[]) {
        this.sourceData = data;
        this.dataChange.next(this.sourceData);
    }

    constructor(private sourceData: TaskLevelReportRecord[]) {
        this.initialize();
    }

    initialize() {
        this.dataChange.next(this.sourceData);
    }
}

export class TaskLevelDataSource extends DataSource<any> {
    constructor(private database: TaskLevelReportDatabase,
        private sort: MatSort) {
        super();
    }


    connect(): Observable<(TaskLevelReportRecord | TaskReportDetailRow)[]> {
        const displayDataChanges = [
            this.sort.sortChange,
            this.database.dataChange
        ];
        return merge(...displayDataChanges).pipe(map(() => {
            const rows: (TaskLevelReportRecord | TaskReportDetailRow)[] = [];
            const data = this.getSortedData();
            data.forEach(element => rows.push(element, { detailRow: true, element: element }));
            return rows;
        }));
    }

    disconnect() {
        // No-op
    }

    /** Returns a sorted copy of the database data. */
    getSortedData(): TaskLevelReportRecord[] {
        const data = this.database.data;
        if (!this.sort.active || this.sort.direction == '') { return data; }

        return data.sort((a, b) => {
            let propertyA: number | string = '';
            let propertyB: number | string = '';

            switch (this.sort.active) {
                case 'task': [propertyA, propertyB] = [a.task.name, b.task.name]; break;
                case 'before': [propertyA, propertyB] = [a.before, b.before]; break;
                case 'thisPeriod': [propertyA, propertyB] = [a.thisPeriod, b.thisPeriod]; break;
                case 'tillNow': [propertyA, propertyB] = [a.tillNow, b.tillNow]; break;
            }

            let valueA = isNaN(+propertyA) ? propertyA : +propertyA;
            let valueB = isNaN(+propertyB) ? propertyB : +propertyB;

            return (valueA < valueB ? -1 : 1) * (this.sort.direction == 'asc' ? 1 : -1);
        });
    }
}