﻿import { Component, OnInit, Input, Injectable, ViewChild } from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { DataSource } from "@angular/cdk/collections";
import { MatSort } from "@angular/material";
import { BehaviorSubject } from "rxjs/Rx";
import { Observable } from 'rxjs/Observable';
import { merge } from 'rxjs/observable/merge';
import { map } from 'rxjs/operators/map';

import { TaskLevelReportUserRecord } from "../_models/index";

@Component({
    moduleId: module.id,
    selector: 'taskLevelUserReport',
    styleUrls: ['taskLevelUserReport.component.css'],
    templateUrl: 'taskLevelUserReport.component.html',
    animations: [
        trigger('detailExpand', [
            state('collapsed', style({ height: '0px', minHeight: '0', visibility: 'hidden' })),
            state('expanded', style({ height: '*', visibility: 'visible' })),
            transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
        ]),
    ]
})

export class TaskLevelUserReportComponent implements OnInit {

    @ViewChild(MatSort) sort: MatSort;
    displayedColumns = ['user', 'before', 'thisPeriod', 'tillNow'];
    taskLevelUserDataSource: TaskLevelUserDataSource;
    taskLevelUserReportDatabase: TaskLevelUserReportDatabase;

    private _model: TaskLevelReportUserRecord[];
    get model(): TaskLevelReportUserRecord[] {
        return this._model;
    }

    @Input()
    set model(input: TaskLevelReportUserRecord[]) {
        this._model = input;
        this.updateData();
    }

    updateData() {
        if (this.taskLevelUserReportDatabase) {
            this.taskLevelUserReportDatabase.data = this._model;
        }
    }

    ngOnInit() {
        this.taskLevelUserReportDatabase = new TaskLevelUserReportDatabase(this.model);
        this.taskLevelUserDataSource = new TaskLevelUserDataSource(this.taskLevelUserReportDatabase, this.sort);
    }
}


export interface TaskUserReportDetailRow {
    detailRow: boolean;
    element: TaskLevelReportUserRecord;
}

export class TaskLevelUserReportDatabase {
    dataChange: BehaviorSubject<TaskLevelReportUserRecord[]> = new BehaviorSubject<TaskLevelReportUserRecord[]>([]);

    get data(): TaskLevelReportUserRecord[] { return this.dataChange.value; }
    set data(data: TaskLevelReportUserRecord[]) {
        this.sourceData = data;
        this.dataChange.next(this.sourceData);
    }

    constructor(private sourceData: TaskLevelReportUserRecord[]) {
        this.initialize();
    }

    initialize() {
        this.dataChange.next(this.sourceData);
    }
}

export class TaskLevelUserDataSource extends DataSource<any> {
    constructor(private database: TaskLevelUserReportDatabase,
        private sort: MatSort) {
        super();
    }


    connect(): Observable<(TaskLevelReportUserRecord)[]> {
        const displayDataChanges = [
            this.sort.sortChange,
            this.database.dataChange
        ];
        return merge(...displayDataChanges).pipe(map(() => {
            const data = this.getSortedData();
            return data;
        }));
    }

    disconnect() {
        // No-op
    }

    /** Returns a sorted copy of the database data. */
    getSortedData(): TaskLevelReportUserRecord[] {
        const data = this.database.data;
        if (!this.sort.active || this.sort.direction == '') { return data; }

        return data.sort((a, b) => {
            let propertyA: number | string = '';
            let propertyB: number | string = '';

            switch (this.sort.active) {
                case 'user': [propertyA, propertyB] = [a.user.userName, b.user.userName]; break;
                case 'before': [propertyA, propertyB] = [a.before, b.before]; break;
                case 'thisPeriod': [propertyA, propertyB] = [a.thisPeriod, b.thisPeriod]; break;
                case 'tillNow': [propertyA, propertyB] = [a.tillNow, b.tillNow]; break;
            }

            let valueA = isNaN(+propertyA) ? propertyA : +propertyA;
            let valueB = isNaN(+propertyB) ? propertyB : +propertyB;

            return (valueA < valueB ? -1 : 1) * (this.sort.direction == 'asc' ? 1 : -1);
        });
    }
}