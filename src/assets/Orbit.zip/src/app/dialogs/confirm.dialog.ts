﻿import { Component, Injectable, OnInit, Inject, Input } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";

@Component({
    moduleId: module.id,
    styleUrls: ['confirm.dialog.css'],
    templateUrl: 'confirm.dialog.html'
})

export class ConfirmDialog implements OnInit {

    @Input() title: string;
    @Input() message: string;
    constructor(public dialogRef: MatDialogRef<ConfirmDialog>,
        @Inject(MAT_DIALOG_DATA) public data: any) {

    }
    yes() {
        this.dialogRef.close(true);
    }

    no() {
        this.dialogRef.close(false);
    }

    ngOnInit() {
    }
}