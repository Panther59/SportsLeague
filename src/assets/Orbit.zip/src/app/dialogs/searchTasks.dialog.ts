﻿import { Component, OnInit, Inject, ViewChild, Output, EventEmitter } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { TaskService } from "../_services/index";
import { Task, PagingResult } from "../_models/index";
import { SearchTaskGridComponent } from "../grids/index";
import { Router, NavigationStart } from '@angular/router';

@Component({
    moduleId: module.id,
    styleUrls: ['searchTasks.dialog.css'],
    templateUrl: 'searchTasks.dialog.html'
})

export class SearchTasksDialog implements OnInit {

    taskId: number;
    taskName: string;
    taskService: TaskService;
    taskData: Task;
    router: Router;

    constructor(public dialogRef: MatDialogRef<SearchTasksDialog>,
        @Inject(MAT_DIALOG_DATA) public data: any) {

        this.taskService = data.taskService;
        this.router = data.router;

        this.router.events.subscribe((event) => {
            if (event instanceof NavigationStart) {
                this.close();
            }
        });
    }

    async searchTasks() {
        var task = new Task();
        if (this.taskId && this.taskId.toString().isNullOrEmpty() == false) {
            task.id = this.taskId;
        }

        if (this.taskName && this.taskName.isNullOrEmpty() == false) {
            task.name = this.taskName;
        }

        this.taskData = task
    }


    taskSelected(task: Task) {
        this.dialogRef.close({ task: task });
    }

    ngOnInit() {
    }

    onCloseCancel() {
        this.close();
    }

    close() {
        this.dialogRef.close();
    }
}