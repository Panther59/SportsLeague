import { Component, Injectable, OnInit, Inject } from '@angular/core';
import { User, Task, TaskType, Application, Module } from '../_models/index';
import { TaskService, AlertService, UserService, StorageService, ModuleService } from "../_services/index";
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Observable } from "rxjs/Observable";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { Router, NavigationStart } from '@angular/router';
import * as AppGlobal from "../global";

@Component({
    moduleId: module.id,
    styleUrls: ['addtask.dialog.css'],
    templateUrl: 'addtask.dialog.html'
})

export class AddtaskDialog implements OnInit {

    taskTypes: TaskType[] = [];
    users: User[] = [];
    model: Task = new Task();
    alertService: AlertService;
    storageService: StorageService;
    taskService: TaskService;
    userService: UserService;
    moduleService: ModuleService;
    router: Router;
    taskTypeId: number;
    isNew: boolean;
    title: string;
    selectedApplication: number = -1;
    selectedModule: number = -1;
    applications: Application[];
    modules: Module[];
    @BlockUI() blockUI: NgBlockUI;
    constructor(public dialogRef: MatDialogRef<AddtaskDialog>,
        @Inject(MAT_DIALOG_DATA) public data: any) {

        this.alertService = data.alertService;
        this.moduleService = data.moduleService;
        this.storageService = data.storageService;
        this.taskService = data.taskService;
        this.userService = data.userService;

        this.router = data.router;
        this.router.events.subscribe((event) => {
            if (event instanceof NavigationStart) {
                this.close(false);
            }
        });
    }

    async loadDataForTask(id: number) {
        this.title = "Task Detail";
        this.applications = await this.getApplications();
        this.isNew = false;
        this.blockUI.start("Fetching task information...");
        await Promise.all([
            this.loadTaskTypes(),
            this.loadUsers(),
            this.loadTask(id)
        ])
            .then((data) => this.blockUI.stop())
            .catch((er) => {
                this.alertService.error(er);
                this.blockUI.stop();
            });
    }

    async loadApplication() {
        this.applications = await this.getApplications()
    }

    async getApplications(): Promise<Application[]> {
        if (this.storageService.applications) {
            return this.storageService.applications;
        }
        else {
            let apps = await this.moduleService.getAll().toPromise();
            this.storageService.applications = apps;
            return apps;
        }
    }

    async loadData() {
        this.title = "Add New Task";
        this.isNew = true;
        this.model.priority = "";
        this.blockUI.start("Generating form...");
        await Promise.all([
            this.loadTaskTypes(),
            this.loadUsers(),
            this.loadApplication()
        ])
            .then((data) => {
                this.blockUI.stop();
                this.taskTypeId = -1;
            })
            .catch((er) => {
                this.alertService.error(er);
                this.blockUI.stop();
            });
    }

    private async loadTask(id: number) {
        try {
            this.model = await this.taskService.getTaskById(id).toPromise();
            this.logMessageData(JSON.stringify(this.model));
            this.taskTypeId = this.model.taskType.id;
            this.selectedApplication = this.applications.find((item, index) => item.modules.some((mod, modIndex) => mod.id == this.model.module.id)).id;
            this.applicationChanged();
            this.selectedModule = this.model.module.id;
        }
        catch (er) {
            this.alertService.error(er);
        }
    }

    private canPopupBeClosed(): boolean {
        return !this.isNew;
    }

    private async loadTaskTypes() {
        this.taskTypes = await this.taskService.getTaskTypes().toPromise();
    }

    private async loadUsers() {
        this.users = await this.userService.getAll().toPromise();
    }

    private getCustomDate(input: Date) {
        var convDate = new Date(input);
        return { year: convDate.getFullYear(), month: convDate.getMonth() + 1, day: convDate.getDate() };
    }

    async applicationChanged() {
        var application = this.applications.find((item, index) => item.id == this.selectedApplication);
        if (application) {
            this.modules = application.modules;
            this.selectedModule = -1;
        }
        else {
            this.modules = [];
        }
    }

    save() {
        this.alertService.clear();
        let valid = this.validateInput();
        if (valid) {
            this.blockUI.start("Saving task... please wait...");
            this.model.taskType = new TaskType();
            this.model.taskType.id = this.taskTypeId;
            this.model.module = this.modules.find((item, index) => item.id == this.selectedModule);

            var result = this.taskService.saveTask(this.model).toPromise().then((data) => {
                this.blockUI.stop();
                this.close(true);
            }).catch((er) => {
                this.alertService.error(er);
                this.blockUI.stop();
            });
        }
    }

    private validateInput(): boolean {

        if (Boolean(this.model.id) == false || this.model.id <= 0) {
            this.alertService.error("Invalid Task Id");
            return false;
        }

        if (Boolean(this.taskTypeId) == false || this.taskTypeId <= 0) {
            this.alertService.error("Task type is required");
            return false;
        }

        if (this.checkValidString(this.model.name) == false) {
            this.alertService.error("Name is required");
            return false;
        }

        if (this.checkValidString(this.model.description) == false) {
            this.alertService.error("Description is required");
            return false;
        }

        this.logMessageData("Application: " + this.selectedApplication);

        if (this.selectedApplication <= 0) {
            this.alertService.error("Application is required");
            return false;
        }

        this.logMessageData("Module: " + this.selectedModule);

        if (this.selectedModule <= 0) {
            this.alertService.error("Module is required");
            return false;
        }

        if (this.checkValidString(this.model.priority) == false) {
            this.alertService.error("Priority is required");
            return false;
        }

        if (this.checkValidString(this.model.status) == false) {
            this.alertService.error("Status is required");
            return false;
        }

        return true;
    }

    private checkValidString(input: string): boolean {
        if (Boolean(input) && input.trim().length > 0) {
            return true;
        }
        else {
            return false;
        }
    }

    favoriteChanged() {
        this.logMessageData("Favorite changed");
        if (this.model && this.model.isMyTask) {
            this.model.isMyTask = false;
        }
        else {
            this.model.isMyTask = true;
        }
    }

    close(result: boolean) {
        this.dialogRef.close(result);
    }

    logMessageData(message: string) {
        AppGlobal.logMessageData(message);
    }

    ngOnInit() {
    }
}
