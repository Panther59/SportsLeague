﻿import { Component, Injectable, OnInit, Inject } from '@angular/core';
import { User, Task, TaskType } from '../_models/index';
import { TaskService, AlertService, UserService } from "../_services/index";
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import * as AppGlobal from "../global";
import { Router, NavigationStart } from '@angular/router';

@Component({
    moduleId: module.id,
    styleUrls: ['adduser.dialog.css'],
    templateUrl: 'adduser.dialog.html'
})

export class AdduserDialog implements OnInit {

    types: string[] = [];
    userType: string;
    model: User = new User();
    alertService: AlertService;
    taskService: TaskService;
    userService: UserService;
    router: Router;
    isNew: boolean;
    title: string;
    @BlockUI() blockUI: NgBlockUI;
    constructor(public dialogRef: MatDialogRef<AdduserDialog>,
        @Inject(MAT_DIALOG_DATA) public data: any) {

        this.router = data.router;
        this.router.events.subscribe((event) => {
            if (event instanceof NavigationStart) {
                this.close();
            }
        });
    }

    async loadDataForUser(id: number) {
        this.blockUI.start("Fetching user information...");
        this.title = "User Detail";
        this.isNew = false;
        await Promise.all([
            this.loadTask(id)
        ])
            .then((data) => {
                this.loadTypes();
                this.userType = this.model.type;
                this.blockUI.stop();
            })
            .catch((er) => {
                this.alertService.error(er);
                this.blockUI.stop();
            });
    }

    loadTypes() {
        let types: string[] = [];
        types.push("Please Select");
        types.push("Regular User");
        types.push("Administrator");
        types.push("Super User");
        this.types = types;
    }

    async loadData() {
        this.blockUI.start("Generating form...");
        this.title = "Add New User";
        this.isNew = true;

        this.loadTypes();
        this.userType = "Please Select";
        this.blockUI.stop();
    }

    private async loadTask(id: number) {
        try {
            this.model = await this.userService.getUserById(id).toPromise();
        }
        catch (er) {
            this.alertService.error(er);
        }
    }

    private canPopupBeClosed(): boolean {
        return false;
    }


    private getCustomDate(input: Date) {
        var convDate = new Date(input);
        return { year: convDate.getFullYear(), month: convDate.getMonth() + 1, day: convDate.getDate() };
    }

    save() {
        this.alertService.clear();
        let valid = this.validateInput();
        if (valid) {
            this.blockUI.start("Saving user... please wait...");
            AppGlobal.logMessageData(this.model);
            this.model.type = this.userType;

            if (this.isNew) {
                var result = this.userService.createUser(this.model).toPromise().then((data) => {
                    this.blockUI.stop();
                    this.dialogRef.close(true);
                }).catch((er) => {
                    this.alertService.error(er);
                    this.blockUI.stop();
                });
            }
            else {
                var result = this.userService.updateUser(this.model.id, this.model).toPromise().then((data) => {
                    this.blockUI.stop();
                    this.dialogRef.close(true);
                }).catch((er) => {
                    this.alertService.error(er);
                    this.blockUI.stop();
                });
            }
        }
    }

    private validateInput(): boolean {

        if (Boolean(this.userType) == false || this.userType == "Please Select") {
            this.alertService.error("Type is required");
            return false;
        }

        if (this.checkValidString(this.model.userName) == false) {
            this.alertService.error("User Name is required");
            return false;
        }

        if (this.checkValidString(this.model.firstName) == false) {
            this.alertService.error("First Name is required");
            return false;
        }

        if (this.checkValidString(this.model.lastName) == false) {
            this.alertService.error("Last Name is required");
            return false;
        }

        if (this.checkValidString(this.model.email) == false) {
            this.alertService.error("Email is required");
            return false;
        }

        if (this.checkValidString(this.model.phone) == false) {
            this.alertService.error("Phone is required");
            return false;
        }

        return true;
    }

    private checkValidString(input: string): boolean {
        if (Boolean(input) && input.trim().length > 0) {
            return true;
        }
        else {
            return false;
        }
    }

    close() {
        this.dialogRef.close(false);
    }

    ngOnInit() {
    }
}