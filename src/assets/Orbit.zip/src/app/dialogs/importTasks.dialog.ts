import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { JsonConvert, OperationMode, ValueCheckingMode, JsonObject } from "json2typescript"
import { Router, NavigationStart, ActivatedRoute } from '@angular/router';
import { ImportTask, Task, Module, Application, TaskType, UpdateTask } from "../_models/index";
import { AlertService, StorageService, ModuleService, TaskService, MessageService } from "../_services/index";
import { merge } from 'rxjs/observable/merge';
import { map } from 'rxjs/operators/map';
import { Observable } from 'rxjs/Observable';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import * as XLSX from 'xlsx';
import * as AppGlobal from "../global";

@Component({
    moduleId: module.id,
    styleUrls: ['importTasks.dialog.css'],
    templateUrl: 'importTasks.dialog.html'
})

export class ImportTasksDialog implements OnInit {
    excelLoadingMessage: string = 'Fetching data from excel...';
    startDate: Date;
    endDate: Date;
    isPageLoaded: boolean;
    taskTypes: TaskType[] = [];
    tasks: UpdateTask[];
    applications: Application[];
    modules: Module[];
    isTaskLoaded: boolean;
    taskCount: number;
    @ViewChild('importFilePathInput') importFilePathInput: any;
    importFilePath: string;
    taskService: TaskService;
    moduleService: ModuleService;
    messageService: MessageService;
    alertService: AlertService;
    storageService: StorageService;
    router: Router;
    isExcelReading: boolean;
    isTasksImporting: boolean;
    isTasksImported: boolean;
    arrayBuffer: any;
    importProgress: number;

    constructor(public dialogRef: MatDialogRef<ImportTasksDialog>,
        @Inject(MAT_DIALOG_DATA) public data: any) {

        this.alertService = data.alertService;
        this.moduleService = data.moduleService;
        this.storageService = data.storageService;
        this.taskService = data.taskService;
        this.messageService = data.messageService;
        this.router = data.router;
        this.endDate = new Date(Date.now());
        this.startDate = this.addDayToDate(this.endDate, -7);

        this.router.events.subscribe((event) => {
            if (event instanceof NavigationStart) {
                this.close(false);
            }
        });
    }

    addDayToDate(date: Date, days: number): Date {
        const firstWeekDateNumber = new Date(date).getDate();
        var firstDate = new Date(date);
        let newDate = new Date(firstDate.setDate(firstWeekDateNumber + days));
        return newDate;
    }

    public async loadData() {
        this.applications = await this.getApplications();
        await this.loadTaskTypes();
        this.isPageLoaded = true;
    }

    private async loadTaskTypes() {
        this.taskTypes = await this.taskService.getTaskTypes().toPromise();
    }

    async getApplications(): Promise<Application[]> {
        if (this.storageService.applications) {
            return this.storageService.applications;
        }
        else {
            let apps = await this.moduleService.getAll().toPromise();
            this.storageService.applications = apps;
            return apps;
        }
    }

    fileTarget: File;
    importFilechange(event: any) {
        const target: DataTransfer = <DataTransfer>(event.target);
        if (target.files.length !== 1) throw new Error('Cannot use multiple files');
        this.fileTarget = target.files[0];
    }

    async readFromExcel() {
        if (this.fileTarget) {
            const reader: FileReader = new FileReader();
            reader.onload = (e: any) => this.loadDataFromExcel(e);
            reader.readAsArrayBuffer(this.fileTarget);
        }
    }

    async loadDataFromExcel(e: any) {
        try {
            this.isExcelReading = true;
            // pre-process data
            var binary = "";
            var bytes = new Uint8Array(e.target.result);
            var length = bytes.byteLength;
            for (var i = 0; i < length; i++) {
                binary += String.fromCharCode(bytes[i]);
            }
            // call 'xlsx' to read the file
            var wb = XLSX.read(binary, { type: 'binary', cellDates: true, cellStyles: true });

            ///* read workbook */
            //const bstr: string = e.target.result;
            //const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'buffer' });

            /* grab first sheet */
            let wsname = wb.SheetNames[0];
            let ws = wb.Sheets[wsname];

            /* save data */
            let obj = XLSX.utils.sheet_to_json<ImportTask>(ws);
            //console.log(obj);

            let jsonConvert: JsonConvert = new JsonConvert();
            jsonConvert.operationMode = OperationMode.ENABLE; // print some debug data
            jsonConvert.ignorePrimitiveChecks = false; // don't allow assigning number to string etc.
            jsonConvert.valueCheckingMode = ValueCheckingMode.ALLOW_NULL; // never allow null

            let importedTasks = jsonConvert.deserialize(obj, ImportTask);

            let grouped = importedTasks.groupBy('taskId');
            let tasks = grouped.map((input: AppGlobal.Group<ImportTask>) => {
                /// item going to have latest record which is identified by sorting by updatedOn in desc mode and taking the first element
                const items = input.value.sort(function (a, b) {
                    var dateA: any = new Date(a.updatedOn), dateB: any = new Date(b.updatedOn);
                    return dateB - dateA;
                });
                const item = items[0];

                let task = new UpdateTask();
                task.id = item.taskId;
                task.description = item.description;
                task.module = this.getModuleData(item.module, item.application);
                task.priority = item.priority;
                task.name = item.title;
                task.status = item.status;
                task.type = item.type;
                task.importedTaskType = this.getTaskType(item.type);
                /// get the created date from the list of record and look for minimum date
                task.createdOn = new Date(input.value.reduce(function (agg, obj) { return agg < obj.updatedOn ? agg : obj.updatedOn; }, item.updatedOn));
                task.updatedOn = new Date(item.updatedOn);
                return task;
            });

            this.tasks = tasks.filter((t: UpdateTask, i: number) => (t.createdOn > this.startDate && t.createdOn < this.endDate) || (t.updatedOn > this.startDate && t.updatedOn < this.endDate));
            this.taskCount = this.tasks.length;
            if (this.taskCount > 0) {
                this.isTaskLoaded = true;
            }
        } catch (e) {
            AppGlobal.logErrorData(e);
        }
        finally {
            this.isExcelReading = false;
        }
    }

    orderByDate(arr: any, dateProp: string) {
        return arr.slice().sort(function (a, b) {
            return a[dateProp] < b[dateProp] ? -1 : 1;
        });
    }

    orderByDateDesc(arr: any, dateProp: string) {
        return arr.slice().sort(function (a, b) {
            return a[dateProp] < b[dateProp] ? 1 : -1;
        });
    }

    getModuleData(module: string, application: string): Module {
        if (module) {
            let appSelected = this.applications.find((item, index) => application && item.name && item.name.toLowerCase() == application.toLowerCase() && item.modules.some((m, mmind) => { return m && m.name && module && m.name.toLowerCase() == module.toLowerCase() }));
            if (appSelected) {
                return appSelected.modules.find((m, mmind) => { return m && m.name && module && m.name.toLowerCase() == module.toLowerCase() });
            }
        }
    }

    getTaskType(type: string): TaskType {
        return this.taskTypes.find((item, index) => item.type.toLowerCase() == type.toLowerCase());
    }

    close(result: boolean) {
        this.dialogRef.close(result || this.isTasksImported);
    }

    async saveImportTasks() {
        try {
            let taskToBeImported = this.tasks.filter((t, i) => Boolean(t.isSelected) == true);
            let count = taskToBeImported.length;
            if (count > 0) {
                let completedCount = 0;
                this.importProgress = 0;
                this.isTasksImporting = true;
                AppGlobal.logMessageData(taskToBeImported);
                for (let task of taskToBeImported) {
                    await this.importTask(task);
                    completedCount++;
                    this.importProgress = completedCount * 100 / count;
                    AppGlobal.logMessageData("progress:" + this.importProgress);
                }

                await this.messageService.showMessage("Import", "Importing of task completed");
            }
        } catch (e) {
            AppGlobal.logErrorData(e);
        }
        finally {
            this.isTasksImporting = false;
            this.importProgress = 100;
        }
    }

    async importTask(task: UpdateTask) {
        try {
            task.isImported = false;
            task.isUpdating = true;
            let result = await this.taskService.saveTask(task).toPromise();
            task.isSelected = false;
            task.isImported = true;
            task.isUpdating = false;
        } catch (e) {
            task.isImported = false;
            task.isUpdating = false;
        }
    }

    canPopupBeClosed(): boolean {
        return true;
    }

    ngOnInit() {
    }
}
