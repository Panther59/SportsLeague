﻿import { Component, Injectable, OnInit, Inject, Input } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";

@Component({
    moduleId: module.id,
    styleUrls: ['message.dialog.css'],
    templateUrl: 'message.dialog.html'
})

export class MessageDialog implements OnInit {

    @Input() title: string;
    @Input() message: string;
    @Input() buttonText: string = "Close";

    constructor(public dialogRef: MatDialogRef<MessageDialog>,
        @Inject(MAT_DIALOG_DATA) public data: any) {

    }

    close() {
        this.dialogRef.close();
    }

    ngOnInit() {
    }
}