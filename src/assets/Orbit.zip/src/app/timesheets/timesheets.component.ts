import { Component, OnInit, Input, Output, EventEmitter, ContentChild, ViewChild } from '@angular/core';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Title } from '@angular/platform-browser';

import { Timesheet, TimeRecord, Task, DayHour } from "../_models/index";
import { TaskService, TimesheetService, StorageService, MessageService } from "../_services/index";
import { TimesheetComponent } from "../timesheet/index";
import * as AppGlobal from "../global";

@Component({
    moduleId: module.id,
    styleUrls: ['timesheets.component.css'],
    templateUrl: 'timesheets.component.html'
})

export class TimesheetsComponent implements OnInit {

    timesheets: Timesheet[] = [];
    timesheet: Timesheet;
    timesheetsCount: number;
    weekEndingModel: any = {};
    tasks: Task[];
    canReopen: boolean = false;
    canSubmit: boolean = false;
    isTimesheetsLoaded: boolean = false;
    isTimesheetLoaded: boolean = false;
    isPageLoaded: boolean = false;
    readOnly: boolean = true;
    weekStartingDate: Date;
    weekEndingDate: Date;
    //weekEndingDateDisplay: any;
    @BlockUI() blockUI: NgBlockUI;
    loadingTimesheetMessage: string = "Loading your current timesheet";
    loadingTimesheetsMessage: string = "Loading your submitted timesheets";
    @ViewChild('currentTimesheet') currentTimesheet: TimesheetComponent;

    constructor(
        private taskService: TaskService,
        private titleService: Title,
        private messageService: MessageService,
        private timesheetService: TimesheetService,
        private storageService: StorageService) {

        this.titleService.setTitle("Timesheet | Orbit");
    }

    private async loadTasks() {
        this.tasks = await this.taskService.getAllMyTasks().toPromise();
    }

    private async loadTimesheets() {
        if (this.storageService.currentUser) {
            this.timesheets = await this.timesheetService.getAll(this.storageService.currentUser.id).toPromise();
            this.timesheetsCount = this.timesheets.length;
            this.isTimesheetsLoaded = true;
        }
    }

    //addNewTimeRecord() {
    //    if (this.timesheet && this.timesheet.timesheetDetails) {
    //        var blankRec = new TimeRecord()
    //        blankRec.task = new Task();
    //        blankRec.task.id = -1;
    //        this.currentTimesheet.addDaysToRecord(blankRec, this.weekStartingDate, this.weekEndingDate);
    //        this.timesheet.timesheetDetails.push(blankRec);
    //    }
    //}

    reloadTimesheets(event: Event) {
        this.loadTimesheets();
    }

    private async getTimesheetRecord(date: Date) {
        if (this.storageService.currentUser) {
            var timesheet = await this.timesheetService.getUserTimesheetForDate(this.storageService.currentUser.id, date).toPromise();
            this.loadTimesheetFromDB(timesheet);
        }
    }

    private loadTimesheetFromDB(timesheet: Timesheet) {
        if (timesheet) {
            //this.headerRecord = new TimeRecord();
            //this.addDaysToRecord(this.headerRecord, timesheet.timesheetPeriod.startDate, timesheet.timesheetPeriod.endDate);
            if (!timesheet.timesheetDetails || timesheet.timesheetDetails.length === 0) {
                timesheet.timesheetDetails = [];
                var blankRec = new TimeRecord()
                blankRec.task = new Task();
                blankRec.task.id = -1;
                timesheet.timesheetDetails.push(blankRec);
            }

            //timesheet.timesheetDetails.forEach((item, index) => {
            //    this.addDaysToRecord(item, timesheet.timesheetPeriod.startDate, timesheet.timesheetPeriod.endDate);
            //});

            this.timesheet = timesheet;
            this.setWeekDates(timesheet.timesheetPeriod.startDate, timesheet.timesheetPeriod.endDate);
            this.setReadOnly(timesheet.status);
            this.isTimesheetLoaded = true;
        }
    }

    private setReadOnly(status: string) {
        switch (status.toLowerCase()) {
            case "draft":
                this.canReopen = false;
                this.canSubmit = true;
                this.readOnly = false;
                break;
            case "open":
                this.canReopen = false;
                this.canSubmit = true;
                this.readOnly = false;
                break;
            case "submitted":
                this.canReopen = true;
                this.canSubmit = false;
                this.readOnly = true;
                break;
            case "processed":
                this.canReopen = true;
                this.canSubmit = false;
                this.readOnly = true;
                break;
            case "closed":
                this.canReopen = false;
                this.canSubmit = false;
                this.readOnly = true;
                break;
            default:
                this.canReopen = false;
                this.canSubmit = false;
                this.readOnly = true;
                break;
        }

    }

    async onDateChanged(date: Date) {
        if (this.isPageLoaded) {
            this.weekEndingDate = date;
            await this.getTimesheetRecord(date);
        }
    }

    async timesheetDetail(timesheetId: number) {
        if (timesheetId) {
            this.blockUI.start("Loading timesheet...please wait...");
            let timesheet = await this.timesheetService.getTimesheetById(timesheetId).toPromise();
            this.loadTimesheetFromDB(timesheet);
            this.blockUI.stop();
        }
    }

    async submitTimeSheet() {
        if (this.storageService.currentUser) {
            if (this.validatedData()) {
                this.blockUI.start("Saving timesheet...please wait...");
                var result = await this.timesheetService.saveTimesheet(this.storageService.currentUser.id, this.timesheet).toPromise().then((data) => {
                    this.messageService.showMessage("Timesheet", "Timesheet has beed saved successfully");
                    this.loadTimesheetFromDB(data);
                    this.loadTimesheets();
                }).catch((err) => {
                    AppGlobal.logErrorData(err);
                    this.messageService.showMessage("Timesheet", "Error occured while saving timesheet, please try again later.");
                });
                this.blockUI.stop();
            }
        }
    }

    validatedData(): boolean {
        if (this.timesheet.timesheetDetails == null || this.timesheet.timesheetDetails.length <= 0) {
            this.messageService.showMessage("Timesheet", "No timesheet task selected");
            return false;
        }

        let itemsTasks = this.timesheet.timesheetDetails.find((item, index) => item.total > 0 && (item.task == null || item.task.id < 0));
        if (itemsTasks != null) {
            this.messageService.showMessage("Timesheet", "For one of the rows hours are present but task is not selected");
            return false;
        }

        return true;
    }

    reopenTimeSheet() {
        this.timesheet.status = "Open";
        this.setReadOnly(this.timesheet.status);
    }
    private setWeekDates(startDate: Date, endDate: Date) {
        this.weekStartingDate = startDate;
        this.weekEndingDate = endDate;
    }

    exportTimeSheet() {
        this.currentTimesheet.exportTimeSheet();
    }

    async ngOnInit() {
        try {
            this.blockUI.start("Loading timesheets...please wait...");

            await Promise.all([
                this.loadTimesheets(),
                this.loadTasks(),
                this.getTimesheetRecord(new Date(Date.now()))
            ]);

            this.blockUI.stop();
            this.isPageLoaded = true;
        } catch (e) {
            this.blockUI.stop();
            AppGlobal.logErrorData(e);
        }
    }
}
