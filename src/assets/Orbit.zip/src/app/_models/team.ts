﻿import { Application, TimesheetPeriod, Timesheet, User } from "./index";

export class Team {
    period: TimesheetPeriod;
    users: TeamUserTimesheet[];
}

export class TeamUserTimesheet {
    timesheet: Timesheet;
    user: User;
    userName: string;
    status: string;
    hours: number;
}