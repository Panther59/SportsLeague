﻿import { Module } from "./index";

export class Application {
    id: number;
    name: string;
    modules: Module[];
}