﻿import { TimeRecord, TimesheetPeriod } from "./index";

export class Timesheet {
    id: number;
    title: string;
    week: number;
    year: number;
    status: string;
    isCurrent: boolean;
    Version: number;
    timesheetDetails: TimeRecord[];
    timesheetPeriod: TimesheetPeriod;
}
export class TimesheetTaskDetail {
    srNo: number;
    id: number;
    title: string;
    user: string;
    weekHrs: number;
    totalHrs: number;
    type: string;
    module: string;
    priority: string;
    status: string;
    createdDate: string;
    modifiedDate: string;
    category: string;
}
