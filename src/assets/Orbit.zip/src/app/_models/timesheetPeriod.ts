﻿export class TimesheetPeriod {
    id: number;
    startDate: Date;
    endDate: Date;
    days: number;
    isCurrent: boolean;
}