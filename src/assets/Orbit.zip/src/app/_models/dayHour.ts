﻿export class DayHour {
    date: Date;
    hours: number;
    isHoliday: boolean;
    isLeave: boolean;
}