﻿import { Task, User, } from "./index";

export class Leave {
    approvedByUser: User;
    approvedOn: Date
    date: Date;
    hour: number;
    id: number;
    leaveUser: User;
    status: number;
    task: Task;
}
