﻿import { Leave } from "./leave";

export class Day {
    date: Date;
    checked: boolean;
    isCurrentMonth: boolean;
    isWeekEnd: boolean = false;
    color: string;
    content: any;
    leave: Leave;
    isPersonalLeaveTaken: boolean;
    isSickLeaveTaken: boolean;
    canRemoveLeave: boolean;
}