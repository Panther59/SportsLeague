﻿import { Day } from "./day";

export class Week {
    weekNumber: number;
    startDate: Date;
    endDate: number;
    month: number;
    year: number;
    days: Day[]
}