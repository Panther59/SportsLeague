﻿import { JsonObject, JsonProperty, JsonCustomConvert, JsonConverter } from "json2typescript";
import { Task } from "./task";

@JsonConverter
export class StringToNumberConverter implements JsonCustomConvert<number> {
    deserialize(input: any): number {
        return +input;
    }

    serialize(input: number): any {
        return input.toString();
    }
}

@JsonConverter
export class PriorityConverter implements JsonCustomConvert<string> {
    deserialize(input: any): string {
        let output = input;
        switch (input) {
            case 'CRITICAL': {
                output = 'P1';
                break;
            }
            case 'HIGH': {
                output = 'P2';
                break;
            }
            case 'MEDIUM': {
                output = 'P3';
                break;
            }
            case 'LOW': {
                output = 'P4';
                break;
            }

            default: {
                break;
            }
        }

        return output;
    }

    serialize(input: string): any {
        return input;
    }
}

@JsonObject
export class ImportTask {
    @JsonProperty("Ticket No", StringToNumberConverter)
    taskId: number = undefined;
    @JsonProperty("Type", String, true)
    type: string = undefined;
    @JsonProperty("Application", String, true)
    application: string = undefined;
    @JsonProperty("Module", String, true)
    module: string = undefined;
    @JsonProperty("Title", String, true)
    title: string = undefined;
    @JsonProperty("Status", String, true)
    status: string = undefined;
    @JsonProperty("Description", String, true)
    description: string = undefined;
    @JsonProperty("Priority", PriorityConverter)
    priority: string = undefined;
    @JsonProperty("Last Updated On", PriorityConverter)
    updatedOn: Date = undefined;
}

export class UpdateTask extends Task{
    isSelected: boolean;
    isUpdating: boolean;
    isImported: boolean;
}
