﻿import { Task, DayHour } from "./index";

export class TimeRecord{
    task: Task;
    timesheetDayHours: DayHour[];
    total: number;
}