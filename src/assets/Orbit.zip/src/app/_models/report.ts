﻿import { TimesheetPeriod, Task, User, Module } from "./index";

export class TaskLevelReport {
    period: TimesheetPeriod;
    records: TaskLevelReportRecord[];
}

export class ModuleLevelReport {
    period: TimesheetPeriod;
    records: ModuleLevelReportRecord[];
}

export class TaskLevelReportRecord {
    task: Task;
    thisPeriod: number;
    tillNow: number;
    before: number;
    users: TaskLevelReportUserRecord[];
    get userCount(): number {
        if (this.users) {
            return this.users.length;
        }
        else {
            return 0;
        }
    }
}

export class ModuleLevelReportRecord {
    module: Module;
    thisPeriod: number;
    tillNow: number;
    before: number;
    tasks: TaskLevelReportRecord[];
}

export class TaskLevelReportUserRecord {
    user: User;
    thisPeriod: number;
    tillNow: number;
    before: number;
}

export class TaskReportExcel {
    taskId: number;
    taskName: string;
    thisPeriod: number;
    tillNow: number;
    before: number;
}

export class TaskUserReportExcel {
    taskId: number;
    taskName: string;
    userName: string;
    thisPeriod: number;
    tillNow: number;
    before: number;
}