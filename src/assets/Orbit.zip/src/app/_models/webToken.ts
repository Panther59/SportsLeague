﻿export class WebToken {
    accessToken: string;
    expiresOn: Date;
    refreshToken: string;
    userID: number;
}