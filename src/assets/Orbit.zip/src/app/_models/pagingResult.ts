﻿export class PagingResult<T> {
    pageNumber: number;
    pageSize: number;
    total: number
    records: Array<T>;
}