﻿export class ServiceError {
    Code: number;
    GUID: string;
    Message: string;
}