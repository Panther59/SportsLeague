﻿import { Application } from "./index";

export class Module {
    id: number;
    name: string;
    application: Application;
}