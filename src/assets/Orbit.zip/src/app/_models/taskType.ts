﻿export class TaskType {
    id: number;
    type: string;
}