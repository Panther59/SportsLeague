﻿import { User } from "./user";

export class ChangePassword {
    user: User;
    currentPassword: string;
    newPassword: string;
    retypeNewPassword: string;
}