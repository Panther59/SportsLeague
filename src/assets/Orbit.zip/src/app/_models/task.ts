﻿import { TaskType, User, Module, Application } from "./index";

export class Task {
    id: number;
    isMyTask: boolean;
    name: string;
    description: string;
    type: string;
    module: Module;
    priority: string;
    status: string;
    taskType: TaskType;
    importedTaskType: TaskType;
    updatedOn: Date;
    createdOn: Date;
    createdByUser: User;
    updatedByUser: User;
}