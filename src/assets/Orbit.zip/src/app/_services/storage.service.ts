﻿import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User, Application } from '../_models/index';

@Injectable()
export class StorageService {

    private readonly applicationsKey = "applications";
    private readonly currentUserKey = "currentUser";
    private readonly tokenKey = "token";
    private readonly themeKey = "theme";

    get currentUser(): User {
        return this.getStorageData<User>(this.currentUserKey);
    };

    set currentUser(user: User) {
        this.setStorageData(this.currentUserKey, user);
    }

    get theme(): string {
        return this.getStorageString(this.themeKey);
    };

    set theme(theme: string) {
        this.setStorageString(this.themeKey, theme);
    }

    get token(): string {
        return this.getStorageString(this.tokenKey);
    };

    set token(token: string) {
        this.setStorageString(this.tokenKey, token);
    }

    get applications(): Application[] {
        return this.getStorageData<Array<Application>>(this.applicationsKey);
    };

    set applications(input: Application[]) {
        this.setStorageData(this.applicationsKey, input);
    }

    private getStorageData<T>(key: string) {
        return JSON.parse(localStorage.getItem(key)) as T;
    }

    private getStorageString(key: string) {
        return localStorage.getItem(key);
    }

    private setStorageData(key: string, data: object) {
        var strData = null;
        if (data != null) {
            strData = JSON.stringify(data);
        }
        this.setStorageString(key, strData);
    }

    private setStorageString(key: string, data: string) {
        if (data == null) {
            localStorage.removeItem(key);
        }
        else {
            localStorage.setItem(key, data);
        }
    }

}