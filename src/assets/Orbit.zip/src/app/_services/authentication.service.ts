﻿import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Router, ActivatedRoute } from '@angular/router';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Keepalive } from '@ng-idle/keepalive';
import 'rxjs/add/operator/map';
import 'rxjs/Rx';

import { StorageService } from "./storage.service";
import { UserService } from "./user.service";
import { MessageService } from "./message.service";
import { WebToken, ServiceError } from '../_models/index'
import * as AppGlobal from "../global";

@Injectable()
export class AuthenticationService {
    @BlockUI() blockUI: NgBlockUI;
    timedOut = false;
    constructor(private httpClient: HttpClient,
        private storageService: StorageService,
        private userService: UserService,
        private messageService: MessageService,
        private router: Router,
        private idle: Idle,
        private keepalive: Keepalive) {
    }

    setupIdleMonitor() {

        // sets an idle timeout of 180 seconds, for testing purposes.
        this.idle.setIdle(600);
        // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
        this.idle.setTimeout(5);
        // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
        this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

        this.idle.onTimeout.subscribe(() => {
            this.logout();
            this.messageService.showMessage("Orbit", "Your session has expired... please log in...").then((data) => {
                this.navigateToLogin(true);
            }).catch((er) => {
                AppGlobal.logErrorData(er);
                this.navigateToLogin(true);
            });
        });

        // sets the ping interval to 15 seconds
        this.keepalive.interval(15);
    }

    navigateToLogin(passReturnUrl: boolean) {
        if (passReturnUrl) {
            this.router.navigate(['/login'], { queryParams: { returnUrl: this.router.url } });
        }
        else {
            this.router.navigate(["/login"]);
        }
    }

    appllicationStartup() {
        this.setupIdleMonitor();
        if (this.storageService.token != null) {
            this.blockUI.start("Loading...")
            this.userService.getCurrentUser().subscribe((data) => {
                this.storageService.currentUser = data;
                this.resetIdleCounter();
                this.blockUI.stop();
            },
                (error) => {
                    this.logout();
                    this.navigateToLogin(false);
                    this.blockUI.stop();
                });
        }
    }

    resetIdleCounter() {
        this.idle.watch();
        this.timedOut = false;
    }

    login(username: string, password: string) {
        let headers: HttpHeaders = new HttpHeaders().set("Authorization", "Basic " + btoa(username + ":" + password));
        headers.append("Content-Type", 'application/json');
        return this.httpClient.get<WebToken>('api/token', { headers: headers })
            .map((token: WebToken) => {
                // login successful if there's a jwt token in the response
                if (token && token.accessToken) {
                    // store user details and jwt token in local storage to keep user logged in between page refreshes
                    this.storageService.token = token.accessToken;
                }
                this.resetIdleCounter();
                return token;
            }); 
    }

    logout() {
        // remove user from local storage to log user out
        this.storageService.currentUser = null;
        this.storageService.token = null;
        this.storageService.applications = null;
        this.timedOut = true;
        this.idle.stop();
    }
}