﻿import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Application, Module } from '../_models/index'

@Injectable()
export class ModuleService {
    constructor(private httpClient: HttpClient) { }

    getAll(): Observable<Array<Application>> {
        return this.httpClient.get<Array<Application>>('api/modules');
    }

    saveModule(app: Application): Observable<Module> {
        return this.httpClient.put<Module>('api/modules', app);
    }
}