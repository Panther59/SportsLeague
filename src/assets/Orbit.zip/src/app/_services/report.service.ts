﻿import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { User, Timesheet, TimesheetPeriod, TaskLevelReport, ModuleLevelReport } from '../_models/index'

@Injectable()
export class ReportService {
    constructor(private httpClient: HttpClient) { }

    getAllTasks(period: TimesheetPeriod): Observable<TaskLevelReport> {
        return this.httpClient.post<TaskLevelReport>('api/reports/tasklevel', period);
    }

    getAllMyTasks(period: TimesheetPeriod): Observable<TaskLevelReport> {
        return this.httpClient.post<TaskLevelReport>('api/reports/current/tasklevel', period);
    }

    getAllModules(period: TimesheetPeriod): Observable<ModuleLevelReport> {
        return this.httpClient.post<ModuleLevelReport>('api/reports/modulelevel', period);
    }
}