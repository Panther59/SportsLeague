﻿import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { User, Timesheet } from '../_models/index'

@Injectable()
export class TimesheetService {
    constructor(private httpClient: HttpClient) { }

    getAll(userId: number): Observable<Array<Timesheet>> {
        return this.httpClient.get<Array<Timesheet>>('api/users/' + userId + '/timesheets');
    }

    getUserTimesheetForDate(userId: number, date: Date): Observable<Timesheet> {
        return this.httpClient.post<Timesheet>('api/users/' + userId + '/timesheet', date);
    }

    getTimesheetById(id: number): Observable<Timesheet> {
        return this.httpClient.get<Timesheet>('api/timesheets/' + id);
    }
    
    saveTimesheet(userId: number, timesheet: Timesheet): Observable<Timesheet> {
        return this.httpClient.put<Timesheet>('api/users/' + userId + '/timesheet', timesheet);
    }
}