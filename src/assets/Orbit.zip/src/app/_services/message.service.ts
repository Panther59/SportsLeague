﻿import { Injectable } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';
import { MessageDialog, ConfirmDialog } from '../dialogs/index';
import { Observable } from 'rxjs';
import { Subject } from 'rxjs/Subject';
import { MatSort, MatPaginator, MatDialog, MatDialogRef, DialogRole } from "@angular/material";

@Injectable()
export class MessageService {
    private subject = new Subject<any>();
    constructor(
        public dialog: MatDialog) { }
    sendMessage(message: string) {
        this.subject.next({ text: message });
    }

    clearMessage() {
        this.subject.next();
    }

    getMessage(): Observable<any> {
        return this.subject.asObservable();
    }

    async showMessage(title: string, message: string, buttonText: string = null): Promise<void> {
        var result: boolean;
        var msgRef = this.dialog.open(MessageDialog, {
            data: {},
            disableClose: true,
            hasBackdrop: true });
        msgRef.componentInstance.title = title;
        msgRef.componentInstance.message = message;
        if (buttonText != null) {
            msgRef.componentInstance.buttonText = buttonText;
        }
        return await msgRef.afterClosed().toPromise();
    }

    async confirm(title: string, message: string): Promise<boolean> {
        var result: boolean;
        var msgRef = this.dialog.open(ConfirmDialog, {
            data: {},
            disableClose: true,
            hasBackdrop: true });
        msgRef.componentInstance.title = title;
        msgRef.componentInstance.message = message;
        return await msgRef.afterClosed().toPromise();
    }
}