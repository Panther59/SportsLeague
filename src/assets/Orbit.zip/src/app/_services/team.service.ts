﻿import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Team, User } from '../_models/index'

@Injectable()
export class TeamService {
    constructor(private httpClient: HttpClient) { }

    getTeamDetail(date: Date): Observable<Team> {
        return this.httpClient.post<Team>('api/team/detail', date);
    }

    addTeamMember(userId: number): Observable<string> {
        return this.httpClient.put<string>('api/team/' + userId, null);
    }

    removeTeamMember(userId: number): Observable<string> {
        return this.httpClient.delete<string>('api/team/' + userId);
    }
}