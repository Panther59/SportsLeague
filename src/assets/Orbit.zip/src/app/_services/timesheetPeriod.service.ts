﻿import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { User, Timesheet, TimesheetPeriod } from '../_models/index'

@Injectable()
export class TimesheetPeriodService {
    constructor(private httpClient: HttpClient) { }

    getAll(): Observable<Array<TimesheetPeriod>> {
        return this.httpClient.get<Array<TimesheetPeriod>>('api/timesheetperiods');
    }

    getPeriodByDate(date: Date): Observable<TimesheetPeriod> {
        return this.httpClient.post<TimesheetPeriod>('api/timesheetperiods', date);
    }
}