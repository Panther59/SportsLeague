﻿import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { User, ChangePassword } from '../_models/index'

@Injectable()
export class UserService {
    constructor(private httpClient: HttpClient) { }

    getAll(): Observable<Array<User>> {
        return this.httpClient.get<Array<User>>('api/users');
    }

    getCurrentUser(): Observable<User> {
        return this.httpClient.get<User>('api/user');
    }

    getUserById(id: number): Observable<User> {
        return this.httpClient.get<User>('api/users/' + id);
    }

    createUser(user: User): Observable<User> {
        return this.httpClient.put<User>('api/user', user);
    }

    updateUser(id: number, user: User): Observable<User> {
        return this.httpClient.put<User>('api/users/' + id, user);
    }

    deleteUser(id: number): Observable<User> {
        return this.httpClient.delete<User>('api/users/' + id);
    }

    changePassword(data: ChangePassword): Observable<User> {
        return this.httpClient.post<User>('api/user/changePassword', data);
    }
}