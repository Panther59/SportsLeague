﻿import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs';
import { Task, PagingResult, TimesheetPeriod, Leave } from '../_models/index';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';

@Injectable()
export class LeaveService {
    constructor(private http: HttpClient) { }

    getTaskTypes(userId: number, period: TimesheetPeriod): Observable<Array<Leave>> {
        return this.http.post<Array<Leave>>('api/users/' + userId + '/leaves', period);
    }

    saveTask(userId: number, leaves: Leave[]): Observable<void> {
        return this.http.put<void>('api/users/' + userId + '/leaves', leaves);
    }
}