﻿import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs';
import { Task, TaskType, PagingResult } from '../_models/index';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';

@Injectable()
export class TaskService {
    constructor(private http: HttpClient) { }

    getAll(pageSize: number = 10, pageNumber: number = 1, orderBy: string = null, sort: string = null): Observable<PagingResult<Task>> {
        let url = 'api/tasks/' + pageSize + "/" + pageNumber;
        if (orderBy) {
            url = url + "?orderBy=" + orderBy;
            if (sort) {
                url = url + "&sort=" + sort;
            }
        }
        return this.http.get<PagingResult<Task>>(url);
    }

    searchTasks(task: Task, pageSize: number = 10, pageNumber: number = 1, orderBy: string = null, sort: string = null): Observable<PagingResult<Task>> {
        let url = 'api/tasks/' + pageSize + "/" + pageNumber;
        if (orderBy) {
            url = url + "?orderBy=" + orderBy;
            if (sort) {
                url = url + "&sort=" + sort;
            }
        }

        return this.http.post<PagingResult<Task>>(url, task);
    }

    getAllMyTasks(): Observable<Array<Task>> {
        return this.http.get<Array<Task>>('api/mytasks');
    }

    getAllLeaveTasks(): Observable<Array<Task>> {
        return this.http.get<Array<Task>>('api/leavetasks');
    }

    getTaskById(id: number): Observable<Task> {
        return this.http.get<Task>('api/tasks/' + id);
    }

    getTaskTypes(): Observable<Array<TaskType>> {
        return this.http.get<Array<TaskType>>('api/taskTypes');
    }

    saveTask(task: Task): Observable<Task> {
        return this.http.put<Task>('api/tasks', task);
    }
}