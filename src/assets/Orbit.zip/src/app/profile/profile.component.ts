﻿import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Title } from '@angular/platform-browser';
import { AlertService, AuthenticationService, UserService, MessageService, StorageService } from "../_services/index";
import { ChangePassword, ServiceError } from "../_models/index";
import * as AppGlobal from "../global";

@Component({
    moduleId: module.id,
    styleUrls: ['profile.component.css'],
    templateUrl: 'profile.component.html'
})

export class ProfileComponent implements OnInit {
    model: ChangePassword = new ChangePassword();
    @BlockUI() blockUI: NgBlockUI;

    constructor(
        private router: Router,
        private authenticationService: AuthenticationService,
        private userService: UserService,
        private messageService: MessageService,
        private storageService: StorageService,
        private alertService: AlertService,
        private titleService: Title) {
        this.titleService.setTitle("Profile | Orbit");
    }

    ngOnInit() {
    }

    async changePassword() {
        AppGlobal.logMessageData("Changing password");
        this.alertService.clear();
        if (this.validate()) {
            this.blockUI.start("Changing your password...");
            try {
                var pass = new ChangePassword();
                pass.user = this.storageService.currentUser;
                pass.currentPassword = btoa(this.model.currentPassword);
                pass.newPassword = btoa(this.model.newPassword);
                pass.retypeNewPassword = btoa(this.model.retypeNewPassword);
                let result = await this.userService.changePassword(pass).toPromise();
                this.blockUI.stop();
                this.storageService.currentUser = null;
                await this.messageService.showMessage("Password Change", "Your password has been changed, please login using new credentials.");
                this.authenticationService.logout();
                this.router.navigate(['/login']);
            }
            
            catch (ex) {
                this.blockUI.stop();
                const err: string = JSON.stringify(ex.error);
                AppGlobal.logErrorData(err);
                let errObj: ServiceError = JSON.parse(ex.error);
                if (errObj && errObj.Message) {
                    this.alertService.error(errObj.Message);
                }
                else {
                    this.alertService.error("Unauthorized");
                }
            }
        }
    }

    validate() {
        if (this.model.newPassword && this.model.newPassword == this.model.currentPassword) {
            this.alertService.error("New Password can not be same as old password.")
            return false;
        }

        if (this.model.newPassword && this.model.newPassword != this.model.retypeNewPassword) {
            this.alertService.error("Current Password and retyped password do not match.")
            return false;
        }

        return true;
    }
}