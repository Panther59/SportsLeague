﻿declare module 'file-saver';
