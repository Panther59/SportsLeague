import { Component, OnInit, ViewChild } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Router, NavigationStart, ActivatedRoute } from '@angular/router';
import { TaskService, MessageService, AlertService, UserService, StorageService, ModuleService } from '../_services/index';
import { Task } from '../_models/index';
import { slideInOutAnimation } from '../_animations/index';
import { AddtaskDialog, ImportTasksDialog } from '../dialogs/index';
import 'rxjs/add/operator/map';
import 'rxjs/Rx';
import { Observable } from "rxjs/Rx";
import { TaskGridComponent } from "../grids/index";
import { MatDialog, MatDialogRef } from '@angular/material';
import * as AppGlobal from "../global";

@Component({
    moduleId: module.id,
    animations: [slideInOutAnimation],
    styleUrls: ['tasks.component.css'],
    templateUrl: 'tasks.component.html',
})

export class TasksComponent implements OnInit {
    @ViewChild('taskGrid') taskGrid: TaskGridComponent;
    allTasks: Task[] = [];
    tasks: Task[] = [];
    error: string;
    isTaskLoaded: boolean = false;
    searchText: string;
    counter: number = 0;

    taskId: number;
    taskName: string;
    taskData: Task;

    ngOnInit() {
        this.activatedRoute.params.subscribe(params => {
            if (params['id']) {
                let num = +params['id'];
                this.taskService.getTaskById(num).subscribe((data) => {
                    if (data) {
                        this.taskDetail(data);
                    }
                    else {
                        this.messageService.showMessage("Task", "No task such task found");
                        this.router.navigate(["/tasks"]);
                    }
                }, (err) => {
                    this.messageService.showMessage("Task", err);
                    this.router.navigate(["/tasks"]);
                });
            }
        });
    }

    constructor(
        public dialog: MatDialog,
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private titleService: Title,
        private storageService: StorageService,
        private taskService: TaskService,
        private moduleService: ModuleService,
        private userService: UserService,
        private messageService: MessageService,
        private alertService: AlertService) {
        this.titleService.setTitle("Tasks | Orbit");
        this.getAllTasks();
            // NavigationEnd
            // NavigationCancel
            // NavigationError
            // RoutesRecognized
    }

    searchTasks() {
        var task = new Task();
        if (this.taskId && this.taskId.toString().isNullOrEmpty() == false) {
            task.id = this.taskId;
        }

        if (this.taskName && this.taskName.isNullOrEmpty() == false) {
            task.name = this.taskName;
        }

        this.taskData = task
    }

    async importTasks() {
        let importTasksDialogRef = this.dialog.open(ImportTasksDialog, {
            panelClass: 'my-centered-dialog',
            data: {
                alertService: this.alertService,
                taskService: this.taskService,
                messageService: this.messageService,
                moduleService: this.moduleService,
                storageService: this.storageService,
                router: this.router
            }, 
            closeOnNavigation: true,
            disableClose: true,
            hasBackdrop: true
        });
        importTasksDialogRef.componentInstance.loadData();
        importTasksDialogRef.afterClosed().subscribe(result => {
            if (result) {
                this.getAllTasks();
            }
        });
    }

    //private searchTextChanged() {
    //    this.counter = this.counter + 1;
    //    this.delaySearch(this.counter);
    //}

    //async delaySearch(cnt: number) {
    //    setTimeout(() => this.applyFilter(cnt), 1000);
    //}

    //async applyFilter(cnt: number) {
    //    if (cnt == this.counter) {
    //        if (this.searchText) {
    //            var parts = this.searchText.toLowerCase().split(';').filter(y => y.trim() != '');
    //            var filteredtask = this.allTasks.filter(x => parts.findIndex(y =>
    //                x.id.toString().includes(y) ||
    //                x.name.toLowerCase().includes(y) ||
    //                x.description.toLowerCase().includes(y)) != -1);
    //            this.tasks = filteredtask;
    //            this.taskCount = filteredtask.length;
    //        }
    //        else {
    //            this.tasks = this.allTasks;
    //            this.taskCount = this.tasks.length;
    //        }
    //    }
    //}

    logMessageData(message: string) {
        AppGlobal.logMessageData(message);
    }

    async taskDetail(task: Task) {
        let dialogRef = this.getTaskPopup();
        dialogRef.componentInstance.loadDataForTask(task.id);
    }

    getTaskPopup(): MatDialogRef<AddtaskDialog> {
        let dialogRef = this.dialog.open(AddtaskDialog, {
            data: {
                alertService: this.alertService,
                taskService: this.taskService,
                userService: this.userService,
                moduleService: this.moduleService,
                storageService: this.storageService,
                router: this.router
            },
            closeOnNavigation: true,
            disableClose: true,
            hasBackdrop: true,
        });
        dialogRef.afterClosed().subscribe(result => {
            if (result) {
                this.getAllTasks();
            }
        });

        return dialogRef;
    }

    async openNewTask() {
        var addDialogRef = this.getTaskPopup();
        addDialogRef.componentInstance.loadData();
    }

    taskUpdated() {
        this.getAllTasks();
    }

    private getAllTasks() {
        if (this.taskGrid) {
            this.taskGrid.loadTasksPage();
        }
    }
}
