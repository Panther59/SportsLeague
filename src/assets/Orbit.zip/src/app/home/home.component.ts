﻿import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser'
import { User } from '../_models/index';
import { UserService, StorageService } from '../_services/index';
import { fadeInAnimation, ANIMATE_ON_ROUTE_ENTER } from '../_animations/index';

@Component({
    moduleId: module.id,
    animations: [fadeInAnimation],
    styleUrls: ['home.component.css'],
    templateUrl: 'home.component.html',
})

export class HomeComponent implements OnInit {
    animateOnRouteEnter = ANIMATE_ON_ROUTE_ENTER;
    currentUser: User;
    selectedUser: User;
    users: User[] = [];
    isUserLoaded: boolean = false;

    constructor(
        private userService: UserService,
        private storageService: StorageService,
        private titleService: Title) {
        this.titleService.setTitle("Orbit");
        //this.loadAllUsers();
        this.currentUser = this.storageService.currentUser;
        this.selectedUser = this.currentUser;
    }

    ngOnInit() {
    }

    //deleteUser(id: number) {
    //    this.userService.delete(id).subscribe(() => { this.loadAllUsers() });
    //}

    private loadAllUsers() {
        this.userService.getAll().subscribe(users => {
            this.users = users;
            this.selectedUser = this.currentUser;
            this.isUserLoaded = true;
        });
    }
}