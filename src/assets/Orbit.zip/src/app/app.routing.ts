﻿import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TasksComponent } from './tasks/index';
import { ReportsComponent } from './reports/index';
import { HomeComponent } from './home/index';
import { LoginComponent } from './login/index';
import { AuthGuard, AdminGuard } from './_guards/index';
import { UsersComponent } from "./users/index";
import { TeamsComponent } from "./teams/index";
import { TimesheetsComponent } from "./timesheets/index";
import { ProfileComponent } from "./profile/index";
import { LeavesComponent } from "./leaves/index";

const appRoutes: Routes = [
    { path: 'login', component: LoginComponent },
    { path: '', component: HomeComponent, canActivate: [AuthGuard] },
    { path: 'leaves', component: LeavesComponent, canActivate: [AuthGuard] },
    { path: 'profile', component: ProfileComponent, canActivate: [AuthGuard] },
    { path: 'home', component: HomeComponent, canActivate: [AuthGuard] },
    { path: 'tasks', component: TasksComponent, canActivate: [AuthGuard] },
    { path: 'tasks/:id', component: TasksComponent, canActivate: [AuthGuard] },
    { path: 'reports', component: ReportsComponent, canActivate: [AuthGuard] },
    { path: 'reports/:type/:period', component: ReportsComponent, canActivate: [AuthGuard] },
    { path: 'timesheets', component: TimesheetsComponent, canActivate: [AuthGuard] },
    { path: 'users', component: UsersComponent, canActivate: [AdminGuard] },
    { path: 'team', component: TeamsComponent, canActivate: [AdminGuard] },
    // otherwise redirect to home
    { path: '**', redirectTo: 'home', canActivate: [AuthGuard] }
];

export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes, { useHash: true, enableTracing: false });