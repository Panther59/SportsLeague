import { Component, OnInit, ViewChild } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { DataSource, CollectionViewer } from "@angular/cdk/collections";
import { MatSort, MatPaginator, MatDialog, MatDialogRef } from "@angular/material";
import { merge } from 'rxjs/observable/merge';
import { map } from 'rxjs/operators/map';
import { tap } from "rxjs/operators";
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Router, NavigationStart, ActivatedRoute } from '@angular/router';
import 'rxjs/add/operator/map';
import 'rxjs/Rx';

import { TaskService, MessageService, AlertService, UserService, StorageService } from '../_services/index';
import { User, ChangePassword } from '../_models/index';
import { AdduserDialog } from '../dialogs/index';
import { BehaviorSubject } from "rxjs/Rx";
import { Observable } from "rxjs/Observable";

@Component({
    moduleId: module.id,
    styleUrls: ['users.component.scss'],
    templateUrl: 'users.component.html'
})

export class UsersComponent implements OnInit {

    @ViewChild(MatSort) sort: MatSort;
    displayedColumns = ['id', 'name', 'userName', 'email', 'type'];
    displayedColumnsForRegularAdmin = ['id', 'name', 'userName', 'email', 'type', 'actions'];
    dataSource: UsersDataSource;
    users: User[] = [];
    error: string;
    isUserLoaded: boolean = false;
    constructor(
        private router: Router,
        public dialog: MatDialog,
        private titleService: Title,
        private userService: UserService,
        private storageService: StorageService,
        private messageService: MessageService,
        private alertService: AlertService) {

        this.titleService.setTitle("Users | Orbit");
        this.addActionColumn();
        this.getAllUsers();
    }

    ngOnInit() {
        this.dataSource = new UsersDataSource(this.sort);
    }

    ngAfterViewInit() {

        merge(this.sort.sortChange)
            .pipe(
            tap(() => this.loadUsersPage(this.users))
            )
            .subscribe();
    }

    addActionColumn() {
        if (this.isAdminUser() || this.isSuperUser()) {
            this.displayedColumns = this.displayedColumnsForRegularAdmin;
        }
    }

    isAdminUser(): boolean {
        if (this.storageService.currentUser != null && this.storageService.currentUser.type == 'Administrator') {
            return true;
        }
        else {
            return false;
        }
    }

    isSuperUser(): boolean {
        if (this.storageService.currentUser != null && this.storageService.currentUser.type == 'Super User') {
            return true;
        }
        else {
            return false;
        }
    }

    public loadUsersPage(users: User[]) {
        this.dataSource.loadUsers(users);
    }

    async resetPassword(user: User) {

        let result = await this.messageService.confirm("Password Reset", "Are you sure you want to reset password for " + user.userName);
        if (result) {
            let pass = new ChangePassword();
            pass.user = user;

            this.userService.changePassword(pass);
            this.messageService.showMessage("Password Reset", "Password has been reset to default value.", "Perfect");
        }
    }

    async deleteUser(user: User) {
        let result = await this.messageService.confirm("Delete User", "Are you sure you want to delete account for " + user.userName);
        if (result) {

            this.userService.deleteUser(user.id);
            this.messageService.showMessage("Delete User", "User has been deleted.", "Got it");
            await this.getAllUsers();
        }
    }

    async userDetail(user: User) {
        var addDialogRef = this.getUserDetailPopup();
        addDialogRef.componentInstance.loadDataForUser(user.id);
    }

    async openNewUser() {
        var addDialogRef = this.getUserDetailPopup();
        addDialogRef.componentInstance.loadData();
    }

    private getUserDetailPopup(): MatDialogRef<AdduserDialog> {
        var addDialogRef = this.dialog.open(AdduserDialog, {
            data: {
                router: this.router
            },
            disableClose: true,
            hasBackdrop: true
        });

        addDialogRef.componentInstance.alertService = this.alertService;
        addDialogRef.componentInstance.userService = this.userService;
        addDialogRef.afterClosed().subscribe(result => {
            if (result) {
                this.getAllUsers();
            }
        });

        return addDialogRef;
    }

    private getAllUsers() {
        var data = this.userService.getAll()
            .subscribe((
                data => {
                    this.users = data;
                    this.loadUsersPage(data);
                }),
            error => { this.error = error; });
    }

}

export class UsersDataSource extends DataSource<any> {
    private usersSubject = new BehaviorSubject<User[]>([]);
    constructor(private sort: MatSort) {
        super();
    }


    connect(): Observable<User[]> {
        return this.usersSubject.asObservable();
    }

    disconnect() {
        this.usersSubject.complete();
    }

    /** Returns a sorted copy of the database data. */
    loadUsers(data: User[]) {
        if (this.sort.active && this.sort.direction != '') {
            data = data.sort((a, b) => {
                let propertyA: number | string = '';
                let propertyB: number | string = '';

                switch (this.sort.active) {
                    case 'id': [propertyA, propertyB] = [a.id, b.id]; break;
                    case 'userName': [propertyA, propertyB] = [a.userName ? a.userName.toLowerCase() : '', b.userName ? b.userName.toLowerCase() : '']; break;
                    case 'name': [propertyA, propertyB] = [a.firstName ? a.firstName.toLowerCase() : '', b.firstName ? b.firstName.toLowerCase() : '']; break;
                    case 'email': [propertyA, propertyB] = [a.email ? a.email.toLowerCase() : '', b.email ? b.email.toLowerCase() : '']; break;
                    case 'phone': [propertyA, propertyB] = [a.phone, b.phone]; break;
                    case 'type': [propertyA, propertyB] = [a.type, b.type]; break;
                }

                let valueA = isNaN(+propertyA) ? propertyA : +propertyA;
                let valueB = isNaN(+propertyB) ? propertyB : +propertyB;

                return (valueA < valueB ? -1 : 1) * (this.sort.direction == 'asc' ? 1 : -1);
            });
        }

        this.usersSubject.next(data);
    }
}
