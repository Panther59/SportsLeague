﻿import { MatSort, MatTableDataSource } from "@angular/material";
import { Component, OnInit, ViewChild, EventEmitter, Injectable } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { DataSource } from "@angular/cdk/collections";
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Observable } from 'rxjs/Observable';
import { merge } from 'rxjs/observable/merge';
import { map } from 'rxjs/operators/map';
import { BehaviorSubject } from "rxjs/Rx";
import 'rxjs/add/observable/of';
import * as AppGlobal from "../global";

import { Team, TeamUserTimesheet, User, Task, Timesheet, ServiceError } from "../_models/index";
import { TeamService, TimesheetPeriodService, UserService, MessageService, TaskService } from "../_services/index";
import { ANIMATE_ON_ROUTE_ENTER } from "../_animations/index";

@Component({
    moduleId: module.id,
    styleUrls: ['teams.component.css'],
    templateUrl: 'teams.component.html',
    animations: [
        trigger('detailExpand', [
            state('collapsed', style({ height: '0px', minHeight: '0', visibility: 'hidden' })),
            state('expanded', style({ height: '*', visibility: 'visible' })),
            transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
        ]),
    ]
})

export class TeamsComponent implements OnInit {
    animateOnRouteEnter = ANIMATE_ON_ROUTE_ENTER;

    @ViewChild('myTeam') table: any;
    weekEndingDate: Date;
    users: User[] = [];
    tasks: Task[] = [];
    selectedUserId: number = -1;
    @BlockUI() blockUI: NgBlockUI;
    team: Team;
    showAddUserArea: boolean = false;
    allUsersLoaded: boolean = false;
    teamDetailFetched: boolean = false;
    expanded: any = {};
    pageLoaded: boolean = false;
    displayedColumns = ['expander', 'userName', 'status', 'hours', 'remove'];

    @ViewChild(MatSort) sort: MatSort;
    teamUsersDataSource: TeamDataSource;
    teamTimesheetDatabase: TeamTimesheetDatabase;
    isNotExpansionDetailRow = (_index: number, row: TeamUserTimesheet | TeamUserTimesheetDetailRow) => !row.hasOwnProperty('detailRow');
    isExpansionDetailRow = (_index: number, row: TeamUserTimesheet | TeamUserTimesheetDetailRow) => row.hasOwnProperty('detailRow');
    expandedElement: any;
    headerRowClicked = (row: any) => {
        if (this.expandedElement == row) {
            this.expandedElement = null;
        } else {
            if (row.timesheet != null) {
                this.expandedElement = row;
            }
        }
    }

    constructor(
        private userService: UserService,
        private taskService: TaskService,
        private messageService: MessageService,
        private timesheetPeriodService: TimesheetPeriodService,
        private titleService: Title,
        private teamService: TeamService) {
        this.titleService.setTitle("Team | Orbit");
    }

    ngOnInit() {
        this.teamTimesheetDatabase = new TeamTimesheetDatabase([]);
        this.teamUsersDataSource = new TeamDataSource(this.teamTimesheetDatabase, this.sort);
        this.initialize();
    }

    ngAfterViewInit() {
        //console.log(this.sort);
        //this.initialize();
        //this.teamUsersDataSource!.sort = this.sortForDataSource;
        //this.teamUsersDataSource = new TeamDataSource([], this.sort);
    }

    async initialize() {
        try {
            this.loadTasks();
            this.getAllUsers();
            //let period = await this.timesheetPeriodService.getPeriodByDate(new Date(Date.now())).toPromise();
            //this.weekEndingDate = period.endDate;
            //await this.onDateSelect();
            this.pageLoaded = true;
        } catch (ex) {
            await this.messageService.showMessage("Teams", ex.message);
        }
    }

    private loadTasks() {
        this.taskService.getAll().subscribe((data) => {
            this.tasks = data.records;
        }, (er) => {
        });
    }

    private async getAllUsers() {
        this.users = await this.userService.getAll().toPromise();
        this.allUsersLoaded = true;
    }

    onDateChanged(date: Date) {
        this.weekEndingDate = date;
        this.getTeamStatus(date);
    }

    async loadPreviousWeek() {
        var selectedDate = new Date(this.weekEndingDate);
        selectedDate = new Date(selectedDate.setDate(selectedDate.getDate() - 7));
        await this.getTeamStatus(selectedDate);
    }

    async loadNextWeek() {
        var selectedDate = new Date(this.weekEndingDate);
        selectedDate = new Date(selectedDate.setDate(selectedDate.getDate() + 7));
        await this.getTeamStatus(selectedDate);
    }

    async getTeamStatus(date: Date) {
        this.teamDetailFetched = false;
        this.blockUI.start("Loading Team Details");
        let team = await this.teamService.getTeamDetail(date).toPromise();
        this.teamDetailFetched = true;
        this.loadTeamDetail(team);
        this.blockUI.stop();
    }

    loadTeamDetail(team: Team) {
        team.users.forEach((u, i) => {
            u.userName = u.user.userName;
            u.hours = this.getHours(u);
        });
        this.teamTimesheetDatabase.data = team.users;

        this.team = team;
        this.weekEndingDate = this.team.period.endDate;
    }

    toggleExpandRow(row: any) {
        this.table.rowDetail.toggleExpandRow(row);
    }

    getHours(row: TeamUserTimesheet) {
        if (row && row.timesheet) {
            return this.getWeekTotal(row.timesheet);
        }
        else {
            return 0;
        }
    }

    getHoursDisplay(row: TeamUserTimesheet) {
        if (row && row.timesheet) {
            return this.getWeekTotal(row.timesheet).toString();
        }
        else {
            return "";
        }
    }

    getWeekTotal(timesheet: Timesheet) {
        let sum = 0;
        if (timesheet && timesheet.timesheetDetails) {
            timesheet.timesheetDetails.forEach((item, index) => {
                let daysum = 0;
                if (item.timesheetDayHours) {
                    daysum = item.timesheetDayHours.reduce((par, itm) => {
                        if (itm && itm.hours) {
                            sum = sum + itm.hours;
                        }

                        return daysum;
                    }, 0);
                }
                sum = sum + daysum;
            });
        }

        return sum;
    }

    public getRowDetailsHeight = (row: any) => {
        let base = 110;
        if (row.timesheet && row.timesheet.timesheetDetails && row.timesheet.timesheetDetails.length) {
            base = base + row.timesheet.timesheetDetails.length * 50;
        }

        return base;
    }

    getRowClass(row: any) {
        return { 'timesheetMissing': !Boolean(row.timesheet), 'timesheetPresent': Boolean(row.timesheet) };
    }

    async addNewTeamMember() {
        this.blockUI.start("Getting all the users...");
        try {
            if (this.allUsersLoaded) {
                await this.getAllUsers();
            }

            this.showAddUserArea = true;
        } catch (ex) {
            await this.messageService.showMessage("Add Users", ex.message);
        }
        finally {
            this.blockUI.stop();
        }
    }

    async cancelAddNewTeamMember() {
        this.showAddUserArea = false;
    }

    async saveAddNewTeamMember() {
        if (this.selectedUserId > 0) {
            this.blockUI.start("Adding User...");
            this.logMessageData("Saving new team member with id:" + this.selectedUserId);
            try {
                let team = await this.teamService.addTeamMember(this.selectedUserId).toPromise();

                this.showAddUserArea = false;
                this.blockUI.stop();
                this.onDateChanged(this.weekEndingDate);
            } catch (ex) {
                this.blockUI.stop();
                await this.messageService.showMessage("Add Member", ex.message);
            }

        }
    }

    async removeTeamMember(user: User) {
        if (user) {
            var result = await this.messageService.confirm("Delete Team Member", "Are you sure you want to delete " + user.firstName + " " + user.lastName + " from your team");
            if (result) {
                try {
                    let team = await this.teamService.removeTeamMember(user.id).toPromise();
                    this.onDateChanged(this.weekEndingDate);
                } catch (ex) {
                    await this.messageService.showMessage("Remove Member", ex.message);
                }
            }
        }
    }

    //private getCustomDate(input: Date) {
    //    var convDate = new Date(input);
    //    return { year: convDate.getFullYear(), month: convDate.getMonth() + 1, day: convDate.getDate() };
    //}

    private logMessageData(message: string) {
        AppGlobal.logMessageData(message);
    }
}

export interface TeamUserTimesheetDetailRow {
    detailRow: boolean;
    element: TeamUserTimesheet;
}

export class TeamTimesheetDatabase {
    dataChange: BehaviorSubject<TeamUserTimesheet[]> = new BehaviorSubject<TeamUserTimesheet[]>([]);

    get data(): TeamUserTimesheet[] { return this.dataChange.value; }
    set data(data: TeamUserTimesheet[]) {
        this.sourceData = data;
        this.dataChange.next(this.sourceData);
    }

    constructor(private sourceData: TeamUserTimesheet[]) {
        this.initialize();
    }

    initialize() {
        this.dataChange.next(this.sourceData);
    }
}

export class TeamDataSource extends DataSource<any> {
    constructor(private database: TeamTimesheetDatabase,
        private sort: MatSort) {
        super();
    }


    connect(): Observable<(TeamUserTimesheet | TeamUserTimesheetDetailRow)[]> {
        const displayDataChanges = [
            this.sort.sortChange,
            this.database.dataChange
        ];
        return merge(...displayDataChanges).pipe(map(() => {
            const rows: (TeamUserTimesheet | TeamUserTimesheetDetailRow)[] = [];
            const data = this.getSortedData();
            data.forEach(element => rows.push(element, { detailRow: true, element: element }));
            return rows;
        }));
    }

    disconnect() {
        // No-op
    }

    /** Returns a sorted copy of the database data. */
    getSortedData(): TeamUserTimesheet[] {
        const data = this.database.data;
        if (!this.sort.active || this.sort.direction == '') { return data; }

        return data.sort((a, b) => {
            let propertyA: number | string = '';
            let propertyB: number | string = '';

            switch (this.sort.active) {
                case 'userName': [propertyA, propertyB] = [a.userName, b.userName]; break;
                case 'status': [propertyA, propertyB] = [a.status, b.status]; break;
                case 'hours': [propertyA, propertyB] = [a.hours, b.hours]; break;
            }

            let valueA = isNaN(+propertyA) ? propertyA : +propertyA;
            let valueB = isNaN(+propertyB) ? propertyB : +propertyB;

            return (valueA < valueB ? -1 : 1) * (this.sort.direction == 'asc' ? 1 : -1);
        });
    }
}