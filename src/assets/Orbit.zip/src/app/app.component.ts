import { Component, OnDestroy, HostBinding, OnInit } from '@angular/core';
import { OverlayContainer } from '@angular/cdk/overlay';
import { MessageService, AuthenticationService, StorageService, ModuleService } from './_services/index';
import { Subscription } from 'rxjs/Subscription';
import { Router, ActivatedRoute } from '@angular/router';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';
import { WaitingComponent, BlockwaitingComponent } from "./waiting/index";
import { routerTransition } from "./_animations/index";
import * as AppGlobal from "./global";

@Component({
    selector: 'app-root',
    templateUrl: 'app.component.html',
    styleUrls: ['app.component.css'],
    animations: [routerTransition],
    moduleId: module.id
})
export class AppComponent implements OnInit, OnDestroy {
    isLoggedIn: boolean;
    subscription: Subscription;
    waitingTemplate: WaitingComponent;
    blockTemplate = BlockwaitingComponent;
    @HostBinding('class') componentCssClass;
    themes: string[] = ["my-light-theme","my-dark-theme" ,"my-theme"];

    constructor(
        public overlayContainer: OverlayContainer,
        private router: Router,
        private storageService: StorageService,
        private moduleService: ModuleService,
        private authenticationService: AuthenticationService) {

        authenticationService.appllicationStartup();
    }

    getCurrentUserName() {
        var user = this.storageService.currentUser;
        if (user && user.firstName && user.lastName) {
            return user.firstName + " " + user.lastName;
        }
        else {
            return null;
        }
    }

    getCurrentUserRoleName() {
        var user = this.storageService.currentUser;
        if (user && user.type) {
            return user.type;
        }
    }

    logout() {
        this.authenticationService.logout();
        this.router.navigate(['/login']);
    }

    isUserLoggedIn(): boolean {
        if (this.storageService.currentUser != null) {
            return true;
        }
        else {
            return false;
        }
    }

    selectTheme(theme: string = null) {
        let selectedTheme = 'my-theme';
        if (theme != null) {
            selectedTheme = theme;
        }

        this.applyTheme(selectedTheme);
        this.storageService.theme = selectedTheme;
    }

    applyTheme(theme: string) {
        this.componentCssClass = theme;
        const classList = this.overlayContainer.getContainerElement().classList;
        const toRemove = Array.from(classList).filter((item: string) =>
            item.includes('-theme')
        );
        if (toRemove && toRemove.length > 0) {
            classList.remove(...toRemove);
        }

        classList.add(theme);
        AppGlobal.logMessageData("Applied theme: " + theme);
    }

    isAdminUser(): boolean {
        if (this.storageService.currentUser != null &&
            (this.storageService.currentUser.type == 'Super User' ||
                this.storageService.currentUser.type == 'Administrator')) {
            return true;
        }
        else {
            return false;
        }
    }

    ngOnInit(): void {
        let theme = this.storageService.theme;
        AppGlobal.logMessageData("stored theme found: " + theme);
        if (theme && this.themes.some((t, i) => t == theme)) {
            this.selectTheme(theme);
        }
        else {
            this.selectTheme();
        }
    }

    ngOnDestroy() {
        // unsubscribe to ensure no memory leaks
        this.subscription.unsubscribe();
    }
}
