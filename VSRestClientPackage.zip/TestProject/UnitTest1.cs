﻿using System;
using System.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RestClientLibrary.ViewModel;

namespace TestProject
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            string data = File.ReadAllText(@"C:\Users\utkarsh.chauhan\Desktop\SampleJson.txt");
            var result = JsonTreeDataViewModel.JsonToTreeview(data);
        }
    }
}
