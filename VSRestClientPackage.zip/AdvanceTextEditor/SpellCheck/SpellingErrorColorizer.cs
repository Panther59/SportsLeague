﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using AdvanceTextEditor.Rendering;
using AdvanceTextEditor.Document;

namespace AdvanceTextEditor
{
    public class SpellingErrorColorizer : DocumentColorizingTransformer
    {
        private readonly TextDecorationCollection collection;
        private TextEditor _textEditor;

        public SpellingErrorColorizer(TextEditor textEditor, SpellCheckBehavior behavior)
        {
            behavior.IgnoreAllClicked += new System.EventHandler(behavior_IgnoreAllClicked);
            _textEditor = textEditor;
            // Create the Text decoration collection for the visual effect - you can get creative here
            collection = new TextDecorationCollection();
            var dec = new TextDecoration();
            dec.Pen = new Pen {Thickness = 1, DashStyle = DashStyles.DashDot, Brush = new SolidColorBrush(Colors.Red)};
            dec.PenThicknessUnit = TextDecorationUnit.FontRecommended;
            collection.Add(dec);

            // Set the static text box properties
            _textEditor.SpellCheckTextBox.AcceptsReturn = true;
            _textEditor.SpellCheckTextBox.AcceptsTab = true;
        }

        void behavior_IgnoreAllClicked(object sender, System.EventArgs e)
        {
            //if (this.CurrentContext != null)
            //{
            //    Colorize(this.CurrentContext);
            //}
            //_textEditor.TextArea.Caret.BringCaretToView();
            //DocumentLine line = _textEditor.Document.GetLineByOffset(_textEditor.CaretOffset);
            //ColorizeLine(line);
        }

        protected override void ColorizeLine(DocumentLine line)
        {
            lock (_textEditor.SpellCheckTextBox)
            {
                _textEditor.SpellCheckTextBox.Text = CurrentContext.Document.Text;
                int start = line.Offset;
                int end = line.EndOffset;
                start = _textEditor.SpellCheckTextBox.GetNextSpellingErrorCharacterIndex(start, LogicalDirection.Forward);
                while (start < end)
                {
                    if (start == -1)
                        break;

                    int wordEnd = start + _textEditor.SpellCheckTextBox.GetSpellingErrorLength(start);

                    SpellingError error = _textEditor.SpellCheckTextBox.GetSpellingError(start);
                    if (error != null)
                    {
                        base.ChangeLinePart(start, wordEnd,(VisualLineElement element) => element.TextRunProperties.SetTextDecorations(collection));
                    }

                    start = _textEditor.SpellCheckTextBox.GetNextSpellingErrorCharacterIndex(wordEnd, LogicalDirection.Forward);
                }
            }
        }
    }
}