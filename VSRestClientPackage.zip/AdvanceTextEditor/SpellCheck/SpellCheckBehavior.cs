﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Controls.Primitives;
using System.Text;
using System.Xml.Linq;
using System.Xml;
using System.Threading.Tasks;

namespace AdvanceTextEditor
{
    public class SpellCheckBehavior
    {

        public event EventHandler IgnoreAllClicked;
        public SpellCheckBehavior(TextEditor editor)
        {
            textEditor = editor;
            textEditor.ContextMenuOpening += textEditor_ContextMenuOpening;
        }
        private TextEditor textEditor;

        

        private void textEditor_ContextMenuOpening(object sender, ContextMenuEventArgs e)
        {
            if (textEditor == null || textEditor.SpellCheckEnabled == false)
            {
                return;
            }

            TextViewPosition? pos = textEditor.TextArea.TextView.GetPosition(new Point(e.CursorLeft, e.CursorTop));

            if (pos != null)
            {
                ////Reset the context menu
                //textEditor.ContextMenu = null;

                //Get the new caret position
                int newCaret = textEditor.Document.GetOffset(pos.Value.Line, pos.Value.Column);

                //Text box properties
                textEditor.SpellCheckTextBox.AcceptsReturn = true;
                textEditor.SpellCheckTextBox.AcceptsTab = true;
                textEditor.SpellCheckTextBox.SpellCheck.IsEnabled = true;
                textEditor.SpellCheckTextBox.Text = textEditor.Text;

                //Check for spelling errors
                SpellingError error = textEditor.SpellCheckTextBox.GetSpellingError(newCaret);
                if (textEditor.ContextMenu == null)
                {
                    textEditor.ContextMenu = new ContextMenu();
                }
                this.ClearSpellCheckMenuItems(textEditor.ContextMenu);

                //If there is a spelling mistake
                if (error != null)
                {
                    bool hasSuggestion = false;
                    int wordStartOffset = textEditor.SpellCheckTextBox.GetSpellingErrorStart(newCaret);
                    int wordLength = textEditor.SpellCheckTextBox.GetSpellingErrorLength(wordStartOffset);
                    foreach (string err in error.Suggestions)
                    {
                        hasSuggestion = true;
                        MenuItem item = new MenuItem() { Header = err };
                        var t = new Tuple<int, int>(wordStartOffset, wordLength);
                        item.Tag = t;
                        item.Click += item_Click;
                        textEditor.ContextMenu.Items.Add(item);
                    }

                    if (hasSuggestion == false)
                    {
                        var item = new MenuItem { Header = "(No spelling suggestions)", IsEnabled = false };
                        textEditor.ContextMenu.Items.Add(item);
                    }
                    textEditor.ContextMenu.Items.Add(new Separator());

                    //AddIgnoreMenu();
                }

                AddCutMenu();
                AddCopyMenu();
                if (textEditor.SelectionLength > 0)
                {
                    itemCut.IsEnabled = true;
                    itemCopy.IsEnabled = true;
                }
                AddPasteMenu();
                if(textEditor.SyntaxHighlighting != null && textEditor.SyntaxHighlighting.Name == "XML")
                {
                    textEditor.ContextMenu.Items.Add(new Separator());

                    MenuItem xmlFormatting = new MenuItem();
                    xmlFormatting.Header = "Format XML";
                    xmlFormatting.Click += new RoutedEventHandler(xmlFormatting_Click);
                    textEditor.ContextMenu.Items.Add(xmlFormatting);
                }
            }
        }

        void xmlFormatting_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                textEditor.Text = FormatXML(textEditor.Text);
            }
            catch (Exception ex)
            {
                textEditor.OnShowMessage("Error", ex.Message);
            }
        }

        public string FormatXML(string xml)
        {
            var stringBuilder = new StringBuilder();

            var element = XElement.Parse(xml);

            var settings = new XmlWriterSettings();
            settings.OmitXmlDeclaration = true;
            settings.Indent = true;
            settings.NewLineOnAttributes = true;

            using (var xmlWriter = XmlWriter.Create(stringBuilder, settings))
            {
                element.Save(xmlWriter);
            }

            return stringBuilder.ToString();
        }
        MenuItem itemIgnore;
        private void AddIgnoreMenu()
        {
            if (itemIgnore == null)
            {
                itemIgnore = this.GetMenu("Ignore All", System.Windows.Documents.EditingCommands.IgnoreSpellingError, textEditor.SpellCheckTextBox);
                //itemIgnore.Click += new RoutedEventHandler(itemIgnore_Click);
            }
            itemIgnore.IsEnabled = true;
            textEditor.ContextMenu.Items.Add(itemIgnore);
        }


        MenuItem itemCut;
        private void AddCutMenu()
        {
            if (itemCut == null)
            {
                itemCut = new MenuItem { Header = "Cut", InputGestureText = "Ctrl + X", IsEnabled = false };
                itemCut.Click += new RoutedEventHandler(itemCut_Click);
            }
            textEditor.ContextMenu.Items.Add(itemCut);
        }

        MenuItem itemCopy;
        private void AddCopyMenu()
        {
            if (itemCopy == null)
            {
                itemCopy = new MenuItem { Header = "Copy", InputGestureText = "Ctrl + C" ,IsEnabled = false};
                itemCopy.Click += new RoutedEventHandler(itemCopy_Click);
            }
            textEditor.ContextMenu.Items.Add(itemCopy);
        }

        MenuItem itemPaste;
        private void AddPasteMenu()
        {
            if (itemPaste == null)
            {
                itemPaste = new MenuItem { Header = "Paste",  InputGestureText = "Ctrl + V" };
                itemPaste.Click += new RoutedEventHandler(itemPaste_Click);
            }
            textEditor.ContextMenu.Items.Add(itemPaste);
        }

        //private void txtBox_ContextMenuOpening(object sender, ContextMenuEventArgs e)
        //{
        //    ContextMenu menu = this.Resources["ctxMenu"] as ContextMenu;
        //    this.ClearSpellCheckMenuItems(menu);
        //    int catatPos = txtBox.CaretIndex;
        //    SpellingError error = txtBox.GetSpellingError(catatPos);
        //    if (error != null)
        //    {
        //        this.txtBox.ContextMenu.Items.Insert(0, new Separator());
        //        MenuItem item = this.GetMenu("Ignore All", EditingCommands.IgnoreSpellingError, this.txtBox);
        //        item.Tag = "S";
        //        this.txtBox.ContextMenu.Items.Insert(0, item);
        //        foreach (string suggession in error.Suggestions)
        //        {
        //            item = this.GetMenu(suggession, EditingCommands.CorrectSpellingError, this.txtBox);
        //            item.Tag = "S";
        //            this.txtBox.ContextMenu.Items.Insert(0, item);
        //        }

        //    }
        //}
        private MenuItem GetMenu(string header, ICommand command, TextBoxBase target)
        {
            MenuItem item = new MenuItem();
            item.Header = header;
            item.Command = command;
            item.CommandParameter = header;
            item.CommandTarget = target;
            return item;
        }
        private void ClearSpellCheckMenuItems(ContextMenu menu)
        {
            if (menu != null)
            {
                for (int i = menu.Items.Count - 1; i >= 0; i--)
                {
                    menu.Items.RemoveAt(i);
                }
            }
        }

        void itemIgnore_Click(object sender, RoutedEventArgs e)
        {
            //if (IgnoreAllClicked != null)
            //{
            //    IgnoreAllClicked(this, null);
            //}
        }

        void itemPaste_Click(object sender, RoutedEventArgs e)
        {
            textEditor.Paste();
        }

        void itemCopy_Click(object sender, RoutedEventArgs e)
        {
            textEditor.Copy();
        }

        void itemCut_Click(object sender, RoutedEventArgs e)
        {
            textEditor.Cut();
        }

        //Click event of the context menu
        private void item_Click(object sender, RoutedEventArgs e)
        {
            var item = sender as MenuItem;
            if (item != null)
            {
                var seg = item.Tag as Tuple<int, int>;
                textEditor.Document.Replace(seg.Item1, seg.Item2, item.Header.ToString());
            }
        }
    }
}