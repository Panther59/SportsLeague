﻿namespace RestClientLibrary.Screen
{
    using DataLibrary;

    /// <summary>
    /// Defines the <see cref="ucKeyValuePairs" />
    /// </summary>
    public partial class ucKeyValuePairs : BaseUserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref = "ucKeyValuePairs"/> class.
        /// </summary>
        public ucKeyValuePairs()
        {
            InitializeComponent();
        }
    }
}
