﻿namespace RestClientLibrary.Screen
{
    using DataLibrary;

    /// <summary>
    /// Interaction logic for ucAutomationTasks.xaml
    /// </summary>
    public partial class ucAutomationTasks : BaseUserControl
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ucAutomationTasks"/> class.
        /// </summary>
        public ucAutomationTasks()
        {
            InitializeComponent();
        }
    }
}
