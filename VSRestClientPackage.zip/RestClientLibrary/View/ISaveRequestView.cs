﻿namespace RestClientLibrary.View
{
    using DataLibrary;

    public interface ISaveRequestView : IBaseView
    {
    }
}
