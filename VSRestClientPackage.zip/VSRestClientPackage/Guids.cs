﻿// Guids.cs
// MUST match guids.h
using System;

namespace Accenture.VSRestClientPackage
{
    static class GuidList
    {
        public const string guidVSRestClientPackagePkgString = "fb67ca2f-f710-48f6-97b2-5acfcc516998";
        public const string guidVSRestClientPackageCmdSetString = "9a4520b2-2ba2-4b6d-a65c-f384ae37b59e";
        public const string guidToolWindowPersistanceString = "74cf64a5-68f8-4e74-97fd-052579b0f9d9";

        public static readonly Guid guidVSRestClientPackageCmdSet = new Guid(guidVSRestClientPackageCmdSetString);
    };
}