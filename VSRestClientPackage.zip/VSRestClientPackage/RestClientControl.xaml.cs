﻿using RestClientLibrary.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Accenture.VSRestClientPackage
{
    /// <summary>
    /// Interaction logic for RestClientControl.xaml
    /// </summary>
    public partial class RestClientControl : UserControl
    {
        public RestClientControl()
        {
            InitializeComponent();
            this.SetTheme();
            Microsoft.VisualStudio.PlatformUI.VSColorTheme.ThemeChanged += this.VSColorTheme_ThemeChanged;
        }

        private void VSColorTheme_ThemeChanged(Microsoft.VisualStudio.PlatformUI.ThemeChangedEventArgs e)
        {
            this.SetTheme();
        }

        private void SetTheme()
        {
            var color = Microsoft.VisualStudio.PlatformUI.VSColorTheme.GetThemedColor(Microsoft.VisualStudio.PlatformUI.EnvironmentColors.ComboBoxBackgroundColorKey);
            var themeResource = this.GridMain.TryFindResource("EditorThemeKey");
            var variableResource = this.GridMain.TryFindResource("VariableBrush");

            bool isDark = IsDarkTheme(color);
            if (themeResource != null)
            {
                this.GridMain.Resources["EditorThemeKey"] = isDark ? "Dark" : "Light";
            }
            else
            {
                this.GridMain.Resources.Add("EditorThemeKey", isDark ? "Dark" : "Light");
            }

            if (variableResource != null)
            {
                this.GridMain.Resources["VariableBrush"] = isDark ? Brushes.Orange : Brushes.Blue;
            }
            else
            {
                this.GridMain.Resources.Add("VariableBrush", isDark ? Brushes.Orange : Brushes.Blue);
            }
        }

        private bool IsDarkTheme(System.Drawing.Color color)
        {
            int colorData = (color.R + color.G + color.B) / 3;

            return colorData < 120;
        }
    }
}