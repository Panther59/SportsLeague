﻿// PkgCmdID.cs
// MUST match PkgCmdID.h
using System;

namespace Accenture.VSRestClientPackage
{
    static class PkgCmdIDList
    {

        public const uint cmdidRestClient =    0x101;

    };
}